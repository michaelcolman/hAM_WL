// Initialisation file ====================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  // 
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include "Initialisation.h"
#include "Structs.h"
#include "Arguments.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Simulation settings ==========================================================================\\|
// Defaults
void set_simulation_defaults(Simulation_parameters *sim, double dt)
{
	sim->BCL				= 1000; 						// ms
	sim->NBeats				= 10;
	sim->Paced_time			= (sim->NBeats-1) * sim->BCL + 5; // up to end of last applied stimulus (which can be up to 5 ms long)
	sim->Total_time			= sim->Paced_time + 2000 - 5;  	// 2000 ms quiescent period
	sim->dt					= dt;							// ms

	sim->reference			= "";

	// S2
	sim->S2_CL				= 0; 		// No S2
	sim->NS2				= 1;		// Default to 1 S2 stimulus if applied
	sim->S2_time			= 0;
}

// Sets stim variables, model type etc dependant on input arguments
void set_simulation_settings(Simulation_parameters *sim, Argument_parameters A, const char * Model_type)
{
	// NOTE: throughout this function, native models are automatically set with no quiescnet period,
	// whereas integrated models are set to 2000 ms quiescent period. Pass "Total_time" and "Paced_time"
	// as arguments to control these directly

	// Sim time and pacing=========================================\\|
	if (A.reference_arg == true)
		sim->reference					= A.reference;
	if (A.BCL_arg == true) 
	{	
		sim->BCL 						= A.BCL;
		sim->Paced_time         		= (sim->NBeats-1) * sim->BCL + 5;
		if (strcmp(Model_type, "native") == 0) 		sim->Total_time		= sim->NBeats * sim->BCL;
		if (strcmp(Model_type, "integrated") == 0) 	sim->Total_time 	= sim->Paced_time + 2000 - 5;
	}
	if (A.NBeats_arg == true)
	{
		sim->NBeats						= A.NBeats;
		sim->Paced_time         		= (sim->NBeats-1) * sim->BCL + 5;
		if (A.Total_time_arg == true)
			sim->Total_time				= A.Total_time; 	
		else
		{	
			if (strcmp(Model_type, "native") == 0) 		sim->Total_time = sim->NBeats * sim->BCL;
			if (strcmp(Model_type, "integrated") == 0) 	sim->Total_time = sim->Paced_time + 2000 - 5;
		}
	}
	else if (A.Total_time_arg == true)
	{
		sim->Total_time             	= A.Total_time;
		if (A.Paced_time_arg == true)
			sim->Paced_time				= A.Paced_time;
		else
		{ 
			if (strcmp(Model_type, "native") == 0)			sim->Paced_time	= sim->Total_time;
			if (strcmp(Model_type, "integrated") == 0)		sim->Paced_time	= sim->Total_time - 2000;	
		}
		sim->NBeats						= (sim->Paced_time + (sim->BCL-2))/sim->BCL;
		sim->Paced_time					= (sim->NBeats-1) * (sim->BCL) + 5;
	}
	if (sim->NBeats < 0) sim->NBeats 	= 0;
	if (A.S2_arg == true)
	{
		sim->S2_CL						= A.S2_CL;
		if (A.NS2_arg == true) sim->NS2	= A.NS2;
		sim->S2_time					= (sim->NS2) * sim->S2_CL + sim->Paced_time;
		if (A.Total_time_arg == false)	sim->Total_time = sim->S2_time + 2000 - 5;
	}
	// End Sim time and pacing=====================================//|

	// dt
	if (A.dt_arg	== true)	sim->dt = A.dt;

	// Vclamp on/off
	sim->Vclamp		= A.Vclamp;

	// Read/Write state
	sim->Write_state	= A.Write_state;
	sim->Read_state		= A.Read_state;
}
// End simulation settings ======================================================================//|

// Model conditions (Model type, remodelling etc) ===============================================\\|
void set_model_conditions(Cell_parameters *p, Argument_parameters A)
{
	// Defaults
	p->Model            = "hAM_WL_CRN";                    // minimal model is default model type
	p->Agent            = "none";
	p->Remodelling      = "none";
	p->ISO              = 0.0;	// uM
	p->ISO_model		= "default";
	p->Mutation			= "none";

	// (hAM only) 
	p->hAM                = false;
	p->environment        = "intact"; // Needs a default for state files anyway

	// Set by arguments
	if (A.Model_arg == true)   			p->Model          = A.Model;
	if (A.ISO_arg == true)              p->ISO            = A.ISO;
	if (A.Remodelling_arg == true)      p->Remodelling    = A.Remodelling;
	if (A.Agent_arg == true)            p->Agent          = A.Agent;
	if (A.Mutation_arg == true)      	p->Mutation   	  = A.Mutation;
	//if (A.ISO_model_arg == true)		p->ISO_model	  = A.ISO_model;  // Set in Main after parameters are set to allow model-dependant default and argument overwriting

	// hAM specific settings
	if (strcmp(p->Model, "hAM_CRN") == 0 || strcmp(p->Model, "hAM_GB") == 0 || strcmp(p->Model, "hAM_NG") == 0 || strcmp(p->Model, "hAM_MT") == 0 \
			|| strcmp(p->Model, "hAM_WL_CRN") == 0 || strcmp(p->Model, "hAM_WL_GB") == 0 || strcmp(p->Model, "hAM_CRN_mWL") == 0 || strcmp(p->Model, "hAM_GB_mWL") == 0 || strcmp(p->Model, "hAM_NG_mWL") == 0)
	{
		p->hAM    = true;
	}

	if (p->hAM    == true)
	{
		if (A.environment_arg 	== true) 	p->environment  = A.environment;
	}
}

void set_local_model_conditions(Cell_parameters p_in, Cell_parameters *p)
{
	p->Model		= p_in.Model;
	p->Agent		= p_in.Agent;
	p->Remodelling	= p_in.Remodelling;
	p->ISO			= p_in.ISO;
	p->Mutation		= p_in.Mutation;
	p->hAM			= p_in.hAM;
	p->environment	= p_in.environment;
}
// End Model conditions (Model type, remodelling etc) ===========================================//|

// Output settings to screen ====================================================================\\|
void output_settings(Simulation_parameters sim, char const * directory, bool DC_current_mod_arg, Cell_parameters p)
{
	int counter = 0;

	char * filename       = (char*)malloc(500);
	sprintf(filename, "%s/Settings.dat", directory);

	FILE * so;
	so = fopen(filename, "wt");

	// Screen
	printf("\n*************************************************************************************************************\n");
	printf("MODEL SETTINGS\n\n");
	printf("Simulation settings:\n");
	printf("\tVoltage clamp is %s || Write state is %s || Read state is %s\n", sim.Vclamp, sim.Write_state, sim.Read_state);
	printf("\tBCL = %d ms || NBeats = %d || Total_time = %d ms || Paced_time = %d ms || dt = %f ms\n", sim.BCL, sim.NBeats, sim.Total_time, sim.Paced_time, sim.dt);
	if (sim.S2_CL > 0) printf("\tS2  = %d ms || NS2   = %d || S2_time = %d\n", sim.S2_CL, sim.NS2, sim.S2_time);
	printf("\nModel settings:\n");
	printf("\tModel = %s || Celltype = %s || Remodelling = %s || Agent = %s || Mutation = %s || ISO = %f uM", p.Model, p.Celltype, p.Remodelling, p.Agent, p.Mutation, p.ISO);
	if (p.ISO > 0) printf(" || ISO_model = %s\n", p.ISO_model);
	else printf("\n");
	if (p.hAM == true) printf("\thAM single cell model is being used; cell environment is %s ", p.environment);
	if (strcmp(p.environment, "isolated") == 0) printf ("|| Ihyp = %0.2f pA/pF\n", p.AIhyp);
	else printf("\n");
	if (DC_current_mod_arg == true)
	{
		printf("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=\n");
		printf("Direct control current modification:\n");
		printf("  Current/Flux scaling:\t\t");
		printf("INa_scale  = %.02f || INaL_scale  = %.02f || Ito_scale = %.02f || ICaL_scale = %.02f || IKur_scale  = %.02f\n", p.GNa, p.GNaL, p.Gto, p.GCaL, p.GKur);
		printf("\t\t\t\tIKr_scale  = %.02f || IKs_scale   = %.02f || IK1_scale = %.02f || INCX_scale = %.02f || ICaP_scale  = %.02f\n", p.GKr, p.GKs, p.GK1, p.GNCX, p.GCaP);
		printf("\t\t\t\tINab_scale = %.02f || ICab_scale  = %.02f || IKb_scale = %.02f || INaK_scale = %.02f || IClCa_scale = %.02f\n", p.GNab, p.GCab, p.GKb, p.GNaK, p.GClCa);
		printf("\t\t\t\tJup_scale  = %.02f || Jleak_scale = %.02f || Jrel_scale = %0.2f\n\n", p.Gup, p.Gleak, p.Grel);

		printf("  Time constant scaling:\t");
		printf("INa_va_tau_scale  = %.02f || INa_vi_1_tau_scale = %.02f || INa_vi_2_tau_scale = %.02f || INaL_va_tau_scale = %.02f || INaL_vi_tau_scale = %.02f\n", p.INa_va_tau_scale, p.INa_vi_1_tau_scale, p.INa_vi_2_tau_scale, p.INaL_va_tau_scale, p.INaL_vi_tau_scale);
		printf("\t\t\t\tIto_va_tau_scale  = %.02f || Ito_vi_tau_scale   = %.02f || ICaL_va_tau_scale  = %.02f || ICaL_vi_tau_scale = %.02f\n", p.Ito_va_tau_scale, p.Ito_vi_tau_scale, p.ICaL_va_tau_scale, p.ICaL_vi_tau_scale);
		printf("\t\t\t\tIKur_va_tau_scale = %.02f || IKur_vi_tau_scale  = %.02f || IKr_va_tau_scale   = %0.2f || IKs_va_tau_sacle  = %0.2f\n\n", p.IKur_va_tau_scale, p.IKur_vi_tau_scale, p.IKr_va_tau_scale, p.IKs_va_tau_scale);

		printf("  Voltage dependence shifts:\t");
		printf("INa_va_shift     = %.02f || INa_vi_shift      = %.02f || INaL_va_shift    = %.02f || INaL_vi_shift     = %.02f\n", p.INa_va_shift, p.INa_vi_shift, p.INaL_va_shift, p.INaL_vi_shift);
		printf("\t\t\t\tIto_va_ss_shift  = %.02f || Ito_va_tau_shift  = %.02f || Ito_vi_ss_shift  = %.02f || Ito_vi_tau_shift  = %.02f\n", p.Ito_va_ss_shift, p.Ito_va_tau_shift, p.Ito_vi_ss_shift, p.Ito_vi_tau_shift);
		printf("\t\t\t\tICaL_va_ss_shift = %.02f || ICaL_va_tau_shift = %.02f || ICaL_vi_ss_shift = %.02f || ICaL_vi_tau_shift = %.02f\n", p.ICaL_va_ss_shift, p.ICaL_va_tau_shift, p.ICaL_vi_ss_shift, p.ICaL_vi_tau_shift);
		printf("\t\t\t\tIKur_va_ss_shift = %.02f || IKur_va_tau_shift = %.02f || IKur_vi_ss_shift = %.02f || IKur_vi_tau_shift = %.02f\n", p.IKur_va_ss_shift, p.IKur_va_tau_shift, p.IKur_vi_ss_shift, p.IKur_vi_tau_shift);
		printf("\t\t\t\tIKr_va_ss_shift  = %.02f || IKr_va_tau_shift  = %.02f || IKr_vi_ss_shift  = %.02f\n\t\t\t\tIKs_va_ss_shift  = %.02f || IKs_va_tau_shift  = %.02f || IK1_va_shift     = %.02f\n\n", p.IKr_va_ss_shift, p.IKr_va_tau_shift, p.IKr_vi_ss_shift, p.IKs_va_ss_shift, p.IKs_va_tau_shift, p.IK1_va_shift);

		printf("  Voltage dependence gradients:\t");
		printf("Ito_va_ss_kscale  = %.02f || Ito_vi_ss_kscale  = %.02f || ICaL_va_ss_kscale = %.02f || ICaL_vi_ss_kscale = %.02f\n\t\t\t\tIKur_va_ss_kscale = %.02f || IKur_vi_ss_kscale = %.02f\n", p.Ito_va_ss_kscale, p.Ito_vi_ss_kscale, p.ICaL_va_ss_kscale, p.ICaL_vi_ss_kscale, p.IKur_va_ss_kscale, p.IKur_vi_ss_kscale);
		printf("\t\t\t\tIKr_va_ss_kscale  = %.02f || IKr_vi_ss_kscale  = %.02f || IKs_va_ss_kscale = %.02f\n", p.IKr_va_ss_kscale, p.IKr_vi_ss_kscale, p.IKs_va_ss_kscale);
		printf("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=\n");
	}
	printf("*************************************************************************************************************\n\n");

	// File
	fprintf(so,"Simulation settings:\n");
	fprintf(so,"\tVoltage clamp is %s\n", sim.Vclamp);
	fprintf(so,"\tBCL = %d ms || NBeats = %d || Total_time = %d ms || Paced_time = %d ms || dt = %f ms\n", sim.BCL, sim.NBeats, sim.Total_time, sim.Paced_time, sim.dt);
	fprintf(so,"Model settings:\n");
	fprintf(so,"\tModel = %s || Celltype = %s || Remodelling = %s || Agent = %s || Mutation = %s || ISO = %f uM", p.Model, p.Celltype, p.Remodelling, p.Agent, p.Mutation, p.ISO);
	if (p.ISO > 0) fprintf(so, " || ISO_model = %s\n", p.ISO_model);
    else fprintf(so, "\n");
	if (p.hAM == true) fprintf(so, "\thAM single cell model is being used; cell environment is %s ", p.environment);
    if (strcmp(p.environment, "isolated") == 0) fprintf (so, "|| Ihyp = %0.2f pA/pF\n", p.AIhyp);
    else fprintf(so, "\n");
	if (DC_current_mod_arg == true)
	{
		fprintf(so,"\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=\n");
		fprintf(so,"Direct control current modification:\n");
		fprintf(so,"  Current/Flux scaling:\t\t");
		fprintf(so,"INa_scale  = %.02f || INaL_scale  = %.02f || Ito_scale = %.02f || ICaL_scale = %.02f || IKur_scale  = %.02f\n", p.GNa, p.GNaL, p.Gto, p.GCaL, p.GKur);
		fprintf(so,"\t\t\t\tIKr_scale  = %.02f || IKs_scale   = %.02f || IK1_scale = %.02f || INCX_scale = %.02f || ICaP_scale  = %.02f\n", p.GKr, p.GKs, p.GK1, p.GNCX, p.GCaP);
		fprintf(so,"\t\t\t\tINab_scale = %.02f || ICab_scale  = %.02f || IKb_scale = %.02f || INaK_scale = %.02f || IClCa_scale = %.02f\n", p.GNab, p.GCab, p.GKb, p.GNaK, p.GClCa);
		fprintf(so,"\t\t\t\tJup_scale  = %.02f || Jleak_scale = %.02f || || Jrel_scale = %0.2f\n\n", p.Gleak, p.Gup, p.Grel);

		fprintf(so,"  Time constant scaling:\t");
		fprintf(so,"INa_va_tau_scale  = %.02f || INa_vi_1_tau_scale = %.02f || INa_vi_2_tau_scale = %.02f || INaL_va_tau_scale = %.02f || INaL_vi_tau_scale = %.02f\n", p.INa_va_tau_scale, p.INa_vi_1_tau_scale, p.INa_vi_2_tau_scale, p.INaL_va_tau_scale, p.INaL_vi_tau_scale);
		fprintf(so,"\t\t\t\tIto_va_tau_scale  = %.02f || Ito_vi_tau_scale   = %.02f || ICaL_va_tau_scale  = %.02f || ICaL_vi_tau_scale = %.02f\n", p.Ito_va_tau_scale, p.Ito_vi_tau_scale, p.ICaL_va_tau_scale, p.ICaL_vi_tau_scale);
		fprintf(so,"\t\t\t\tIKur_va_tau_scale = %.02f || IKur_vi_tau_scale  = %.02f || IKr_va_tau_scale   = %0.2f || IKs_va_tau_sacle  = %0.2f\n\n", p.IKur_va_tau_scale, p.IKur_vi_tau_scale, p.IKr_va_tau_scale, p.IKs_va_tau_scale);

		fprintf(so,"  Voltage dependence shifts:\t");
		fprintf(so,"INa_va_shift     = %.02f || INa_vi_shift      = %.02f || INaL_va_shift    = %.02f || INaL_vi_shift     = %.02f\n", p.INa_va_shift, p.INa_vi_shift, p.INaL_va_shift, p.INaL_vi_shift);
		fprintf(so,"\t\t\t\tIto_va_ss_shift  = %.02f || Ito_va_tau_shift  = %.02f || Ito_vi_ss_shift  = %.02f || Ito_vi_tau_shift  = %.02f\n", p.Ito_va_ss_shift, p.Ito_va_tau_shift, p.Ito_vi_ss_shift, p.Ito_vi_tau_shift);
		fprintf(so,"\t\t\t\tICaL_va_ss_shift = %.02f || ICaL_va_tau_shift = %.02f || ICaL_vi_ss_shift = %.02f || ICaL_vi_tau_shift = %.02f\n", p.ICaL_va_ss_shift, p.ICaL_va_tau_shift, p.ICaL_vi_ss_shift, p.ICaL_vi_tau_shift);
		fprintf(so,"\t\t\t\tIKur_va_ss_shift = %.02f || IKur_va_tau_shift = %.02f || IKur_vi_ss_shift = %.02f || IKur_vi_tau_shift = %.02f\n", p.IKur_va_ss_shift, p.IKur_va_tau_shift, p.IKur_vi_ss_shift, p.IKur_vi_tau_shift);
		fprintf(so,"\t\t\t\tIKr_va_ss_shift  = %.02f || IKr_va_tau_shift  = %.02f || IKr_vi_ss_shift  = %.02f\n\t\t\t\tIKs_va_ss_shift  = %.02f || IKs_va_tau_shift  = %.02f || IK1_va_shift     = %.02f\n\n", p.IKr_va_ss_shift, p.IKr_va_tau_shift, p.IKr_vi_ss_shift, p.IKs_va_ss_shift, p.IKs_va_tau_shift, p.IK1_va_shift);

		fprintf(so,"  Voltage dependence gradients:\t");
		fprintf(so,"Ito_va_ss_kscale  = %.02f || Ito_vi_ss_kscale  = %.02f || ICaL_va_ss_kscale = %.02f || ICaL_vi_ss_kscale = %.02f\n\t\t\t\tIKur_va_ss_kscale = %.02f || IKur_vi_ss_kscale = %.02f\n", p.Ito_va_ss_kscale, p.Ito_vi_ss_kscale, p.ICaL_va_ss_kscale, p.ICaL_vi_ss_kscale, p.IKur_va_ss_kscale, p.IKur_vi_ss_kscale);
		fprintf(so,"\t\t\t\tIKr_va_ss_kscale  = %.02f || IKr_vi_ss_kscale  = %.02f || IKs_va_ss_kscale = %.02f\n", p.IKr_va_ss_kscale, p.IKr_vi_ss_kscale, p.IKs_va_ss_kscale);
		fprintf(so,"\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=\n");
	}

	fclose(so);
}

// Default parameters (parameters which apply to all models; model specific can overwrite =======\\|
// Native Ca handling =======================================================\\|
void set_default_parameters(Cell_parameters *p)
{
	// Constants ==================================================\\|
	p->R			= 8.314;    // J mol^-1 K^-1
	p->F			= 96.485;   // C mmol-1
	p->T			= 310;      // K
	p->FoRT			= p->F/(p->R*p->T);
	// End Constants ==============================================//|

	// Stimulus parameters ========================================\\|
	p->stimduration	= 5.0; 		// ms
	p->stimmag		= -12.5;	// pA/pF
	// End Stimulus parameters ====================================//|

	// Concentrations / environment ===============================\\|
	// Concentrations (constant OR initial condition)
	p->Nai              = 7.95;     // mM
	p->Nao              = 140;      // mM
	p->Ki               = 143.103;  // mM
	p->Ko               = 4.5;      // mM
	p->Cai              = 0.000102; // mM 
	p->Cao              = 1.8;      // mM
	p->Cm				= 100;		// pF
	// End Concentrations =========================================//|

	// Reference for multi files for het and mod ==================\\| 
	p->Het_set_ref			= 0;
	p->ISO_set_ref			= 0;
	p->Agent_set_ref		= 0;
	p->Remodelling_set_ref 	= 0;
	p->Mutation_set_ref		= 0;
	p->Celltype             = "default";	// This is overwritten in sepcific params if default is a specific cell type
	// End reference for multi files for het and mod ==============//| 
}
// End native Ca handling ===================================================//|

// Current modification variables ===============================================================\\|
void set_modification_defaults_native(Cell_parameters *p)
{
	// Scale factors all defaulted to 1
	p->GNa						= 1.0;
	p->GNaL						= 1.0;
	p->Gto						= 1.0;
	p->GCaL						= 1.0;
	p->GKur						= 1.0;
	p->GKr						= 1.0;
	p->GKs						= 1.0;
	p->GK1						= 1.0;
	p->GNCX						= 1.0;
	p->GCaP						= 1.0;
	p->GNab						= 1.0;
	p->GCab						= 1.0;
	p->GKb						= 1.0;
	p->GNaK						= 1.0;
	p->GClCa					= 1.0;

	p->INa_va_tau_scale			= 1.0;
	p->INa_vi_1_tau_scale		= 1.0;
	p->INa_vi_2_tau_scale		= 1.0;
	p->INaL_va_tau_scale		= 1.0;
	p->INaL_vi_tau_scale		= 1.0;
	p->Ito_va_tau_scale			= 1.0;
	p->Ito_vi_tau_scale			= 1.0;
	p->ICaL_va_tau_scale		= 1.0;
	p->ICaL_vi_tau_scale		= 1.0;
	p->IKur_va_tau_scale		= 1.0;
	p->IKur_vi_tau_scale		= 1.0;
	p->IKr_va_tau_scale			= 1.0;
	p->IKr_vi_tau_scale			= 1.0;
	p->IKs_va_tau_scale			= 1.0;

	p->Ito_va_ss_kscale			= 1.0;
	p->Ito_vi_ss_kscale			= 1.0;
	p->ICaL_va_ss_kscale		= 1.0;
	p->ICaL_vi_ss_kscale		= 1.0;
	p->IKur_va_ss_kscale		= 1.0;
	p->IKur_vi_ss_kscale		= 1.0;
	p->IKr_va_ss_kscale			= 1.0;
	p->IKr_vi_ss_kscale			= 1.0;
	p->IKs_va_ss_kscale			= 1.0;

	// Voltage shifts all defaulted to 0
	p->INa_va_shift				= 0.0;
	p->INa_vi_shift				= 0.0;
	p->INaL_va_shift			= 0.0;
	p->INaL_vi_shift			= 0.0;

	p->Ito_va_ss_shift			= 0.0;
	p->Ito_vi_ss_shift			= 0.0;
	p->Ito_va_tau_shift			= 0.0;
	p->Ito_vi_tau_shift			= 0.0;
	p->ICaL_va_ss_shift			= 0.0;
	p->ICaL_vi_ss_shift			= 0.0;
	p->ICaL_va_tau_shift		= 0.0;
	p->ICaL_vi_tau_shift		= 0.0;
	p->IKur_va_ss_shift			= 0.0;
	p->IKur_vi_ss_shift			= 0.0;
	p->IKur_va_tau_shift		= 0.0;
	p->IKur_vi_tau_shift		= 0.0;
	p->IKr_va_ss_shift        	= 0.0;
	p->IKr_va_tau_shift       	= 0.0;
	p->IKr_vi_ss_shift        	= 0.0;
	p->IKr_vi_tau_shift       	= 0.0;
	p->IKs_va_ss_shift        	= 0.0;
	p->IKs_va_tau_shift       	= 0.0;
	p->IK1_va_shift				= 0.0;

	// Ca handling
	p->Gup						= 1.0;
	p->Gleak					= 1.0;
	p->Grel						= 1.0;

}

void assign_modification_from_arguments(Cell_parameters *p, Argument_parameters A)
{
	// If the argument has been passed, set the parameters to the defined argument, else leave as defaults
	if (A.GNa_arg		== true)	p->GNa		*= A.GNa;
	if (A.GNaL_arg		== true)	p->GNaL		*= A.GNaL;
	if (A.Gto_arg		== true)	p->Gto		*= A.Gto;
	if (A.GCaL_arg		== true)	p->GCaL		*= A.GCaL;
	if (A.GKur_arg		== true)	p->GKur		*= A.GKur;
	if (A.GKr_arg		== true)	p->GKr		*= A.GKr;
	if (A.GKs_arg		== true)	p->GKs		*= A.GKs;
	if (A.GK1_arg		== true)	p->GK1		*= A.GK1;
	if (A.GNCX_arg		== true)	p->GNCX		*= A.GNCX;
	if (A.GCaP_arg		== true)	p->GCaP		*= A.GCaP;
	if (A.GNab_arg		== true)	p->GNab		*= A.GNab;
	if (A.GCab_arg		== true)	p->GCab		*= A.GCab;
	if (A.GKb_arg		== true)	p->GKb		*= A.GKb;
	if (A.GNaK_arg		== true)	p->GNaK		*= A.GNaK;
	if (A.GClCa_arg		== true)	p->GClCa	*= A.GClCa;
	if (A.Gup_arg		== true)	p->Gup		*= A.Gup;
	if (A.Gleak_arg		== true)	p->Gleak	*= A.Gleak;
	if (A.Grel_arg		== true)	p->Grel		*= A.Grel;

	if (A.INa_va_tau_scale_arg		== true)	p->INa_va_tau_scale		*= A.INa_va_tau_scale;
	if (A.INa_vi_1_tau_scale_arg	== true)	p->INa_vi_1_tau_scale	*= A.INa_vi_1_tau_scale;
	if (A.INa_vi_2_tau_scale_arg	== true)	p->INa_vi_2_tau_scale	*= A.INa_vi_2_tau_scale;
	if (A.INaL_va_tau_scale_arg		== true)	p->INaL_va_tau_scale	*= A.INaL_va_tau_scale;
	if (A.INaL_vi_tau_scale_arg		== true)	p->INaL_vi_tau_scale	*= A.INaL_vi_tau_scale;
	if (A.Ito_va_tau_scale_arg		== true)	p->Ito_va_tau_scale		*= A.Ito_va_tau_scale;
	if (A.Ito_vi_tau_scale_arg		== true)	p->Ito_vi_tau_scale		*= A.Ito_vi_tau_scale;
	if (A.ICaL_va_tau_scale_arg		== true)	p->ICaL_va_tau_scale	*= A.ICaL_va_tau_scale;
	if (A.ICaL_vi_tau_scale_arg		== true)	p->ICaL_vi_tau_scale	*= A.ICaL_vi_tau_scale;
	if (A.IKur_va_tau_scale_arg		== true)	p->IKur_va_tau_scale	*= A.IKur_va_tau_scale;
	if (A.IKur_vi_tau_scale_arg		== true)	p->IKur_vi_tau_scale	*= A.IKur_vi_tau_scale;
	if (A.IKr_va_tau_scale_arg		== true)	p->IKr_va_tau_scale		*= A.IKr_va_tau_scale;
	if (A.IKs_va_tau_scale_arg		== true)	p->IKs_va_tau_scale		*= A.IKs_va_tau_scale;
	
	if (A.INa_va_shift_arg			== true)	p->INa_va_shift			+= A.INa_va_shift;
	if (A.INa_vi_shift_arg			== true)	p->INa_vi_shift			+= A.INa_vi_shift;
	if (A.INaL_va_shift_arg			== true)	p->INaL_va_shift		+= A.INaL_va_shift;
	if (A.INaL_vi_shift_arg			== true)	p->INaL_vi_shift		+= A.INaL_vi_shift;
	if (A.Ito_va_ss_shift_arg		== true)	p->Ito_va_ss_shift		+= A.Ito_va_ss_shift;
	if (A.Ito_va_tau_shift_arg		== true)	p->Ito_va_tau_shift		+= A.Ito_va_tau_shift;
	if (A.Ito_vi_ss_shift_arg		== true)	p->Ito_vi_ss_shift		+= A.Ito_vi_ss_shift;
	if (A.Ito_vi_tau_shift_arg		== true)	p->Ito_vi_tau_shift		+= A.Ito_vi_tau_shift;
	if (A.ICaL_va_ss_shift_arg		== true)	p->ICaL_va_ss_shift		+= A.ICaL_va_ss_shift;
	if (A.ICaL_va_tau_shift_arg		== true)	p->ICaL_va_tau_shift	+= A.ICaL_va_tau_shift;
	if (A.ICaL_vi_ss_shift_arg		== true)	p->ICaL_vi_ss_shift		+= A.ICaL_vi_ss_shift;
	if (A.ICaL_vi_tau_shift_arg		== true)	p->ICaL_vi_tau_shift	+= A.ICaL_vi_tau_shift;
	if (A.IKur_va_ss_shift_arg		== true)	p->IKur_va_ss_shift		+= A.IKur_va_ss_shift;
	if (A.IKur_va_tau_shift_arg		== true)	p->IKur_va_tau_shift	+= A.IKur_va_tau_shift;
	if (A.IKur_vi_ss_shift_arg		== true)	p->IKur_vi_ss_shift		+= A.IKur_vi_ss_shift;
	if (A.IKur_vi_tau_shift_arg		== true)	p->IKur_vi_tau_shift	+= A.IKur_vi_tau_shift;
	if (A.IKr_va_ss_shift_arg		== true)	p->IKr_va_ss_shift		+= A.IKr_va_ss_shift;
	if (A.IKr_va_tau_shift_arg		== true)	p->IKr_va_tau_shift		+= A.IKr_va_tau_shift;
	if (A.IKr_vi_ss_shift_arg		== true)	p->IKr_vi_ss_shift		+= A.IKr_vi_ss_shift;
	if (A.IKs_va_ss_shift_arg		== true)	p->IKs_va_ss_shift		+= A.IKs_va_ss_shift;
	if (A.IKs_va_tau_shift_arg		== true)	p->IKs_va_tau_shift		+= A.IKs_va_tau_shift;
	if (A.IK1_va_shift_arg			== true)	p->IK1_va_shift			+= A.IK1_va_shift;
	if (A.Ito_shift_arg				== true)
	{
		p->Ito_va_ss_shift			+= A.Ito_shift;
		p->Ito_vi_ss_shift			+= A.Ito_shift;
		p->Ito_va_tau_shift			+= A.Ito_shift;
		p->Ito_vi_tau_shift			+= A.Ito_shift;
	}
	if (A.ICaL_shift_arg			== true)
	{
		p->ICaL_va_ss_shift			+= A.ICaL_shift;
		p->ICaL_vi_ss_shift			+= A.ICaL_shift;
		p->ICaL_va_tau_shift		+= A.ICaL_shift;
		p->ICaL_vi_tau_shift		+= A.ICaL_shift;
	}
	if (A.IKur_shift_arg			== true)
	{
		p->IKur_va_ss_shift			+= A.IKur_shift;
		p->IKur_vi_ss_shift			+= A.IKur_shift;
		p->IKur_va_tau_shift		+= A.IKur_shift;
		p->IKur_vi_tau_shift		+= A.IKur_shift;
	}
	
	if (A.Ito_va_ss_kscale_arg		== true)	p->Ito_va_ss_kscale		*= A.Ito_va_ss_kscale;
	if (A.Ito_vi_ss_kscale_arg		== true)	p->Ito_vi_ss_kscale		*= A.Ito_vi_ss_kscale;
	if (A.ICaL_va_ss_kscale_arg		== true)	p->ICaL_va_ss_kscale	*= A.ICaL_va_ss_kscale;
	if (A.ICaL_vi_ss_kscale_arg		== true)	p->ICaL_vi_ss_kscale	*= A.ICaL_vi_ss_kscale;
	if (A.IKur_va_ss_kscale_arg		== true)	p->IKur_va_ss_kscale	*= A.IKur_va_ss_kscale;
	if (A.IKur_vi_ss_kscale_arg		== true)	p->IKur_vi_ss_kscale	*= A.IKur_vi_ss_kscale;
	if (A.IKr_va_ss_kscale_arg		== true)	p->IKr_va_ss_kscale		*= A.IKr_va_ss_kscale;
	if (A.IKr_vi_ss_kscale_arg		== true)	p->IKr_vi_ss_kscale		*= A.IKr_vi_ss_kscale;
	if (A.IKs_va_ss_kscale_arg		== true)	p->IKs_va_ss_kscale		*= A.IKs_va_ss_kscale;
}
// End current modification piables ===========================================================//|

// Argument handling file =================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include "Arguments.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h> 

// Set Argument defaults ==============================================================\\|
void set_argument_defaults(Argument_parameters *A)
{
	// Simulation setttings =========\\|
	A->reference_arg	= false;
	A->BCL_arg          = false;
	A->Total_time_arg   = false;
	A->Paced_time_arg   = false;
	A->NBeats_arg       = false;
	A->dt_arg           = false;
	A->S2_arg			= false;
	// End sim settings =============//|

	// Model and cell conditions=====\\|
	A->Model_arg        = false;
	A->Celltype_arg     = false;
	A->Agent_arg		= false;
	A->Remodelling_arg	= false;
	A->ISO_arg			= false;
	A->ISO_model_arg	= false;
	A->Mutation_arg		= false;
	A->Vclamp			= "Off";
	A->Write_state		= "Off";
	A->Read_state		= "Off";
	A->Ihyp_arg			= false;
	A->environment_arg	= false;
	// End model and cell ===========//|   

	// Direct control current mod ===\\|
	A->DC_current_mod_arg		= false;	   	
	A->GNa_arg					= false;                 
	A->GNaL_arg					= false;                
	A->Gto_arg					= false;               
	A->GCaL_arg					= false;                
	A->GKur_arg					= false;                
	A->GKr_arg					= false;                 
	A->GKs_arg					= false;                 
	A->GK1_arg					= false;                 
	A->GNCX_arg					= false;                
	A->GCaP_arg					= false;                
	A->GNab_arg					= false;                
	A->GCab_arg					= false;                
	A->GKb_arg					= false;                 
	A->GNaK_arg					= false;                
	A->GClCa_arg				= false;               
	A->INa_va_tau_scale_arg		= false;    
	A->INa_vi_1_tau_scale_arg	= false;  
	A->INa_vi_2_tau_scale_arg	= false;  
	A->INaL_va_tau_scale_arg	= false;   
	A->INaL_vi_tau_scale_arg	= false;   
	A->Ito_va_tau_scale_arg		= false;    
	A->Ito_vi_tau_scale_arg		= false;    
	A->ICaL_va_tau_scale_arg	= false;   
	A->ICaL_vi_tau_scale_arg	= false;   
	A->IKur_va_tau_scale_arg	= false;   
	A->IKur_vi_tau_scale_arg	= false;   
	A->IKr_va_tau_scale_arg		= false;    
	A->IKs_va_tau_scale_arg		= false;    
	A->INa_va_shift_arg			= false;        
	A->INa_vi_shift_arg			= false;        
	A->INaL_va_shift_arg		= false;       
	A->INaL_vi_shift_arg		= false;       
	A->Ito_va_ss_shift_arg		= false;     
	A->Ito_vi_ss_shift_arg		= false;     
	A->Ito_va_tau_shift_arg		= false;    
	A->Ito_vi_tau_shift_arg		= false;    
	A->Ito_va_ss_kscale_arg		= false;    
	A->Ito_vi_ss_kscale_arg		= false;    
	A->ICaL_va_ss_shift_arg		= false;    
	A->ICaL_vi_ss_shift_arg		= false;    
	A->ICaL_va_tau_shift_arg	= false;   
	A->ICaL_vi_tau_shift_arg	= false;   
	A->ICaL_va_ss_kscale_arg	= false;   
	A->ICaL_vi_ss_kscale_arg	= false;   
    A->IKur_va_ss_shift_arg		= false;    
    A->IKur_vi_ss_shift_arg		= false;    
    A->IKur_va_tau_shift_arg	= false;   
    A->IKur_vi_tau_shift_arg	= false;   
    A->IKur_va_ss_kscale_arg	= false;   
    A->IKur_vi_ss_kscale_arg	= false;   
    A->IKr_va_ss_shift_arg		= false;     
    A->IKr_va_tau_shift_arg		= false;    
    A->IKr_va_ss_kscale_arg		= false;    
    A->IKr_vi_ss_shift_arg		= false;     
    A->IKr_vi_ss_kscale_arg		= false;    
    A->IKs_va_ss_shift_arg		= false;     
    A->IKs_va_tau_shift_arg		= false;    
    A->IKs_va_ss_kscale_arg		= false;    
    A->IK1_va_shift_arg			= false;        
    A->Gup_arg					= false;                 
    A->Gleak_arg				= false;                
    A->Grel_arg					= false;                
	A->Ito_shift_arg			= false;
	A->ICaL_shift_arg			= false;
	A->IKur_shift_arg			= false;
	// End Direct control current mod //|
 
}
// End Set Argument defaults ==========================================================//|

// Set arguments ======================================================================\\|
void set_arguments(int Narg, char *argin[], Argument_parameters *A, char const *Version)
{
	// Open Arg tracker file and print version and time
	FILE *out;
	out = fopen("Log.dat", "a"); // append so it continuously logs all sims
	time_t rawtime;
	time (&rawtime);
	fprintf(out, "Sim time: %sModel version ran: %s\nSettings:\t", ctime (&rawtime), Version);

	// Read arguments (command line or from file) into Argument_parameters struct
	int counter = 1;
	while (counter < Narg) // loop until Number of arguments has been reached
	{
		// Simulation setttings =============================================\\|
		if (strcmp(argin[counter], "Reference") == 0 || strcmp(argin[counter], "reference") == 0) // if there is no difference between argument and "BCL"
        {
            A->reference              	= argin[counter+1];       	// Reads argument into reference variable
			A->reference_arg			= true;						// Argument has been passed
            fprintf(out, "reference   %s ", argin[counter+1]);    	// Print option to log file
            counter++;
        }		
		else if (strcmp(argin[counter], "Vclamp") == 0)
        {
			A->Vclamp           = argin[counter+1];
			fprintf(out, "Vclamp   %s ", argin[counter+1]);
			if (strcmp(A->Vclamp, "On") != 0 && strcmp(A->Vclamp, "Off") != 0)
			{
				printf("ERROR: \"%s\" is not a valid Vclamp argument. Please pass only \"Off\" or \"On\"\n\n", A->Vclamp);
				exit(1);
			}
			counter++;
		}
		else if (strcmp(argin[counter], "BCL") == 0)
		{
			A->BCL				= atoi(argin[counter+1]);	
			A->BCL_arg			= true;						
			fprintf(out, "BCL	%s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Total_time") == 0 || strcmp(argin[counter], "total_time") == 0 || strcmp(argin[counter], "Total_Time") == 0)
		{
			A->Total_time		= atoi(argin[counter+1]); 
			A->Total_time_arg	= true;
			fprintf(out, "Total_time %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Paced_time") == 0 || strcmp(argin[counter], "paced_time") == 0 || strcmp(argin[counter], "Paced_Time") == 0)
		{
			A->Paced_time       = atoi(argin[counter+1]);
			A->Paced_time_arg   = true;
			fprintf(out, "Paced_time %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "NBeats") == 0 || strcmp(argin[counter], "Nbeats") == 0 || strcmp(argin[counter], "Beats") == 0 || strcmp(argin[counter], "beats") == 0)
		{
			A->NBeats       	= atoi(argin[counter+1]);
			A->NBeats_arg   	= true;
			fprintf(out, "NBeats %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "dt") == 0)         
		{
			A->dt              	= atof(argin[counter+1]);       
			A->dt_arg          = true;                         
			fprintf(out, "dt %s ", argin[counter+1]);                
			counter++;
		}
		else if (strcmp(argin[counter], "S2") == 0)
		{
			A->S2_CL            = atoi(argin[counter+1]);
			A->S2_arg          = true;
			fprintf(out, "S2   %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "NS2") == 0)
		{
			A->NS2            = atoi(argin[counter+1]);
			A->NS2_arg        = true;
			fprintf(out, "NS2   %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Write_state") == 0)
		{
			A->Write_state           	= argin[counter+1];
			fprintf(out, "Write_state   %s ", argin[counter+1]);
			if (strcmp(A->Write_state, "On") != 0 && strcmp(A->Write_state, "Off") != 0 && strcmp(A->Write_state, "phase") != 0)
            {
                printf("ERROR: \"%s\" is not a valid Read/Write state argument. Please pass only \"Off\" or \"On\" or (tissue only): \"phase\"\n\n", A->Write_state);
                exit(1);
            }
			counter++;
		}
		else if (strcmp(argin[counter], "Read_state") == 0)
		{
			A->Read_state      	     	= argin[counter+1];
			fprintf(out, "Read_state   %s ", argin[counter+1]);
			if (strcmp(A->Read_state, "On") != 0 && strcmp(A->Read_state, "Off") != 0 && strcmp(A->Read_state, "phase") != 0 )
            {
                printf("ERROR: \"%s\" is not a valid Read/Write state argument. Please pass only \"Off\" or \"On\" or (tissue only): \"phase\"\n\n", A->Read_state);
                exit(1);
            }
			counter++;
		}
		// End Simulation setttings =========================================//|

		// Model and cell conditions ========================================\\|
		else if (strcmp(argin[counter], "Model") == 0)
		{
			A->Model			= argin[counter+1];
			A->Model_arg       	= true;
			fprintf(out, "Model %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Celltype") == 0)
		{
			A->Celltype			= argin[counter+1];
			A->Celltype_arg    	= true;
			fprintf(out, "Celltype %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Agent") == 0)
		{
			A->Agent			= argin[counter+1];
			A->Agent_arg       	= true;
			fprintf(out, "Agent %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Remodelling") == 0)
		{
			A->Remodelling		= argin[counter+1];
			A->Remodelling_arg 	= true;
			fprintf(out, "Remodelling %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "Mutation") == 0)
        {
            A->Mutation      	= argin[counter+1];
            A->Mutation_arg  	= true;
            fprintf(out, "Mutation %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ISO") == 0)
        {
            A->ISO				= atof(argin[counter+1]);
            A->ISO_arg       	= true;
            fprintf(out, "ISO %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ISO_model") == 0)
        {
            A->ISO_model        = argin[counter+1];
            A->ISO_model_arg    = true;
            fprintf(out, "ISO_model %s ", argin[counter+1]);
            counter++;
        }
		// hAM single cell specific settings
		else if (strcmp(argin[counter], "Environment") == 0 || strcmp(argin[counter], "environment") == 0)
        {
            A->environment          = argin[counter+1];
            A->environment_arg    	= true;
            fprintf(out, "environment %s ", argin[counter+1]);
			if (strcmp(A->environment, "isolated") != 0 && strcmp(A->environment, "intact") != 0)
            {
                printf("ERROR: \"%s\" is not a valid environment argument. Please pass only \"intact\" or \"isolated\"\n\n", A->environment);
                exit(1);
            }
            counter++;
        }
		// End model and cell conditions ====================================//|

		// Applied hyperpolarising current ==================================\\|
		else if (strcmp(argin[counter], "Ihyp") == 0)
        {
            A->AIhyp            = atof(argin[counter+1]);
			A->Ihyp_arg			= true;
            fprintf(out, "Ihyp %s ", argin[counter+1]);
            counter++;
        }
		// End Applied hyperpolarising current ==============================//|

		// Direct control current modidification ============================\\|
		else if (strcmp(argin[counter], "INa_scale") == 0)
        {
            A->GNa              = atof(argin[counter+1]);
			A->GNa_arg				= true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "INa_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INaL_scale") == 0)
        {
            A->GNaL  			= atof(argin[counter+1]);
            A->GNaL_arg  		= true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "INaL_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_scale") == 0)
        {
            A->Gto             = atof(argin[counter+1]);
            A->Gto_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "Ito_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaL_scale") == 0)
        {
            A->GCaL             = atof(argin[counter+1]);
            A->GCaL_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "ICaL_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKur_scale") == 0)
        {
            A->GKur             = atof(argin[counter+1]);
            A->GKur_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "IKur_scale %s ", argin[counter+1]);
            counter++;
        }	
		else if (strcmp(argin[counter], "IKr_scale") == 0)
        {
            A->GKr             = atof(argin[counter+1]);
            A->GKr_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "IKr_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKs_scale") == 0)
        {
            A->GKs             = atof(argin[counter+1]);
            A->GKs_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "IKs_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IK1_scale") == 0)
        {
            A->GK1             = atof(argin[counter+1]);
            A->GK1_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "IK1_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INCX_scale") == 0)
        {
            A->GNCX             = atof(argin[counter+1]);
            A->GNCX_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "INCX_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaP_scale") == 0)
        {
            A->GCaP             = atof(argin[counter+1]);
            A->GCaP_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "ICaP_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INab_scale") == 0)
        {
            A->GNab             = atof(argin[counter+1]);
            A->GNab_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "INab_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICab_scale") == 0)
        {
            A->GCab             = atof(argin[counter+1]);
            A->GCab_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "ICab_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKb_scale") == 0)
        {
            A->GKb             = atof(argin[counter+1]);
            A->GKb_arg         = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "IKb_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INaK_scale") == 0)
        {
            A->GNaK            = atof(argin[counter+1]);
            A->GNaK_arg        = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "INaK_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IClCa_scale") == 0)
        {
            A->GClCa           = atof(argin[counter+1]);
            A->GClCa_arg       = true;
			A->DC_current_mod_arg 	= true;
            fprintf(out, "IClCa_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Jup_scale") == 0)
        {
            A->Gup            = atof(argin[counter+1]);
            A->Gup_arg        = true;
            A->DC_current_mod_arg   = true;
            fprintf(out, "Jup_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Jleak_scale") == 0)
        {
            A->Gleak            = atof(argin[counter+1]);
            A->Gleak_arg        = true;
            A->DC_current_mod_arg   = true;
            fprintf(out, "Jleak_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Jrel_scale") == 0)
        {
            A->Grel            = atof(argin[counter+1]);
            A->Grel_arg        = true;
            A->DC_current_mod_arg   = true;
            fprintf(out, "Jrel_scale %s ", argin[counter+1]);
            counter++;
        }

		else if (strcmp(argin[counter], "INa_va_tau_scale") == 0)
        {
            A->INa_va_tau_scale			= atof(argin[counter+1]);
            A->INa_va_tau_scale_arg		= true;
            A->DC_current_mod_arg   	= true;
            fprintf(out, "INa_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }	
		else if (strcmp(argin[counter], "INa_vi_1_tau_scale") == 0)
        {
            A->INa_vi_1_tau_scale			= atof(argin[counter+1]);
            A->INa_vi_1_tau_scale_arg		= true;
            A->DC_current_mod_arg   	= true;
            fprintf(out, "INa_vi_1_tau_scale %s ", argin[counter+1]);
            counter++;
        }	
		else if (strcmp(argin[counter], "INa_vi_2_tau_scale") == 0)
        {
            A->INa_vi_2_tau_scale			= atof(argin[counter+1]);
            A->INa_vi_2_tau_scale_arg		= true;
            A->DC_current_mod_arg   	= true;
            fprintf(out, "INa_vi_2_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INaL_va_tau_scale") == 0)
        {
            A->INaL_va_tau_scale        = atof(argin[counter+1]);
            A->INaL_va_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "INaL_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INaL_vi_tau_scale") == 0)
        {
            A->INaL_vi_tau_scale        = atof(argin[counter+1]);
            A->INaL_vi_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "INaL_vi_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_va_tau_scale") == 0)
        {
            A->Ito_va_tau_scale        = atof(argin[counter+1]);
            A->Ito_va_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_vi_tau_scale") == 0)
        {
            A->Ito_vi_tau_scale        = atof(argin[counter+1]);
            A->Ito_vi_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_vi_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaL_va_tau_scale") == 0)
        {
            A->ICaL_va_tau_scale        = atof(argin[counter+1]);
            A->ICaL_va_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "ICaL_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaL_vi_tau_scale") == 0)
        {
            A->ICaL_vi_tau_scale        = atof(argin[counter+1]);
            A->ICaL_vi_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "ICaL_vi_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKur_va_tau_scale") == 0)
        {
            A->IKur_va_tau_scale        = atof(argin[counter+1]);
            A->IKur_va_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "IKur_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKur_vi_tau_scale") == 0)
        {
            A->IKur_vi_tau_scale        = atof(argin[counter+1]);
            A->IKur_vi_tau_scale_arg    = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "IKur_vi_tau_scale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKr_va_tau_scale") == 0)
        {
            A->IKr_va_tau_scale        = atof(argin[counter+1]);
            A->IKr_va_tau_scale_arg    = true;
            A->DC_current_mod_arg      = true;
            fprintf(out, "IKr_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }
        else if (strcmp(argin[counter], "IKs_va_tau_scale") == 0)
        {
            A->IKs_va_tau_scale        = atof(argin[counter+1]);
            A->IKs_va_tau_scale_arg    = true;
            A->DC_current_mod_arg      = true;
            fprintf(out, "IKs_va_tau_scale %s ", argin[counter+1]);
            counter++;
        }

		else if (strcmp(argin[counter], "INa_va_shift") == 0)
        {
            A->INa_va_shift        		= atof(argin[counter+1]);
            A->INa_va_shift_arg   		= true;
            A->DC_current_mod_arg      	= true;
            fprintf(out, "INa_va_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INa_vi_shift") == 0)
        {
            A->INa_vi_shift        		= atof(argin[counter+1]);
            A->INa_vi_shift_arg   		= true;
            A->DC_current_mod_arg      	= true;
            fprintf(out, "INa_vi_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "INaL_va_shift") == 0)
        {
            A->INaL_va_shift            = atof(argin[counter+1]);
            A->INaL_va_shift_arg        = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "INaL_va_shift %s ", argin[counter+1]);
            counter++;
        }
        else if (strcmp(argin[counter], "INaL_vi_shift") == 0)
        {
            A->INaL_vi_shift            = atof(argin[counter+1]);
            A->INaL_vi_shift_arg        = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "INaL_vi_shift %s ", argin[counter+1]);
            counter++;
        }	
		else if (strcmp(argin[counter], "Ito_va_ss_shift") == 0)
        {
            A->Ito_va_ss_shift          = atof(argin[counter+1]);
            A->Ito_va_ss_shift_arg      = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_va_ss_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_va_tau_shift") == 0)
        {
            A->Ito_va_tau_shift         = atof(argin[counter+1]);
            A->Ito_va_tau_shift_arg     = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_va_tau_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_vi_ss_shift") == 0)
        {
            A->Ito_vi_ss_shift          = atof(argin[counter+1]);
            A->Ito_vi_ss_shift_arg      = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_vi_ss_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_vi_tau_shift") == 0)
        {
            A->Ito_vi_tau_shift         = atof(argin[counter+1]);
            A->Ito_vi_tau_shift_arg     = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_vi_tau_shift %s ", argin[counter+1]);
            counter++;
		}
		else if (strcmp(argin[counter], "Ito_shift") == 0)
        {
            A->Ito_shift          		= atof(argin[counter+1]);
            A->Ito_shift_arg      		= true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "Ito_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaL_va_ss_shift") == 0)
		{
			A->ICaL_va_ss_shift          = atof(argin[counter+1]);
			A->ICaL_va_ss_shift_arg      = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "ICaL_va_ss_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "ICaL_va_tau_shift") == 0)
		{
			A->ICaL_va_tau_shift         = atof(argin[counter+1]);
			A->ICaL_va_tau_shift_arg     = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "ICaL_va_tau_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "ICaL_vi_ss_shift") == 0)
		{
			A->ICaL_vi_ss_shift          = atof(argin[counter+1]);
			A->ICaL_vi_ss_shift_arg      = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "ICaL_vi_ss_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "ICaL_vi_tau_shift") == 0)
		{
			A->ICaL_vi_tau_shift         = atof(argin[counter+1]);
			A->ICaL_vi_tau_shift_arg     = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "ICaL_vi_tau_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "ICaL_shift") == 0)
        {
            A->ICaL_shift          		= atof(argin[counter+1]);
            A->ICaL_shift_arg      		= true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "ICaL_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKur_va_ss_shift") == 0)
		{
			A->IKur_va_ss_shift          = atof(argin[counter+1]);
			A->IKur_va_ss_shift_arg      = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKur_va_ss_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKur_va_tau_shift") == 0)
		{
			A->IKur_va_tau_shift         = atof(argin[counter+1]);
			A->IKur_va_tau_shift_arg     = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKur_va_tau_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKur_vi_ss_shift") == 0)
		{
			A->IKur_vi_ss_shift          = atof(argin[counter+1]);
			A->IKur_vi_ss_shift_arg      = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKur_vi_ss_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKur_vi_tau_shift") == 0)
		{
			A->IKur_vi_tau_shift         = atof(argin[counter+1]);
			A->IKur_vi_tau_shift_arg     = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKur_vi_tau_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKur_shift") == 0)
        {
            A->IKur_shift          		= atof(argin[counter+1]);
            A->IKur_shift_arg      		= true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "IKur_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKr_va_ss_shift") == 0)
		{
			A->IKr_va_ss_shift          = atof(argin[counter+1]);
			A->IKr_va_ss_shift_arg      = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKr_va_ss_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKr_va_tau_shift") == 0)
		{
			A->IKr_va_tau_shift         = atof(argin[counter+1]);
			A->IKr_va_tau_shift_arg     = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKr_va_tau_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKr_vi_ss_shift") == 0)
        {
            A->IKr_vi_ss_shift         = atof(argin[counter+1]);
            A->IKr_vi_ss_shift_arg     = true;
            A->DC_current_mod_arg       = true;
            fprintf(out, "IKr_vi_ss_shift %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKs_va_ss_shift") == 0)
		{
			A->IKs_va_ss_shift          = atof(argin[counter+1]);
			A->IKs_va_ss_shift_arg      = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKs_va_ss_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IKs_va_tau_shift") == 0)
		{
			A->IKs_va_tau_shift         = atof(argin[counter+1]);
			A->IKs_va_tau_shift_arg     = true;
			A->DC_current_mod_arg       = true;
			fprintf(out, "IKs_va_tau_shift %s ", argin[counter+1]);
			counter++;
		}
		else if (strcmp(argin[counter], "IK1_va_shift") == 0)
        {
            A->IK1_va_shift         = atof(argin[counter+1]);
            A->IK1_va_shift_arg     = true;
            A->DC_current_mod_arg       = true; 
            fprintf(out, "IK1_va_shift %s ", argin[counter+1]);
            counter++;
        }

		else if (strcmp(argin[counter], "Ito_va_ss_kscale") == 0)
        {
            A->Ito_va_ss_kscale         = atof(argin[counter+1]);
            A->Ito_va_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "Ito_va_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "Ito_vi_ss_kscale") == 0)
        {
            A->Ito_vi_ss_kscale         = atof(argin[counter+1]);
            A->Ito_vi_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "Ito_vi_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaL_va_ss_kscale") == 0)
        {
            A->ICaL_va_ss_kscale         = atof(argin[counter+1]);
            A->ICaL_va_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "ICaL_va_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "ICaL_vi_ss_kscale") == 0)
        {
            A->ICaL_vi_ss_kscale         = atof(argin[counter+1]);
            A->ICaL_vi_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "ICaL_vi_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKur_va_ss_kscale") == 0)
        {
            A->IKur_va_ss_kscale         = atof(argin[counter+1]);
            A->IKur_va_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "IKur_va_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKur_vi_ss_kscale") == 0)
        {
            A->IKur_vi_ss_kscale         = atof(argin[counter+1]);
            A->IKur_vi_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "IKur_vi_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKr_va_ss_kscale") == 0)
        {
            A->IKr_va_ss_kscale         = atof(argin[counter+1]);
            A->IKr_va_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "IKr_va_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKr_vi_ss_kscale") == 0)
        {
            A->IKr_vi_ss_kscale         = atof(argin[counter+1]);
            A->IKr_vi_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "IKr_vi_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		else if (strcmp(argin[counter], "IKs_va_ss_kscale") == 0)
        {
            A->IKs_va_ss_kscale         = atof(argin[counter+1]);
            A->IKs_va_ss_kscale_arg     = true;
            A->DC_current_mod_arg       = true;  
            fprintf(out, "IKs_va_ss_kscale %s ", argin[counter+1]);
            counter++;
        }
		// End Direct control current modidification ========================//|

		// Valid argument check =============================================\\|
		else 
		{
			printf("ERROR: \"%s\" is not a valid argument.\n", argin[counter]);
			printf("Please select from the following options:\n\n");
			printf("\tReference [text]\tVclamp [On/Off]\t{Read/Write}_state [On/Off]\n\n");
			printf("[Simulation settings]:\n");
			printf("\tBCL [x (ms)]\tTotal_time [x (ms)]\tPaced_time [x (ms)]\tNBeats [n]\tdt [x (ms)]\n");
			printf("\tS2  [x (ms)]\tNS2 [n]\n\n");
			printf("[Model and cell conditions]:\n");
			printf("\tModel [text]\tCelltype [text]\tAgent [text]\tRemodelling [text]\tISO [x (0-1uM)]\tISO_model [text]\n");
			printf("\tIhyp [x (pA/pF)]\n");
			printf("\tenvironment [intact/isolated]\n\n");
			printf("[Direct control current modification]:\n");
			printf("\t{INa/INaL/Ito/ICaL/IKur/IKr/IKs/IK1/INCX/ICaP/INab/ICab/IKb/INaK/IClCa}_scale [x]\n\n");
			printf("\t{Jup/Jleak/Jrel}_scale [x]\n\n");
			printf("\t{INa_va/INa_vi_1/INa_vi_2/INaL_va/INaL_vi/Ito_va/Ito_vi/ICaL_va/ICaL_vi/IKur_va/IKur_vi/IKr_va/IKs_va}_tau_scale [x]\n\n");
			printf("\t{INa_va/INa_vi/INaL_va/INaL_vi/Ito_va_ss/Ito_va_tau/Ito_vi_ss/Ito_vi_tau}_shift [x (mV)]\n\n");
			printf("\t{ICaL_va_ss/ICaL_va_tau/ICaL_vi_ss/ICaL_vi_tau}_shift [x (mV)]\n\n");
			printf("\t{IKur_va_ss/IKur_va_tau/IKur_vi_ss/IKur_vi_tau}_shift [x (mV)]\n\n");
			printf("\t{IKr_va_ss/IKr_va_tau/IKr_vi_ss/IKs_va_ss/IKs_va_tau/IK1_va}_shift [x (mV)]\n\n");
			printf("\t{Ito_va/Ito_vi/ICaL_va/ICaL_vi/IKur_va/IKur_vi/IKr_va/IKr_vi/IKs_va}_ss_kscale [x]\n\n");

			if (strcmp(Version, "Tissue_native") == 0 || strcmp(Version, "Tissue_integrated") == 0)
			{
				printf("Additional tissue model options:\n");
				printf("\tSpatial_output_interval [int ms]\n");
				printf("\tTissue_order	[1D/2D/3D/3D_geo]\t Tissue_model [basic, ...]\t Tissue_type [homogeneous/heterogeneous]\n");
				printf("\tOrientation_type [isotropic/anisotropic/orthotropic/uniform/]\t D_uniformity [uniform, non_uniform]\n");
				printf("\tStimulus_location_type [edge/centre]\n");
				printf("\tDscale [double]\n");
			}

			if (strcmp(Version, "Single_cell_3D") == 0)
            {
                printf("Additional spatial cell model model options:\n");
				printf("\tSpatial_output_interval [int ms]\n");
				printf("\tCell_size [string]\tSim_cell_size [string]\tCai [uM]\tCaSR [uM]\n");
				printf("\tDetub [On/Off]\tTT_map [string]\n");
			}
			exit(1);
		}
		// End Valid argument check =========================================//|

		counter++;
	}
	fprintf(out, "\n\n");
	// End read arguments into struct
	fclose(out);
}
// End set arguments ==================================================================//|


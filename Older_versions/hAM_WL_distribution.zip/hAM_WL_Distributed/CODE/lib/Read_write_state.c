// Read/write state file ==================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include "Structs.h"
#include "Read_write_state.h"

// Functions which write the state ====================================================\\|
void Write_state_variables_native(State_variables s, FILE *out)
{
	fprintf(out, "%lf\t", s.Vm);
	fprintf(out, "%lf\t", s.INa_va);
	fprintf(out, "%lf\t", s.INa_vi_1);
	fprintf(out, "%lf\t", s.INa_vi_2);
	fprintf(out, "%lf\t", s.INaL_va);
	fprintf(out, "%lf\t", s.INaL_vi);
	fprintf(out, "%lf\t", s.Ito_va);
	fprintf(out, "%lf\t", s.Ito_vi);
	fprintf(out, "%lf\t", s.Ito_vi_s);
	fprintf(out, "%lf\t", s.Ito_vi_3);
	fprintf(out, "%lf\t", s.ICaL_va);
	fprintf(out, "%lf\t", s.ICaL_vi);
	fprintf(out, "%lf\t", s.ICaL_vi_s);
	fprintf(out, "%lf\t", s.ICaL_ci);
	fprintf(out, "%lf\t", s.ICaL_ci_j);
	fprintf(out, "%lf\t", s.IKur_va);
	fprintf(out, "%lf\t", s.IKur_vi);
	fprintf(out, "%lf\t", s.IKr_va);
	fprintf(out, "%lf\t", s.IKr_vi);
	fprintf(out, "%lf\t", s.IKs_va);		// 20

	fprintf(out, "%lf\t", s.Cai);
	fprintf(out, "%lf\t", s.Cai_j);
	fprintf(out, "%lf\t", s.Cai_sl);
	fprintf(out, "%lf\t", s.CajSR);
	fprintf(out, "%lf\t", s.CanSR);			// 25

	fprintf(out, "%lf\t", s.Nai);
	fprintf(out, "%lf\t", s.Nai_j);
	fprintf(out, "%lf\t", s.Nai_sl);
	fprintf(out, "%lf\t", s.Ki);			// 29

	fprintf(out, "%lf\t", s.Cao);
	fprintf(out, "%lf\t", s.Nao);
	fprintf(out, "%lf\t", s.Ko);			// 32

	fprintf(out, "%lf\t", s.RyRo);			
	fprintf(out, "%lf\t", s.RyRi);
	fprintf(out, "%lf\t", s.RyRr);
	fprintf(out, "%lf\t", s.Myo_c);
	fprintf(out, "%lf\t", s.Myo_m);
	fprintf(out, "%lf\t", s.Tn_CHc);
	fprintf(out, "%lf\t", s.Tn_CHm);
	fprintf(out, "%lf\t", s.Tn_CL);			// 40

	fprintf(out, "%lf\t", s.cmdn);
	fprintf(out, "%lf\t", s.trpn);
	fprintf(out, "%lf\t", s.csqn);			// 43

	fprintf(out, "%lf\t", s.CaCal);
	fprintf(out, "%lf\t", s.Catrop);
	fprintf(out, "%lf\t", s.Camg);
	fprintf(out, "%lf\t", s.Mgmg);
	fprintf(out, "%lf\t", s.CaCalse);		// 48

	// Empty states - used such that new state variables can be added, and total number of elements is same such that files don't need to be reproduced
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state
	fprintf(out, "%lf\t", 0.0);  // replace 0 with new state // 58
}
// End functions which write the state ================================================//|

// Functions which read the state =====================================================\\|
void Read_state_variables_native(State_variables *s, FILE *in)
{
	double temp;  // variable to read empty states into

	fscanf(in, "%lf\t", &s->Vm);
	fscanf(in, "%lf\t", &s->INa_va);
	fscanf(in, "%lf\t", &s->INa_vi_1);
	fscanf(in, "%lf\t", &s->INa_vi_2);
	fscanf(in, "%lf\t", &s->INaL_va);
	fscanf(in, "%lf\t", &s->INaL_vi);
	fscanf(in, "%lf\t", &s->Ito_va);
	fscanf(in, "%lf\t", &s->Ito_vi);
	fscanf(in, "%lf\t", &s->Ito_vi_s);
	fscanf(in, "%lf\t", &s->Ito_vi_3);
	fscanf(in, "%lf\t", &s->ICaL_va);
	fscanf(in, "%lf\t", &s->ICaL_vi);
	fscanf(in, "%lf\t", &s->ICaL_vi_s);
	fscanf(in, "%lf\t", &s->ICaL_ci);
	fscanf(in, "%lf\t", &s->ICaL_ci_j);
	fscanf(in, "%lf\t", &s->IKur_va);
	fscanf(in, "%lf\t", &s->IKur_vi);
	fscanf(in, "%lf\t", &s->IKr_va);
	fscanf(in, "%lf\t", &s->IKr_vi);
	fscanf(in, "%lf\t", &s->IKs_va);		// 20

	fscanf(in, "%lf\t", &s->Cai);
	fscanf(in, "%lf\t", &s->Cai_j);
	fscanf(in, "%lf\t", &s->Cai_sl);
	fscanf(in, "%lf\t", &s->CajSR);
	fscanf(in, "%lf\t", &s->CanSR);			// 25

	fscanf(in, "%lf\t", &s->Nai);
	fscanf(in, "%lf\t", &s->Nai_j);
	fscanf(in, "%lf\t", &s->Nai_sl);
	fscanf(in, "%lf\t", &s->Ki);			// 29

	fscanf(in, "%lf\t", &s->Cao);
	fscanf(in, "%lf\t", &s->Nao);
	fscanf(in, "%lf\t", &s->Ko);			// 32

	fscanf(in, "%lf\t", &s->RyRo);
	fscanf(in, "%lf\t", &s->RyRi);
	fscanf(in, "%lf\t", &s->RyRr);
	fscanf(in, "%lf\t", &s->Myo_c);
	fscanf(in, "%lf\t", &s->Myo_m);
	fscanf(in, "%lf\t", &s->Tn_CHc);
	fscanf(in, "%lf\t", &s->Tn_CHm);
	fscanf(in, "%lf\t", &s->Tn_CL);			// 40

	fscanf(in, "%lf\t", &s->cmdn);
	fscanf(in, "%lf\t", &s->trpn);
	fscanf(in, "%lf\t", &s->csqn);			// 43

	fscanf(in, "%lf\t", &s->CaCal);
	fscanf(in, "%lf\t", &s->Catrop);
	fscanf(in, "%lf\t", &s->Camg);
	fscanf(in, "%lf\t", &s->Mgmg);
	fscanf(in, "%lf\t", &s->CaCalse);		// 48

	// Empty states - used such that new state variables can be added, and total number of elements is same such that files don't need to be reproduced
	fscanf(in, "%lf\t", &temp);				// replace temp with new state
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);
	fscanf(in, "%lf\t", &temp);				// 58
}
// End functions which read the state =================================================//|

// Functions which set filename and call write/read state =============================\\|
void Write_state_single_cell_native(State_variables s, Cell_parameters p, int BCL, const char * PATH, const char *Model)
{
	FILE *out;
	char *string = (char*)malloc(500);

	sprintf(string, "%s/State_files/Single_cell/Native_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_env_%s.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, p.environment);

	out = fopen(string, "wt");

	if (out == NULL)
	{
		printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
		exit(1);
	}

	Write_state_variables_native(s, out);
	fclose(out);
}

void Read_state_single_cell_native(State_variables *s, Cell_parameters p, int BCL, const char * PATH, const char *Model)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/Single_cell/Native_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_env_%s.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, p.environment);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Read_state_variables_native(s, in);
    fclose(in);
}

void Write_state_single_cell_integrated(State_variables s, Cell_parameters p, int BCL, const char * PATH, const char *Model)
{
    FILE *out;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/Single_cell/Integrated_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_env_%s.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, p.environment);

    out = fopen(string, "wt");

    if (out == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Write_state_variables_native(s, out);
    fclose(out);
}

void Read_state_single_cell_integrated(State_variables *s, Cell_parameters p, int BCL, const char * PATH, const char *Model)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/Single_cell/Integrated_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_env_%s.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, p.environment);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Read_state_variables_native(s, in);
    fclose(in);
}

void Write_state_single_cell_integrated_0D(State_variables s, Cell_parameters p, int BCL, const char * PATH, const char *Model)
{
    FILE *out;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/Single_cell/Integrated_0D_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_env_%s.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, p.environment);

    out = fopen(string, "wt");

    if (out == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Write_state_variables_native(s, out);
    fclose(out);
}

void Read_state_single_cell_integrated_0D(State_variables *s, Cell_parameters p, int BCL, const char * PATH, const char *Model)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/Single_cell/Integrated_0D_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_env_%s.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, p.environment);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Read_state_variables_native(s, in);
    fclose(in);
}


void Write_state_phase(State_variables s, Cell_parameters p, int BCL, const char * PATH, const char *Model, int phase)
{
	FILE *out;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/phase_files/Native_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_phase_%d.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, phase);

    out = fopen(string, "wt");

    if (out == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Write_state_variables_native(s, out);
    fclose(out);
}

void Read_state_phase(State_variables *s, Cell_parameters p, int BCL, const char * PATH, const char *Model, int phase)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/phase_files/Native_model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_phase_%d.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, phase);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Read_state_variables_native(s, in);
    fclose(in);
}

void Write_state_phase_0D(State_variables s, Cell_parameters p, int BCL, const char * PATH, const char *Model, int phase)
{
    FILE *out;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/phase_files/Integrated_0D__model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_phase_%d.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, phase);

    out = fopen(string, "wt");

    if (out == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Write_state_variables_native(s, out);
    fclose(out);
}

void Read_state_phase_0D(State_variables *s, Cell_parameters p, int BCL, const char * PATH, const char *Model, int phase)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/State_files/phase_files/Integrated_0D__model_%s_BCL_%d_region_%s_ISO_%.2f_remodelling_%s_drug_%s_mut_%s_phase_%d.state", PATH, Model, BCL, p.Celltype, p.ISO, p.Remodelling, p.Agent, p.Mutation, phase);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot create state file %s\t does the folder exist?? Is your path %s correct?\n", string, PATH);
        exit(1);
    }

    Read_state_variables_native(s, in);
    fclose(in);
}


// End Functions which set filename and call write/read state =========================//|


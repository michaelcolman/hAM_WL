// TEMPLATE FOR ADDING A NEW MODEL ========================  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// PLEASE REFER TO ORIGINAL PAPER FOR THEIR OWN DISCLAIMER=  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include "Model.h"
#include "Structs.h"

// Parameters and specific settings =============================================================\\|
// Set model dependent parameters 
// If your model does not inhereted from a cell model already included, define all parameters:
void set_parameters_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Capacitance and cell structure
	//p->Cm				= X;		// pF
	//p->Vcell			= Y;	// um^3

	// Concentrations (constant OR initial condition)
	//p->Nao				= X;		// mM
	//p->Cai				= X;		// mM

	// Current parameters
	//p->gNa				= X; 		// s/mF

	//p->INCX_bar			= Z;		// pA/pF

	// Stimulus parameters (if different to default)
	//p->stimduration 	= 5.0;      // ms
	//p->stimmag      	= -13.5;    // pA/pF

	// Default celltype
	//p->Celltype			= "something";
}
// ============= OR ==============\\|
// If your model does inheret from a cell model already include, define only different parameters here
void update_parameters_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Updated parameters
	//p->gto                = X;        // s/mF
}

// Initial conditions
void initial_conditions_native_speciesCELL_MODEL(State_variables *s, Cell_parameters p)
{
	// Define ICs for ALL state variables used in the model
	//s->Vm      			= X;
	//s->INa_va  			= Y;
	//s->INa_vi_1			= Z; 

	// Ca handling
	//s->CajSR				= X;		// mM
	//s->RyRo				= X;

	// Assign state from param (even if constant)
	// Ensure the ICs for all dynamic concenstrations is set as a parameter
	//s->Nai				= p.Nai;
}
// end Parameters and specific settings =========================================================//|

// Heterogeneity and modulation =================================================================\\|
// Celltype/Heterogeneity
void set_celltype_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	// NOTE:: Ensure setting only model-specific conditions here - others defined in Model.c

	if (strcmp(p->Celltype, "default") == 0); 	// Do nothing for baseline celltype
	// testing exmaple illustration of model-specific implementation
	else if (strcmp(p->Celltype, "test") == 0) 
	{
		p->Gto				*= 2; 		// Scale factor = Multiplies previous settings
		p->gKur				= 0.003;	// Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale	*= 1.25;	// Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift	+= 5;		// Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale	*= 0.75;	// Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup				*= 2;		// Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new celltypes here: else if (strcmp(p->Celltype, "X") == 0) {   }
	else 
	{
		printf("ERROR: \"%s\" is not a valid Celltype for the speciesCELL_MODEL models. Please check Model.c and Model_speciesCELL_MODEL.cpp for options\n\n", p->Celltype);
		exit(1);
	}
}

// ISO
void set_modulation_ISO_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	// "p->ISO" is concentration of ISO; "p-ISO_model" is the ISO model to be applied

	// NOTE:: Ensure setting only model-specific conditions here - others defined in Model.c

	// testing exmaple illustration of model-specific implementation
	if (strcmp(p->ISO_model, "default") == 0)
	{
		p->Gto				*= (1.0 + p->ISO*2);	// At saturating solution, x3, at ISO = 0, x1
		p->IKr_va_ss_kscale	*= (1.0 - p->ISO*0.5);  // At saturating solution, x0.5, at ISO = 0, x1
		p->ICaL_vi_ss_shift	+= (1.0 + p->ISO*5);	// At saturating solution, + 5, at ISO = 0, +/-0
		p->Gup				*= (1.0 + p->ISO*2);    // At saturating solution, x3, at ISO = 0, x1
	}
	// Add new ISO_models here: else if (strcmp(p->ISO_model, "X") == 0) {   }
	else
    {
        printf("ERROR: \"%s\" is not a valid ISO model for the speciesCELL_MODEL models. Please check Model.c and Model_speciesCELL_MODEL.cpp for options\n\n", p->ISO_model);
        exit(1);
    }
}

// Pharmacological modulation
void set_modulation_Agent_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	// Note: Many Agents will be commong to multiple or all models, and thus should be defined in
	// lib/Model.c. Only model-specific drugs should be here

	if (strcmp(p->Agent, "none") == 0); // do nothing
	// testing exmaple illustration of model-specific implementation
	else if (strcmp(p->Agent, "test") == 0) 
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new pharmacological agent here: else if (strcmp(p->Agent, "X") == 0) {   }
	else
	{
		printf("ERROR: \"%s\" is not a valid pharmacological agent for the speciesCELL_MODEL models. Please check Model.c and Model_speciesCELL_MODEL.cpp for options\n\n", p->Agent);
		exit(1);
	}
}

// Remodelling
void set_modulation_Remodelling_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	// NOTE:: Ensure setting only model-specific conditions here - others defined in Model.c

	if (strcmp(p->Remodelling, "none") == 0); // do nothing
	// testing exmaple illustration of model-specific implementation
	else if (strcmp(p->Remodelling, "test") == 0)
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new Remodelling here: else if (strcmp(p->Remodelling, "X") == 0) {   }
	else
	{
		printf("ERROR: \"%s\" is not a valid Remodelling model for the speciesCELL_MODEL models. Please check Model.c and Model_speciesCELL_MODEL.cpp for options\n\n", p->Remodelling);
		exit(1);
	}
}

// Mutation
void set_modulation_Mutation_native_speciesCELL_MODEL(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	// NOTE: Many mutations may be common to multiple models and should be in Model.c
	// Add only a model-specific remodelling here

	if (strcmp(p->Mutation, "none") == 0); // do nothing
	// testing exmaple illustration of model-specific implementation
	else if (strcmp(p->Mutation, "test") == 0)
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new mutation here: else if (strcmp(p->mutation, "X") == 0) {   }
	else
	{
		printf("ERROR: \"%s\" is not a valid Mutation model for the speciesCELL_MODEL models. Please check Model.c and Model_speciesCELL_MODEL.cpp for options\n\n", p->Mutation);
		exit(1);
	}
}
// End heterogeneity and modulation =============================================================//|

// Compute model functions ======================================================================\\|
// Your model may have more or fewer currents than this template - just follow the procedure and add/delete as appropriate
void compute_model_speciesCELL_MODEL_native(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	compute_reversal_potentials(p, var, s);
	set_gate_rates_speciesCELL_MODEL_native(p, var, Vm, s->Cai);
	update_gating_variables_speciesCELL_MODEL_native(p, var, s, Vm, dt);
	compute_Itot_speciesCELL_MODEL_native(p, var, s, Vm);
	comp_homeostasis_speciesCELL_MODEL(p, var, s, Vm, dt);
}

void set_gate_rates_speciesCELL_MODEL_native(Cell_parameters p, Model_variables *var, double Vm, double Cai)
{
	// Call only current you need
	//set_INa_LR_rates(p, var, Vm);					// lib/Model.c
	//set_Ito_speciesCELL_MODEL_rates(p, var, Vm);
	//set_IKur_speciesCELL_MODEL_rates(p, var, Vm);
	//set_IKs_speciesCELL_MODEL_rates(p, var, Vm);
	//set_IKr_speciesCELL_MODEL_rates(p, var, Vm);
	//set_IK1_speciesCELL_MODEL_variables(p, var, Vm);
	//set_ICaL_speciesCELL_MODEL_rates(p, var, Vm, Cai);
}

void update_gating_variables_speciesCELL_MODEL_native(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	//update_gates_INa_LR(p, var, s, Vm, dt); 		// lib/Model.c
	//update_gates_IKs_speciesCELL_MODEL(p, var, s, Vm, dt);
	//update_gates_IKr_speciesCELL_MODEL(p, var, s, Vm, dt);
	//update_gates_ICaL_speciesCELL_MODEL(p, var, s, Vm, dt);
	//update_gates_Ito_speciesCELL_MODEL(p, var, s, Vm, dt);
	//update_gates_IKur_speciesCELL_MODEL(p, var, s, Vm, dt);
}

void compute_Itot_speciesCELL_MODEL_native(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
	var->Itot   = 0;

	//compute_INa_LR(p, var, s, Vm);					// lib/Model.c
	//compute_Ito_speciesCELL_MODEL(p, var, s, Vm);
	//compute_ICaL_speciesCELL_MODEL(p, var, s, Vm);
	//compute_IKur_speciesCELL_MODEL(p, var, s, Vm);
	//compute_IKr_speciesCELL_MODEL(p, var, s, Vm);
	//compute_IKs_speciesCELL_MODEL(p, var, s, Vm);
	//compute_IK1_speciesCELL_MODEL(p, var, s, Vm);
	//compute_INCX_speciesCELL_MODEL(p, var, s, Vm);
	//compute_INaK_speciesCELL_MODEL(p, var, s, Vm);
	//compute_ICaP_speciesCELL_MODEL(p, var, s, Vm);
	//compute_INab_speciesCELL_MODEL(p, var, s, Vm);
	//compute_ICab_speciesCELL_MODEL(p, var, s, Vm);

	//var->Itot   = var->INa + var->Ito + var->IK1 + var->ICaL + var->IKur + var->INCX + var->INaK + var->ICaP + var->INab + var->ICab + var->IKr + var->IKs;
}
// End Compute model functions ==================================================================//|

// Compute variables for outputs ================================================================\\|
void compute_and_output_current_functions_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, char const *directory)
{
	// Create files for each current
	char * filename       = (char*)malloc(100);
	FILE * INa_out;
	FILE * Ito_out;
	FILE * IKur_out;
	FILE * ICaL_out;
	FILE * IKr_out;
	FILE * IKs_out;
	sprintf(filename, "%s/Functions/INa.dat", directory);
	INa_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/Ito.dat", directory);
	Ito_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/IKur.dat", directory);
	IKur_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/ICaL.dat", directory);
	ICaL_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/IKr.dat", directory);
	IKr_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/IKs.dat", directory);
	IKs_out = fopen(filename, "wt");

	// Loop over voltages and calculate functions
	double Vm;
	for (Vm = -100; Vm < 100; Vm+=1.0)
	{
		set_gate_rates_speciesCELL_MODEL_native(p, var, Vm, p.Cai);	// Be sure to call your function here. 

		// You may need to adjust what is output here depending on components of the model
		fprintf(INa_out,    "%f %f %f %f %f %f %f\n",   Vm, var->INa_va_al, var->INa_va_bet, var->INa_vi_1_al, var->INa_vi_1_bet, var->INa_vi_2_al, var->INa_vi_2_bet);
		fprintf(Ito_out,    "%f %f %f %f %f\n",      	Vm, var->Ito_va_ss, var->Ito_va_tau, var->Ito_vi_ss, var->Ito_vi_tau);
		fprintf(ICaL_out,   "%f %f %f %f %f %f\n",      Vm, var->ICaL_va_ss, var->ICaL_va_tau, var->ICaL_vi_ss, var->ICaL_vi_tau, var->ICaL_vi_s_tau);
		fprintf(IKur_out,   "%f %f %f %f %f\n",         Vm, var->IKur_va_ss, var->IKur_va_tau, var->IKur_vi_ss, var->IKur_vi_tau);
		fprintf(IKr_out,    "%f %f %f %f\n",            Vm, var->IKr_va_ss, var->IKr_va_tau, var->IKr_vi_ti);
		fprintf(IKs_out,    "%f %f %f\n",               Vm, var->IKs_va_ss, var->IKs_va_tau);

	}

	fclose(INa_out);
	fclose(Ito_out);
	fclose(IKur_out);
	fclose(ICaL_out);
	fclose(IKr_out);
	fclose(IKs_out);
}
// end Compute variables for outputs ============================================================//|

// Current formulations =========================================================================\\|
// INa ======================================================================\\|
// Identical to that of LR model, found in lib/Model.c or new formulation here
// End INa ==================================================================//|

// Ito ======================================================================\\|
void set_Ito_speciesCELL_MODEL_rates(Cell_parameters p, Model_variables *var, double Vm)
{
	// First, assign local voltages for each gate and type such that shifts can be applied by MODIFIERS
	//e.g.:
	//double Vm_ac_ss         = Vm - p.Ito_va_ss_shift;   // Voltage modified by shift applied to activation steady state
	//double Vm_inac_ss       = Vm - p.Ito_vi_ss_shift;   // Voltage modified by shift applied to inactivation steady state
	//double Vm_ac_tau        = Vm - p.Ito_va_tau_shift;  // Voltage modified by shift applied to activation time constant (and rates as they only define tau)
	//double Vm_inac_tau      = Vm - p.Ito_vi_tau_shift;  // Voltage modified by shift applied to inactivation time constant
	// Be sure to use the relevant local voltage in the correct functions

	// Voltage activation (va), voltage inactivation (vi)
	// Can define in many ways:
	// Steady state, regular sigmoid: 
		//var->Ito_va_ss			= sidmoid(Vm_ac_ss, V1/2m K*p.Ito_va_ss_kscale);
	// Steadt state, not regular sigmoid:
		//var->Ito_va_ss		= f(Vm_ac_ss, p.Ito_va_ss_kscale)

	// alpha and beta
		// var->Ito_va_al 	= f(Vm_ac_tau)	// Vm_tau used for tau OR alpha/beta
		// var->Ito_vi_b 	= f(Vm_inac_tau)

	// and don't forget to scale the time-constants!
	//var->Ito_va_tau			*= p.Ito_va_tau_scale;
	//var->Ito_vi_tau			*= p.Ito_vi_tau_scale;
}

void update_gates_Ito_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	// Update the gates, using rush_larsen, forward Euler, or other
	//s->Ito_va              = rush_larsen(s->Ito_va, var->Ito_va_ss, var->Ito_va_tau, dt);
	//s->Ito_vi              += dt*(differential)
}

void compute_Ito_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
	// And finally, compute the actual current
	//var->Ito				= p.gto * pow(s->Ito_va, 3) * s->Ito_vi * (Vm - var->EK);
	// Don't forget to multiply by scale factor!!
	//var->Ito				*= p.Gto;
}
// End Ito ==================================================================//|

// ICaL =====================================================================\\|
// ICaL can be written exactly as above for Ito. However, if there are intentions
// to integrate the new model with the "integrated" calcium handling system
// e.g. for spatial cell models or spontaneous release functions, please 
// follow the procedure below; voltage-dependent gates have their own
// functions so can be called elsewhere
void set_ICaL_speciesCELL_MODEL_rates(Cell_parameters p, Model_variables *var, double Vm, double Cai)
{
    //double Vm_ac_ss         = Vm - p.ICaL_va_ss_shift;    // Voltage modified by shift applied to activation steady state
    //double Vm_inac_ss       = Vm - p.ICaL_vi_ss_shift;    // Voltage modified by shift applied to inactivation steady state
    //double Vm_ac_tau        = Vm - p.ICaL_va_tau_shift;   // Voltage modified by shift applied to activation time constant
    //double Vm_inac_tau      = Vm - p.ICaL_vi_tau_shift;   // Voltage modified by shift applied to inactivation time constant

	//set_ICaL_speciesCELL_MODEL_va_rates(p, &var->ICaL_va_ss, &var->ICaL_va_tau, Vm_ac_ss, Vm_ac_tau, p.ICaL_va_ss_kscale);
	//var->ICaL_va_tau        *= p.ICaL_va_tau_scale;

	//set_ICaL_speciesCELL_MODEL_vi_rates(p, &var->ICaL_vi_ss, &var->ICaL_vi_tau, Vm_inac_ss, Vm_inac_tau, p.ICaL_vi_ss_kscale);
	//var->ICaL_vi_tau        *= p.ICaL_vi_tau_scale;

	// calcium inactivation
	//var->ICaL_ci_ss		= X
	//var->ICaL_ci_tau		= Y
}

void set_ICaL_speciesCELL_MODEL_va_rates(Cell_parameters p, double *va_ss, double *va_tau, double Vm_ss, double Vm_tau, double kscale)
{
    //*va_ss        = sigmoid(Vm_ss, V1/2, -gradient*kscale);  // V, V1/2, k 1/(1+exp((V-V1/2)/k)
	//*va_tau  		= f(Vm_tau)
}

void set_ICaL_speciesCELL_MODEL_vi_rates(Cell_parameters p, double *vi_ss, double *vi_tau, double Vm_ss, double Vm_tau, double kscale)
{
    //*vi_ss        = sigmoid(Vm_ss, V1/2, gradient*kscale);  // V, V1/2, k 1/(1+exp((V-V1/2)/k)
	//*vi_tau  		= f(Vm_tau)
}

// Everything else follows the same format
void update_gates_ICaL_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	//s->ICaL_va       		= rush_larsen(s->ICaL_va, var->ICaL_va_ss, var->ICaL_va_tau, dt);
    //s->ICaL_vi    			= rush_larsen(s->ICaL_vi, var->ICaL_vi_ss, var->ICaL_vi_tau, dt);
    //s->ICaL_ci    			= rush_larsen(s->ICaL_ci, var->ICaL_ci_ss, var->ICaL_ci_tau, dt);
}

void compute_ICaL_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
	//var->ICaL   			= p.gCaL * s->ICaL_va * s->ICaL_vi * s->ICaL_ci * (Vm - 65);
    //var->ICaL 				*= p.GCaL;
}
// End ICaL =================================================================//|

// IKur =====================================================================\\|
void set_IKur_speciesCELL_MODEL_rates(Cell_parameters p, Model_variables *var, double Vm)
{
	//double Vm_ac_ss         = Vm - p.IKur_va_ss_shift;   // Voltage modified by shift applied to activation steady state
	//double Vm_inac_ss       = Vm - p.IKur_vi_ss_shift;   // Voltage modified by shift applied to inactivation steady state
	//double Vm_ac_tau        = Vm - p.IKur_va_tau_shift;  // Voltage modified by shift applied to activation time constant
	//double Vm_inac_tau      = Vm - p.IKur_vi_tau_shift;  // Voltage modified by shift applied to inactivation time constant

	// Dynamic conductance factor
	//var->IKur_dynamic_g		= 0.005+0.05/(1+exp(-(Vm-15)/13));
}

void update_gates_IKur_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
}

void compute_IKur_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
	//var->IKur 				= var->IKur_dynamic_g * pow(s->IKur_va, 3) * s->IKur_vi * (Vm - var->EK);
	//var->IKur				*= p.GKur;
}
// End IKur =================================================================//|

// IKr ======================================================================\\|
void set_IKr_speciesCELL_MODEL_rates(Cell_parameters p, Model_variables *var, double Vm)
{
	//double Vm_ac_ss         = Vm - p.IKr_va_ss_shift;   // Voltage modified by shift applied to activation steady state
	//double Vm_ac_tau        = Vm - p.IKr_va_tau_shift;  // Voltage modified by shift applied to activation time constant

	// Time-independant gate
	//var->IKr_vi_ti          = sigmoid(Vm_ac_ss, -15, 22.4);
}

void update_gates_IKr_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
}

void compute_IKr_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
}
// End IKr ==================================================================//|

// IKs ======================================================================\\|
void set_IKs_speciesCELL_MODEL_rates(Cell_parameters p, Model_variables *var, double Vm)
{
	//double Vm_ac_ss         = Vm - p.IKs_va_ss_shift;   // Voltage modified by shift applied to activation steady state
	//double Vm_ac_tau        = Vm - p.IKs_va_tau_shift;  // Voltage modified by shift applied to activation time constant
}

void update_gates_IKs_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
}

void compute_IKs_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
}
// End IKs ==================================================================//|

// IK1 ======================================================================\\|
void set_IK1_speciesCELL_MODEL_variables(Cell_parameters p, Model_variables *var, double Vm)
{
    //double Vm_in        = Vm - p.IK1_va_shift;
    //var->IK1_va_ti      = (1.0 + exp(0.07*(Vm_in-(-80))));
}

void compute_IK1_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
    //var->IK1               = p.gK1 * (Vm - var->EK)/var->IK1_va_ti;
    //var->IK1               *= p.GK1;
}
// End IK1 ==================================================================//|

// Ca2+ handling, background and pump currents ==============================\\|
// INCX
void compute_INCX_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
	// Create some local variables to make equation easier to read
	//double Cai 		 	= s->Cai;
	//double Cao			= s->Cao;
	//double Nai			= s->Nai;
	//double Nao			= s->Nao;

	//var->INCX			= f(Cai, Cao, Nai, Nao, Vm....)
	//var->INCX			*= p.GNCX;
}

// INaK
void compute_INaK_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
}

// ICaP
void compute_ICaP_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
}

// INab
void compute_INab_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
}

// ICab
void compute_ICab_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
}
// End Ca2+ handling currents ===============================================//|

// Homeostasis ==============================================================\\|
void comp_homeostasis_speciesCELL_MODEL(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	// Differentials
	//var->dNai 				= f(Cm, Ix)
	//var->dCai 				= f(Cm, Ca, Ix)

	// Jrel, SERCA, transfer equations etc etc

	// Update concentrations
	//s->Nai  				+= dt* var->dNai;
	//s->Cai  				+= dt* var->dCai;
}
// End Homeostasis ==========================================================//|
// End Current formulations =====================================================================//|

// Outputs file ===========================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include "Structs.h"
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <cstring>

// Common - screen and file outputs =============================================================\\|
// Final properties to file and screen
void output_properties_to_screen(const char * log_reference, Model_variables var, Simulation_parameters Sim)
{
	// Screen Outputs
	printf("Final two beat properties ****\n");
	printf("\tFINAL beat\t\t:  APD_-70mV = %.2f ms | dv/dt_max = %.2f mV/ms\n", var.APD_t, var.dvdt_max);
	printf("\tPENULTIMATE beat\t:  APD_-70mV = %.2f ms | dv/dt_max = %.2f mV/ms\n", var.APD_t_prev, var.dvdt_max_prev);
	printf("\tFINAL beat\t\t:  APD_30    = %.2f ms  | APD_50    = %.2f ms | APD_70    = %.2f ms | APD_90 = %.2f ms\n", var.APD_p[2], var.APD_p[4], var.APD_p[6], var.APD_p[8]);
	printf("\tPENULTIMATE beat\t:  APD_30    = %.2f ms  | APD_50    = %.2f ms | APD_70    = %.2f ms | APD_90 = %.2f ms\n", var.APD_p_prev[2], var.APD_p_prev[4], var.APD_p_prev[6], var.APD_p_prev[8]);
	printf("\tFINAL beat\t\t:  Vmin      = %.2f mV | Vmax      = %.2f mV  | Amplitude = %.2f mV\n", var.Vmin_prev, var.Vmax, var.Vamp);   // Vmin prev as want Vmin just before final stimulus applied, not at end of simulation
	printf("\tPENULTIMATE beat\t:  Vmin      = %.2f mV | Vmax      = %.2f mV  | Amplitude = %.2f mV\n", var.Vmin_prev_prev, var.Vmax_prev, var.Vamp_prev);    // Vmin prev as want Vmin just before final stimulus applied, not at end of simulation
	printf("\tFINAL beat\t\t:  CaT_min   = %.2f uM   | CaT_max   = %.2f uM   | CaSR_min  = %.2f mM   | CaSR_max = %.2f mM\n", 1e3*var.CaT_min, 1e3*var.CaT_max, var.CaSR_min, var.CaSR_max);
	printf("\tPENULTIMATE beat\t:  CaT_min   = %.2f uM   | CaT_max   = %.2f uM   | CaSR_min  = %.2f mM   | CaSR_max = %.2f mM\n\n", 1e3*var.CaT_min_prev, 1e3*var.CaT_max_prev, var.CaSR_min_prev, var.CaSR_max_prev);

	// Output to file
	FILE *out;
	out = fopen(log_reference, "a");    // Note: Appended, not overwritten
	fprintf(out, "%d %d %f %f %f %f %f %f %f %f %f %f ", Sim.BCL, Sim.S2_CL, var.APD_t, var.APD_t_prev, var.APD_p[2], var.APD_p_prev[2], var.APD_p[4], var.APD_p_prev[4], var.APD_p[6], var.APD_p_prev[6], var.APD_p[8], var.APD_p_prev[8]);
	fprintf(out, "%f %f %f %f %f %f %f %f ", var.dvdt_max, var.dvdt_max_prev, var.Vmin_prev, var.Vmin_prev_prev, var.Vmax, var.Vmax_prev, var.Vamp, var.Vamp_prev);
	fprintf(out, "%f %f %f %f %f %f %f %f\n", 1e3*var.CaT_min, 1e3*var.CaT_min_prev, 1e3*var.CaT_max, 1e3*var.CaT_max_prev, var.CaSR_min, var.CaSR_min_prev, var.CaSR_max, var.CaSR_max_prev);
	fclose(out);

}

// Output currents and gates to file
void output_currents(std::ostream& out, double sim_time, Model_variables var, State_variables s, double Vm)
{
	//1-3
	out<<sim_time<<" "<<Vm<<" "<<var.Istim  \

		// 4-7
		<<" "<<var.INa<<" "<<s.INa_va<<" "<<s.INa_vi_1<<" "<<s.INa_vi_2 \

		// 8-11
		<<" "<<var.Ito<<" "<<s.Ito_va<<" "<<s.Ito_vi<<" "<<s.Ito_vi_s   \

		// 12-15
		<<" "<<var.ICaL<<" "<<s.ICaL_va<<" "<<s.ICaL_vi<<" "<<s.ICaL_vi_s   \

		// 16-18
		<<" "<<var.IKur<<" "<<s.IKur_va<<" "<<s.IKur_vi \

		// 19-21
		<<" "<<var.IKr<<" "<<s.IKr_va<<" "<<var.IKr_vi_ti   \

		// 22-23
		<<" "<<var.IKs<<" "<<s.IKs_va   \

		// 24-25
		<<" "<<var.IK1<<" "<<var.IK1_va_ti  \

		// 26-30 
		<<" "<<var.INCX<<" "<<var.ICaP<<" "<<var.INab<<" "<<var.ICab<<" "<<var.IKb  \

		// 31-33
		<<" "<<var.INaK<<" "<<var.IClCa<<" "<<var.IClb     \

		// 34-39
		<<" "<<s.Cai<<" "<<s.Cai_sl<<" "<<s.Cai_j<<" "<<s.CajSR<<" "<<s.CanSR<<" "<<s.Cao		\

		// 40-42		
		<<" "<<s.RyRo<<" "<<s.RyRr<<" "<<s.RyRi   \

		// 43-48
		<<" "<<s.Nai<<" "<<s.Nai_sl<<" "<<s.Nai_j<<" "<<s.Ki<<" "<<s.Nao<<" "<<s.Ko     \

		<<std::endl;
}

// Excitation properties to file
void output_excitation_properties(std::ostream& out, double sim_time, Model_variables var, double Vm)
{
	//1-3
	out<<sim_time<<" "<<Vm<<" "<<var.ex_switch      \

		// 4-5
		<<" "<<var.dvdt<<" "<<var.dvdt_max              \

		// 6-8
		<<" "<<var.Vmin<<" "<<var.Vmax<<" "<<var.Vamp   \

		// 9-10
		<<" "<<var.APD_t_switch<<" "<<var.APD_t         \

		// 11-14 || 2 = APD_30, 4 = APD_50, 6 = APD_70, 8 = APD_90
		<<" "<<var.APD_p[2]<<" "<<var.APD_p[4]<<" "<<var.APD_p[6]<<" "<<var.APD_p[8]         \

		// 15-18
		<<" "<<1e3*var.CaT_min<<" "<<1e3*var.CaT_max<<" "<<var.CaSR_min<<" "<<var.CaSR_max         \

		<<std::endl;
}
// End Common - screen file outputs =============================================================//|

// Structs header file ====================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiokogy 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#ifndef STRUCTS_H
#define STRUCTS_H

#include <stdbool.h>
#include "MersenneTwister.h"

// struct{}Smulation_parameters;
// struct{}Cell_parameters;
// struct{}State_variables;
// struct{}Model_variables;
// struct{}Argument_parameters;

// Define the simulation parameters struct ======================================================\\|
typedef struct{

	// Reference
	char const	*reference;			// Any reference to identify simulation

	// Simulation pacing and time
	int BCL;				// ms
	int Total_time;			// ms
	int Paced_time;			// ms
	int NBeats;				// N
	double dt;				// ms

	int S2_CL;				// ms
	int NS2;				// N
	int S2_time;			// ms 

	// Simulation conditions
	char const	*Vclamp;		// "On" or "Off"
	char const	*Write_state;	// "On" or "Off"
	char const 	*Read_state; 	// "On" or "Off"

}Simulation_parameters;
// End Define the simulation parameters struct ==================================================//|

// Define the parameters struct (set once) ======================================================\\|
// Contains model parameters and constants and scaling/shift variables (as not dynamically determined)
typedef struct{

	// Global control variables ===================================\\|
	double 		dt;						// Integration time-step	
	char const* Model;					// The baseline model
	char const* Celltype;				// Region or other celltype
	char const* Agent;					// Pharmacological agent
	char const* Remodelling;			// Disease remodelling
	double 		ISO;					// Isoprenaline concentration
	char const* ISO_model;				// Defines which ISO model to use (if multiple models are available for a specific cell model)
	char const* Mutation;				// Mutation
	int 		Het_set_ref;			// Reference for tracking if celltype has been set
	int			ISO_set_ref;			// Reference for tracking if ISO has been set
	int			Agent_set_ref;			// Reference for tracking if Agent has been set
	int			Remodelling_set_ref;	// Reference for tracking if Remodelling has been set
	int 		Mutation_set_ref;		// Reference for tracking if Mutation has been set

	// Multi-model, single species trackers
	bool	hAM;				// True if a hAM model; false for all others

	// hAM specific settings
	char const* Ca_handling; 	// Ca handling model, hAM_WL (chose between GB and CRN)
	char const*	environment;	// isolated vs intact
	// End global control variables ===============================//|	

	// Constants ==================================================\\|
	double R;					// J mol^-1 K^-1
	double F;					// C mmol-1
	double T;					// K
	double FoRT;	
	// End Constants ==============================================//|

	// Cell structure==============================================\\|
	double Cm;					// Membrane capacitance 						(pF)
	double Cm_F;				// Membrane capacitance							(F)

	double Vcell;				// volume of whole cell (um^3)
	double Vcyto;				// volume of intracellular Ca2+ space
	double VjSR;				// volume of jSR / release Ca2+ space
	double VnSR;				// volume of nSR / uptake Ca2+ space
	double Vjunc;				// Volume of intracellular junctional release space
	double Vsl;					// Volume of intracellular sub-sarcolemmal space
	double Vc;					// Volume of extracellular cleft space

	double Fjunc;				// Proportion of currents in junctional vs non-junctional compartments
	double Fjunc_ICaL;			// Proportion of currents in junctional vs non-junctional compartments, LTCCs/ICaL

	// Stimulus parameters ========================================\\|
	double stimduration;		// duration of applied stimulus (ms)
	double stimmag;				// magnitude of applied stimulus (A/F || pA/pF)
	// End Stimulus parameters ====================================//|

	// Current parameters =========================================\\|
	// Hybrid minimal model ===================\\|
	double gIp0d;				// Conductance of phase 0 depolarising current (s/mF | ns/pF)
	double gIp1r;				// Conductance of phase 1 repolarising current (s/mF | ns/pF)
	double gIp2d;				// Conductance of phase 2 depolarising current (s/mF | ns/pF)
	double gIp2r;				// Conductance of phase 2 repolarising current (s/mF | ns/pF)
	double gIp3r;				// Conductance of phase 3 repolarising current (s/mF | ns/pF)
	double gIp4r;				// Conductance of phase 4 repolarising current (s/mF | ns/pF) 
	// End Hybrid minimal model ===============//|

	// Biophysically detailed models ==========\\|
	// Conductances
	double gNa;					// Conductance of fast-sodium current 			(s/mF)
	double gNaL;				// Conductance of fast-sodium current 			(s/mF)
	double gto;					// Conductance of transient-outward K+ current 	(s/mF)
	double gCaL;				// Conductance of L-type ca current 			(s/mF)
	double pCaL;				// Permeability constant fot L-type ca current	(cm/s)
	double pCaL_K;				// Permeability constant fot ICaL, K+ component (cm/s)
	double pCaL_Na;				// Permeability constant fot ICaL, Na+ component(cm/s)
	double gKur;				// Conductance of ultrarpid K+ current 			(s/mF)
	double gKr;					// Conductance of rapid delayed K+ current 		(s/mF)
	double gKs;					// Conductance of slow delayed K+ current 		(s/mF)
	double gK1;					// Conductance of time-independent K+ current 	(s/mF)
	double gClCa;				// Conductance of Ca2+-activated chloride		(s/mF)
	double gNab;				// Conductance of background sodium current 	(s/mF)
	double gCab;				// Conductance of background calcium current 	(s/mF)
	double gKb;					// Conductance of background potassium current 	(s/mF)

	double AIhyp;				// Magnitude of applied hyperpolarising current (pA/pF)

	// ICaL
	double ICaL_ci_tau;			// Calcium induced activation, time constant	(ms)
	double ICaL_ci_al;			// Calcium induced activation, alpha rate 		(ms^-1)
	double ICaL_ci_bet;			// Calcium induced activation, beta rate		(ms^-1)

	// NCX params
	double INCX_bar;			// Maximal current scale factor for NCX 		(pA/pF) or (um^3.uM.ms^-1)
	double INCX_kNao;			// [Na+]o saturation constant for INCX 			(mM)
	double INCX_kNai;			// [Na+]i saturation constant for INCX          (mM)
	double INCX_kCao;			// [Ca2+]o saturation constant for INCX 		(mM)
	double INCX_kCai;			// [Ca2+]i saturation constant for INCX 		(mM)	or (uM)
	double INCX_k;				// Saturation factor for INCX 					(dimensionless)
	double INCX_gamma;			// Voltage dependence factor for INCX 			(dimensionless)
	double INCX_kda;			// Magnitude calcium saturation constant 		(mM)	or (uM)
	double INCX_ksat;			// Saturation constant							(mM)

	// NaK params
	double INaK_bar;			// Maximal current scale factor for INaK		(pA/pF)
	double INaK_kK;				// Half-Saturation constant for Ko INaK 		(mM)
	double INaK_kNa;			// Half-saturation constant for Nai INaK		(mM)

	// Membrane calcium pump (PMCA) params
	double ICaP_bar;			// Conductance factor for calcium pump (pA/pF)	or (um^3 . uM . ms^-1)
	double ICaP_kCa;			// Saturation constant for calcium pump (mM)	or (uM)

	// Background calcium current, flux version
	double ICab_bar;			// (um^3.uM.ms^-1)  CHECK

	//IClCa params
	double IClCa_kd;			// Saturation constant for Ca2+-activated Cl current 

	// ICaL kinetics
	double ICaL_vi_Fs;			// Fraction of slow voltage inactivation
	// End Biophysically detailed model =======//|
	// End Current parameters =====================================//|

	// Concentrations =============================================\\|
	// Many may also be updated state variables; the param in that case
	// becomes the IC for the state variable
	double Nai;					// Intracellular sodium concentration (mM)
	double Nao;					// Extracellular sodium concentration (mM)
	double Ki;					// Intracellular potassium concentration (mM)
	double Ko;					// Extracellular potassium concentration (mM)
	double Cai;					// Intracellular calcium concentration (mM)
	double Cao;					// Extracellular calcium concentration (mM)
	// End concentrations =========================================//|

	// Ca2+ handling ==============================================\\|
	// General/common =========================\\|
	double J_rel_max;			// Maximal flux rate of intracellular Ca2+ release 	(mM/ms) or (um^3/ms)
	double J_SERCA_max;			// Maximal flux rate of intracellular Ca2+ uptake 	(mM/ms) or (uM/ms)
	double J_SERCA_kCa;			// SERCA Cai constant								(mM)	or (uM)
	double J_SERCA_kCaSR;		// SERCA CaSR constant								(uM)
	double J_leak_max;			// Maximal flux rate of intracellular Ca2+ leak		(mM/ms) or ms^-1
	double J_leak_kCaSR;		// Jleak CaSR2+ constant							(-)		or uM
	double J_jsr_nsr_tau;		// Time constant of transfer between jsr and nsr	(ms)
	// End General/common =====================//|

	// Nattel-lab parameters ==================\\|
	double cmdnbar;				// Total calmodulin concentration
	double trpnbar;				// Total troponin concentration
	double csqnbar;				// Total csqn concentration
	double cmdn_k;				// half-saturation constant for calmodulin 	(mM)
	double trpn_k;				// half-saturation constant for troponin 	(mM)
	double csqn_k;				// half-saturation constant for calsequestrin (mM)
	// End Nattel-lab parameters ===============//|

	// Grandi-Bers lab parameters ==============\\|
	// Cell structure, sophisticated and environment
	double junctionLength;		// um
	double junctionRadius;		// um
	double distSLcyto;			// um
	double distJuncSL;			// um

	double DcaJuncSL;			// cm^2/s
	double DcaSLcyto;			// cm^2/s
	double DnaJuncSL;			// cm^2/s
	double DnaSLcyto;			// cm^2/s

	double SAjunc;				// um^2
	double SAsl;				// um^2

	double J_ca_juncsl;			// L/ms
	double J_ca_slmyo;			// L/ms
	double J_na_juncsl;			// L/ms
	double J_na_slmyo;			// L/ms

	// Transport - SR (
	double ks;					// ms^-1
	double Kmf;					// mM
	double Kmr;					// mM
	double hillSRCaP;
	double koCa;				// ms^-1 mM^-1
	double kiCa;				// ms^-1 mM^-1
	double kim;					// ms^-1
	double kom;					// ms^-1
	double ec50SR;				// mM
	double MaxSR;				// mM (?)
	double MinSR;				// mM (?)
	// J_SERCA_max mM/ms already defined for all models above
	
	// Buffering
	double Bmax_SLlowj;			// mM
	double koff_sll;			// ms^-1
	double kon_sll;				// ms^-1 mM^-1
	double Bmax_SLhighj;		// mM
	double kon_slh;				// ms^-1 mM^-1
	double koff_slh;			// ms^-1
	double Bmax_SLlowsl;		// mM
	double Bmax_SLhighsl;		// mM
	double koff_myoca;			// ms^-1
	double kon_myoca;			// ms^-1 mM^-1
	double Bmax_myosin;			// mM
	double Mgi;
	double kon_myomg;			// ms^-1 mM^-1
	double koff_myomg;			// ms^-1
	double kon_tnchca;			// ms^-1 mM^-1
	double koff_tnchca;			// ms^-1
	double Bmax_TnChigh;		// mM
	double kon_tnchmg;			// ms^-1 mM^-1
	double koff_tnchmg;			// ms^-1
	double kon_tncl;			// ms^-1 mM^-1
	double koff_tncl;			// ms^-1
	double Bmax_TnClow;			// mM
	double Bmax_CaM;			// mM
	double kon_cam;				// ms^-1 mM^-1
	double koff_cam;			// ms^-1
	double Bmax_SR;				// mM
	double kon_sr;				// ms^-1 mM^-1
	double koff_sr;				// ms^-1
	double Bmax_Csqn;			// mM
	double kon_csqn;			// ms^-1 mM^-1
	double koff_csqn;			// ms^-1
	double Bmax_Naj;			// mM
	double Bmax_Nasl;			// mM
	double koff_na;				// ms^-1
	double kon_na;				// ms^-1 mM^-1
	// End Grandi-Bers lab parameters ==========//|
	// End Ca2+ handling ==========================================//|	

	// MODIFIERS ==================================================\\|
	// Simple scaling 
	double GNa;					// Scale factor for fast sodium current (and Ip0d)
	double GNaL;				// Scale factor for late sodium current
	double Gto;					// Scale factor for Ito (and Ip1r)
	double GCaL;				// Scale factor for ICaL (and Ip2d)
	double GKur;				// Scale factor for IKur (and Ip2r)
	double GKr;					// Scale factor for IKr (and Ip3r)
	double GKs;					// Scale factor for IKs
	double GK1;					// Scale factor for IK1
	double GNCX;				// Scale factor for INCX
	double GCaP;				// Scale factor for ICaP
	double GNab;				// Scale factor for INab
	double GCab;				// Scale factor for ICab
	double GKb;					// Scale factor for IKb
	double GNaK;				// Scale factor for INaK
	double GClCa;				// Scale factor for IClCa

	// Time constant scaling
	double INa_va_tau_scale;	// Scales time constant for INa voltage activation
	double INa_vi_1_tau_scale;	// Scales time constant for INa voltage inactivation 1
	double INa_vi_2_tau_scale;	// Scales time constant for INa voltage inactivation 2
	double INaL_va_tau_scale;	// Scales time constant for INaL voltage activation
	double INaL_vi_tau_scale;	// Scales time constant for INaL voltage inactivation
	double Ito_va_tau_scale;	// Scales time constant for Ito voltage activation
	double Ito_vi_tau_scale;	// Scales time constant for Ito voltage inactivation
	double ICaL_va_tau_scale;	// Scales time constant for ICaL voltage activation
	double ICaL_vi_tau_scale;	// Scales time constant for ICaL voltage inactivation
	double IKur_va_tau_scale;	// Scales time constant for IKur voltage activation
	double IKur_vi_tau_scale;	// Scales time constant for IKur voltage inactivation
	double IKr_va_tau_scale;	// Scales time constant for IKr voltage activation
	double IKs_va_tau_scale;	// Scales time constant for IKr voltage activation

	// Voltage dependence
	// (note: approach is to shift the V1/2 in the equations; equivalent is to minus shift from Voltage input into equations)
	double INa_va_shift; 		// Shift of the V of activation || alpha and beta  	mV
	double INa_vi_shift;		// Shift of the V of inactivation || alpha and beta mV

	double INaL_va_shift; 		// Shift of the V of activation || alpha and beta  	mV
	double INaL_vi_shift;		// Shift of the V of inactivation || alpha and beta mV

	double Ito_va_ss_shift;		// Shift of the V1/2 of acitvation steady state     mV
	double Ito_vi_ss_shift;		// Shift of the V1/2 of inactivation steady state	mV
	double Ito_va_tau_shift;	// Shift of the voltage dependence of time constant mV
	double Ito_vi_tau_shift;	// Shift of the voltage dependence of time constant mV
	double Ito_va_ss_kscale;	// Scales the gradient parameter of activation steady state
	double Ito_vi_ss_kscale;	// Scales the gradient parameter of inactivation steady state

	double ICaL_va_ss_shift;    // Shift of the V1/2 of acitvation steady state     mV
	double ICaL_vi_ss_shift;    // Shift of the V1/2 of inactivation steady state   mV
	double ICaL_va_tau_shift;   // Shift of the voltage dependence of time constant mV
	double ICaL_vi_tau_shift;   // Shift of the voltage dependence of time constant mV
	double ICaL_va_ss_kscale;   // Scales the gradient parameter of activation steady state
	double ICaL_vi_ss_kscale;   // Scales the gradient parameter of inactivation steady state

	double IKur_va_ss_shift;    // Shift of the V1/2 of acitvation steady state     mV
	double IKur_vi_ss_shift;    // Shift of the V1/2 of inactivation steady state   mV
	double IKur_va_tau_shift;   // Shift of the voltage dependence of time constant mV
	double IKur_vi_tau_shift;   // Shift of the voltage dependence of time constant mV
	double IKur_va_ss_kscale;   // Scales the gradient parameter of activation steady state
	double IKur_vi_ss_kscale;   // Scales the gradient parameter of inactivation steady state

	double IKr_va_ss_shift;    	// Shift of the V1/2 of acitvation steady state     mV
	double IKr_va_tau_shift;    // Shift of the voltage dependence of time constant mV
	double IKr_va_ss_kscale;    // Scales the gradient parameter of activation steady state
	double IKr_vi_ss_shift;    	// Shift of the V1/2 of acitvation steady state     mV
	double IKr_vi_ss_kscale;    // Scales the gradient parameter of activation steady state

	double IKs_va_ss_shift;    	// Shift of the V1/2 of acitvation steady state     mV
	double IKs_va_tau_shift;    // Shift of the voltage dependence of time constant mV
	double IKs_va_ss_kscale;    // Scales the gradient parameter of activation steady state

	double IK1_va_shift;    	// Shift of the V1/2 of acitvation steady state     mV

	// Ca handling modification
	double Gup;					// Scale factor for intracellular, SERCA Ca2+ uptake
	double Gleak;				// Scale factor for intracellular Ca2+ leak
	double Grel;				// Scale factor for intracellualr Ca2+ release 
	// End MODIFIERS ==============================================//|

}Cell_parameters;
// End Define the parameters struct (set once) ==================================================//|

// Define the state variables (time-dependent) ==================================================\\|
// Gating variables, concentrations, and othe time-dependent variables
typedef struct{

	double Vm;					// Whole-cell membrane potential (mV)

	// Current gating variables ===================================\\|
	// Biophysically detailed currents ========\\|
	// INa
	double INa_va;				// voltage activation
	double INa_vi_1;			// voltage inactivation
	double INa_vi_2;			// voltage inactivation 2

	//INaL
	double INaL_va;				// voltage activation
	double INaL_vi;				// voltage inactivation

	// Ito
	double Ito_va;				// voltage activation
	double Ito_vi;				// voltage inactivation (fast if slow also used)
	double Ito_vi_s;			// voltage inactivation, slow

	// ICaL
	double ICaL_va;				// voltage activation
	double ICaL_vi;				// voltage inactivation (fast if slow also used)
	double ICaL_vi_s;			// voltage inactivation, slow
	double ICaL_ci;				// calcium inactivation
	double ICaL_ci_j;			// calcium inactivation, junctional

	// IKur
	double IKur_va;				// voltage activation
	double IKur_vi;				// voltage inactivation (fast if slow also used)

	// IKr
	double IKr_va;				// voltage activation

	// IKs
	double IKs_va;				// voltage activation
	// End Biophysically detailed currents ====//|

	// Hybrid minimal model currents ==========\\|
	// Phase 0 depolarising current
	double Ip0d_va;				// voltage activation
	double Ip0d_vi_1;			// voltage inactivation 1
	double Ip0d_vi_2;			// voltage inactivation 2

	// Phase 1 repolarising current
	double Ip1r_va;				// voltage activation
	double Ip1r_vi;				// voltage inactivation

	// Phase 2 depolarising current
	double Ip2d_va;				// voltage activation
	double Ip2d_vi;				// voltage inactivation

	// Phase 2 repolarising current
	double Ip2r_va;				// voltage activation
	double Ip2r_vi;				// voltage activation

	// Phase 3 repolarising current
	double Ip3r_va;				// voltage activation
	// End Hybrid minimal model currents ======//|
	// End Current gating variables ===============================//|

	// Concentrations =============================================\\|
	// If not updated, then state variable will be set once from the
	// param. Note that the models use the state variable, so it must
	// exist even if it is a constant
	double Nai;                 // Intracellular sodium concentration (mM)
	double Nao;                 // Extracellular sodium concentration (mM)
	double Ki;                  // Intracellular potassium concentration (mM)
	double Ko;                  // Extracellular potassium concentration (mM)
	double Cai;                 // Intracellular calcium concentration (mM)
	double Cao;                 // Extracellular calcium concentration (mM)

	double Nai_j;				// Intracellular sodium concentration, junctional compartment (mM)
	double Nai_sl;				// Intracellular sodium concentration, junctional compartment (mM)
	double Cai_j;				// Intracellular calcium concentration, junctional compart 	(mM)
	double Cai_sl;				// Intracellular calcium concentration, sub-sarcolemmal (mM)
	// End concentrations =========================================//| 

	// Ca2+ handling ==============================================\\|
	double cmdn;				// calmodulin concentration 	(mM)
	double trpn;				// troponin concentration		(mM)
	double csqn;				// calsequestrin concenrration 	(mM)

	double CajSR;				// junctional SR / release compartment Ca concentration (mM)
	double CanSR;				// network SR / uptake compartment Ca concentration  	(mM)

	double RyRo;				// proportion open RyRs / activation gate
	double RyRr;				// proportion refactory RyRs / inactivation gate 1
	double RyRi;				// proportion inactivated RyRs / inactvation gate 2

	// Grandi-Bers Ca handling
	double	Tn_CHm;
	double	Tn_CHc;
	double	Myo_m;
	double	Myo_c;
	double	Tn_CL;

	// Nygren-Giles Ca handlin
	double CaCalse;
	double CaCal;
	double Catrop;
	double Camg;
	double Mgmg;
	// End Ca2+ handling ==========================================//|
}State_variables;
// End Define the state variables (time-dependent) ==============================================//|

// Define the model variables struct  ===========================================================\\|
// All variables which are calculated within the model, and may need to be seen from multiple functions
// Includes the currents themselves, the current variables (steady states, taus), stimulation variables
typedef struct{

	// Stimulus variables =========================================\\|
	double 	Istim;				// Stimulus current (pA/pF)
	bool	stimflag;			// true IF stimulus is being applied
	int 	BCL_int;			// integer value of BCL	
	int 	stimduration_int;	// integer value of stim duration
	int 	stimcount;			// number of times stimulus has been applied
	int 	stimcount_S2;		// number of times stimulus has been applied
	int 	S2_int;				// integer value of S2 coupling interval
	double	Istim_S2;			// S2 stimulus current (pA/pF)
	bool	S2_stimflag;		// true IF S2 stimulus is being applied
	int 	Paced_time_int;		// integer value of paced time (s1)
	// end Stimulus variables =====================================//|

	// Reversal potentials ========================================\\|
	double ENa;					// reversal potential, sodium ions 				(mV)
	double EK;					// reversal potential, potassium ions 			(mV)
	double EKs;					// reversal potential, potassium ions, IKs		(mV)
	double ECa;					// reversal potential, calcium ions 			(mV)
	double ENa_j;				// reversal potential, junctional sodium 		(mV)
	double ENa_sl;				// reversal potential, sub-sarcolemmal sodium	(mV)
	double ECa_j;				// reversal potential, junctional calcium 		(mV)
	double ECa_sl;				// reversal potential, sub-sarcolemmal calcium 	(mV)
	double ECl;					// reversal potential, chloride 				(mV)
	// End Reversal potentials ====================================//|

	// Currents ===================================================\\|
	double Itot;				// Total ionic current (pA/pF)

	// Real currents (all pA/pF) 
	double INa;					// Fast sodium current
	double INaL;				// Late sodium current
	double Ito;					// Transient outward potassium current
	double ICaL;				// L-type calcium current
	double IKur;				// Ultrarpid potassium current
	double IKr;					// Rapid delayed rectifier potassium current
	double IKs;					// Slow delayed rectifier potassium current
	double IK1;					// Time-independent rectifier potassium current
	double INCX;				// Sodium-calcium exchanger
	double INaK;				// Sodim-potassium pump
	double ICaP;				// membrane calcium pump (PMCA)
	double INab;				// Background sodium current
	double ICab;				// Background calcium current
	double IKb;					// Background potassium current
	double IClCa;				// Ca2+-activated chloride current
	double IClb;				// Background chloride current
	//double Ihyp;				// Magnitude of applied hyperpolarising current

	// Currents, more sophisticated structure models
	double INa_sl;				// Fast sodium current, sub-sarcolemmal
	double INaL_sl;				// Late sodium current, sub-sarcolemmal
	double INab_sl;				// Background sodium current, sub-sarcolemmal
	double ICab_sl;				// Background calcium current, sub-sarcolemmal
	double ICaP_sl;				// membrane calcium pump (PMCA), sub-sarcolemmal
	double INCX_sl;				// Sodium-calcium exchanger, sub-sarcolemmal
	double ICaL_sl;				// L-type calcium current, sub-sarcolemmal
	double INaK_sl;				// Sodim-potassium pump, sub-sarcolemmal
	double IClCa_sl;			// Ca2+-activated chloride current, sub-sarcolemmal
	double IKs_sl;				// Slow delayed rectifier potassium current, sub-sarcolemmal
	double INa_j;				// Fast sodium current, junctional
	double INaL_j;				// Late sodium current, junctional
	double INab_j;				// Background sodium current, junctional
	double ICab_j;				// Background calcium current, junctional
	double ICaP_j;				// membrane calcium pump (PMCA), junctional
	double INCX_j;				// Sodium-calcium exchanger, junctional
	double ICaL_j;				// L-type calcium current, junctional
	double INaK_j;				// Sodim-potassium pump, junctional
	double IClCa_j;				// Ca2+-activated chloride current, junctional
	double IKs_j;				// Slow delayed rectifier potassium current, junctional

	double ICaL_Ca_j;			// Calcium specific component, ICaL, junctional
	double ICaL_Ca_sl;			// Calcium specific component, ICaL, sub-sarcolemmal
	double ICaL_K;				// Potassium component, ICaL
	double ICaL_Na_j;			// Sodium specific component, ICaL, junctional
	double ICaL_Na_sl;			// Sodium specific component, ICaL, sub-sarcolemmal

	// Hybrid minimal model current names
	double Ip0d;				// Phase-0 depolarising current
	double Ip1r;				// Phase-1 repolarising current
	double Ip2d;				// Phase-2 depolarising current
	double Ip2r;				// Phase-2 repolarising current
	double Ip3r;				// Phase-3 repolarising current
	double Ip4r;				// Phase-4 repolarising current
	// End currents ===============================================//|

	// Current calculation variables ==============================\\|
	// Dynamic conductance
	double ICaL_bar_sl;			// Maximal current through the L-type calcium channels, sub-sarcolemma 	(Ca-specific component if appropriate)
	double ICaL_bar_j;			// Maximal current through the L-type calcium channels, junctional		(Ca-specific component if appropriate)
	double ICaL_bar_K;			// Maximal current through the L-type calcium channels, Potassium component
	double ICaL_bar_Na_sl;		// Maximal current through the L-type calcium channels, Sodium, sub-sarcolemma
	double ICaL_bar_Na_j;		// Maximal current through the L-type calcium channels, Sodium, junctional

	// Steady states and time constants -  biophysically detailed models
	double INa_va_ss;          	// voltage activation, steady state
	double INa_va_tau;         	// voltage activation, time constant
	double INa_vi_1_ss;        	// voltage inactivation, steady state
	double INa_vi_1_tau;       	// voltage inactivation, time constant
	double INa_vi_2_ss;        	// voltage inactivation, steady state
	double INa_vi_2_tau;       	// voltage inactivation, time constant
	double INa_va_al;          	// voltage activation, alpha transition rate (1-y-> y)
	double INa_va_bet;         	// voltage activation, beta transition rate  (y -> 1-y)
	double INa_vi_1_al;        	// voltage activation, alpha transition rate (1-y -> y)
	double INa_vi_1_bet;       	// voltage activation, beta transition rate  (y -> 1-y)
	double INa_vi_2_al;        	// voltage activation, alpha transition rate (1-y -> y)
	double INa_vi_2_bet;       	// voltage activation, beta transition rate  (y -> 1-y)

	double INaL_va_ss;         	// voltage activation, steady state
	double INaL_va_tau;        	// voltage activation, time constant
	double INaL_vi_ss;         	// voltage inactivation, steady state
	double INaL_vi_tau;        	// voltage inactivation, time constant
	double INaL_va_al;          // voltage activation, alpha transition rate (1-y-> y)
	double INaL_va_bet;         // voltage activation, beta transition rate  (y -> 1-y)

	double Ito_va_ss;          	// voltage activation, steady state
	double Ito_va_tau;         	// voltage activation, time constant
	double Ito_vi_ss;          	// voltage inactivation, steady state
	double Ito_vi_tau;         	// voltage inactivation, time constant
	double Ito_vi_s_tau;       	// voltage inactivation, time constant, slow
	double Ito_va_al;			// voltage activation, alpha transition rate (1-y-> y)
	double Ito_va_bet;			// voltage activation, beta transition rate  (y -> 1-y)
	double Ito_vi_al;			// voltage activation, alpha transition rate (1-y-> y)
	double Ito_vi_bet;			// voltage activation, beta transition rate  (y -> 1-y)
	double Ito_vi_Fs;			// Fraction of slow voltage inactivation

	double ICaL_va_ss;          // voltage activation, steady state
	double ICaL_va_tau;         // voltage activation, time constant
	double ICaL_vi_ss;          // voltage inactivation, steady state
	double ICaL_vi_tau;         // voltage inactivation, time constant
	double ICaL_vi_s_tau;       // voltage inactivation, time constant, slow
	double ICaL_ci_ss;			// calcium inactivation, steady state
	double ICaL_ci_j_ss;		// calcium inactivation, steady state, junctional
	double ICaL_ci_tau;			// calcium inactivation, time constant		
	double ICaL_ci_al;          // Calcium induced activation, alpha rate       (ms^-1)
	double ICaL_ci_bet;         // Calcium induced activation, beta rate        (ms^-1)	

	double IKur_va_ss;          // voltage activation, steady state
	double IKur_va_tau;         // voltage activation, time constant
	double IKur_vi_ss;          // voltage inactivation, steady state
	double IKur_vi_tau;         // voltage inactivation, time constant
	double IKur_va_al;          // voltage activation, alpha transition rate (1-y-> y)
	double IKur_va_bet;         // voltage activation, beta transition rate  (y -> 1-y)
	double IKur_vi_al;          // voltage activation, alpha transition rate (1-y-> y)
	double IKur_vi_bet;         // voltage activation, beta transition rate  (y -> 1-y)
	double IKur_dynamic_g;		// Dynamic conductance factor (s/mF)

	double IKr_va_ss;			// voltage activation, steady state
	double IKr_va_tau;			// voltage activation, time constant

	double IKs_va_ss;			// voltage activation, steady state
	double IKs_va_tau;			// voltage activation, time constant

	double IKr_vi_ti;			// Time-independent inactivation gate
	double IK1_va_ti;			// Time-independent activation

	// Steady states and time constants - hybrid minimal model
	double Ip0d_va_ss;			// voltage activation, steady state
	double Ip0d_va_tau;			// voltage activation, time constant
	double Ip0d_vi_1_ss;		// voltage inactivation, steady state
	double Ip0d_vi_1_tau;		// voltage inactivation, time constant
	double Ip0d_vi_2_ss;		// voltage inactivation, steady state
	double Ip0d_vi_2_tau;		// voltage inactivation, time constant
	double Ip0d_va_al;			// voltage activation, alpha transition rate (1-y-> y)
	double Ip0d_va_bet;			// voltage activation, beta transition rate  (y -> 1-y)
	double Ip0d_vi_1_al;		// voltage activation, alpha transition rate (1-y -> y)
	double Ip0d_vi_1_bet;		// voltage activation, beta transition rate  (y -> 1-y)
	double Ip0d_vi_2_al;		// voltage activation, alpha transition rate (1-y -> y)
	double Ip0d_vi_2_bet;		// voltage activation, beta transition rate  (y -> 1-y)

	double Ip1r_va_ss;			// voltage activation, steady state
	double Ip1r_va_tau;			// voltage activation, time constant
	double Ip1r_vi_ss;			// voltage inactivation, steady state
	double Ip1r_vi_tau;			// voltage inactivation, time constant

	double Ip2d_va_ss;			// voltage activation, steady state
	double Ip2d_va_tau;			// voltage activation, time constant
	double Ip2d_vi_ss;			// voltage inactivation, steady state
	double Ip2d_vi_tau;			// voltage inactivation, time constant

	double Ip2r_va_ss;			// voltage activation, steady state
	double Ip2r_va_tau;			// voltage activation, time constant
	double Ip2r_vi_ss;			// voltage inactivation, steady state
	double Ip2r_vi_tau;			// voltage inactivation, time constant

	double Ip3r_va_ss;			// voltage activation, steady state
	double Ip3r_va_tau;			// voltage activation, time constant
	double Ip3r_va_al;			// voltage activation, alpha transition rate (1-y -> y)
	double Ip3r_va_bet;			// voltage activation, beta transition rate  (y -> 1-y)
	double Ip3r_vi_ti;			// Time-independent inactivation gate

	double Ip4r_va_ti;			// Time-independent activation gate
	// End current calculation variables ==========================//|

	// Homeostasis ================================================\\|
	// Concentrations
	double dNai;				// Differential of intracellular sodium concentration 		(mM/ms)
	double dKi;					// Differential of intracellular potassium concentration 	(mM/ms)
	double dCai;				// Differential of intracellular calcium concentration 		(mM/ms)

	// Ca2+ handling
	double J_rel;				// Intracellular calcium release flux 	(mM/ms)
	double J_SERCA;				// Intracellular Ca2+ uptake flux		(mM/ms)
	double J_leak;				// Intracellular Ca2+ leak flux			(mM/ms)
	double J_jsr_nsr;			// jSR - nSR transfer flux				(mM/ms)
	double Cai_Fn;				// intracellular Ca2+ flux term			(mM/ms)

	double dMyo_c;	// Buffering differentials
	double dMyo_m;
	double dTn_CHc;
	double dTn_CHm;
	double dTn_CL;
	double J_CaB_cytosol;
	double kCaSR;
	double koSRCa;
	double kiSRCa;
	double RI;
	// End Homeostasis ============================================//|

	// Properties and measurement variables =======================\\|
	int 	ex_switch;				// Tracks whether cell is currently excited
	int 	APD_t_switch;			// Tracks whether APD at threshold has been calculated
	int		APD_p_switch[9];		// Tracks whether APD to % repolarisation has been calculated
	double 	t_ex;					// Time at which cell was excited	(ms)
	double 	dvdt;					// Rate of change of voltage		(mV/ms)
	double 	dvdt_max;				// Maximum rate of change of voltage(mV/ms)
	double 	dvdt_max_prev;			// Maximum rate of change of voltage(mV/ms)
	double	Vmax;					// Maximum voltage					(mV)
	double 	Vmax_prev;				// Maximum voltage, previous beat	(mV)
	double  Vmin;					// Minimum voltage					(mV)
	double 	Vmin_prev;				// Minimum voltage, previous beat 	(mV) *well, actually at point of excitation for current beat
	double 	Vmin_prev_prev;			// Minimum voltage, previous beat 	(mV) *point of excitation for previous beat
	double	Vamp;					// Amplitude voltage				(mV)
	double	Vamp_prev;				// Amplitude voltage, previous beat (mV)
	double 	APD_t;					// APD at threshold voltage			(ms)
	double 	APD_p[9];				// APD at multiple % repolarisation (ms)
	double 	APD_t_prev;				// previous beat APD at threshold 	(ms)
	double 	APD_p_prev[9];			// previous beat APD at % 			(ms)
	double 	CaT_min;				// Minimum intracellular Ca2+		(mM)
	double 	CaT_max;				// Maximum intracellular Ca2+		(mM)
	double 	CaSR_min;				// Minimum SR Ca2+					(mM)
	double 	CaSR_max;				// Maximum SR Ca2+					(mM)
	double 	CaT_min_prev;			// Minimum intracellular Ca2+ prev	(mM)
	double 	CaT_max_prev;			// Maximum intracellular Ca2+ prev	(mM)
	double 	CaSR_min_prev;			// Minimum SR Ca2+ prev				(mM)
	double 	CaSR_max_prev;			// Maximum SR Ca2+ prev				(mM)
	// End Properties and measurement variables ===================//|

}Model_variables;
// End Define the model variables struct ========================================================//|

// Define the arguments struct ==================================================================\\|
typedef struct {

	// Reference ==================================================\\|
	char const	*reference;			// Any reference to identify simulation
	bool		reference_arg;		// true IF argument is passed
	// End reference ==============================================//|

	// Simulation settings ========================================\\|
	int         BCL;                // Basic cycle length, ms
	bool        BCL_arg;            // True IF BCL argument has been passed
	int         Total_time;         // Total simulation time, ms
	bool        Total_time_arg;     // True IF Total time argument has been passed
	int         Paced_time;         // Time during which stimulus is applied
	bool        Paced_time_arg;     // True IF paced time argument has been passed
	int         NBeats;             // Number of applied stimuli
	bool        NBeats_arg;         // True IF NBeats argument has been passed
	int			S2_CL;				// CL of S2 stimulus
	bool 		S2_arg;				// True IF S2 CL argument passed
	int 		NS2;				// Number S2 stimuli
	bool		NS2_arg;			// True IF NS2 argument passed
	double      dt;                 // Simulation integration time-step
	bool        dt_arg;             // True IF dt argument has been passed
	char const	*Vclamp;			// "On" or "Off"
	char const  *Write_state;		// "On" or "Off"	
	char const  *Read_state;		// "On" or "Off"
	char const 	*Coupling_type;		// "isotropic", "isotropic_heterogeneous", "anisotropic", "anisotropic_heterogeneous" || relevant for tissue only
	// End simulation settings ====================================//|

	// Model and cell conditions ==================================\\|
	char const  *Model;             // String containing selected model
	bool        Model_arg;          // True IF Model argument has been passed
	char const  *Celltype;          // String containing selected model
	bool        Celltype_arg;       // True IF Model argument has been passed
	char const	*Agent;				// String containing pharma agent
	bool		Agent_arg;			// True IF argument passed
	char const	*Remodelling;		// String containing remodelling
	bool		Remodelling_arg;	// True IF argument passed
	double      ISO;				// Concentration of ISO
	bool		ISO_arg;			// True IF argument passed
	char const  *ISO_model;			// Which ISO model is to be used
	bool		ISO_model_arg;		// True IF argument passed
	char const	*Mutation;			// Mutation
	bool 		Mutation_arg;		// True IF argument has been passed

	char const 	*environment;		// For human single cell only; isolated vs intact cell environment 
	bool		environment_arg;	// True IF environment argument is passed

	double		AIhyp;				// Magnitude of applied hyperpolarising current (pA/pF)
	bool		Ihyp_arg;			// True IF argument has been passed
	// End model and cell conditions ==============================//|

	// Direct current modification ================================\\|
	// Simple scaling 
	double GNa;                 // Scale factor for fast sodium current (and Ip0d)
	double GNaL;                // Scale factor for late sodium current
	double Gto;                 // Scale factor for Ito (and Ip1r)
	double GCaL;                // Scale factor for ICaL (and Ip2d)
	double GKur;                // Scale factor for IKur (and Ip2r)
	double GKr;                 // Scale factor for IKr (and Ip3r)
	double GKs;                 // Scale factor for IKs
	double GK1;                 // Scale factor for IK1
	double GNCX;                // Scale factor for INCX
	double GCaP;                // Scale factor for ICaP
	double GNab;                // Scale factor for INab
	double GCab;                // Scale factor for ICab
	double GKb;                 // Scale factor for IKb
	double GNaK;                // Scale factor for INaK
	double GClCa;               // Scale factor for IClCa

	// Time constant scaling
	double INa_va_tau_scale;   	// Scales time constant for INa voltage activation
	double INa_vi_1_tau_scale;  // Scales time constant for INa voltage inactivation 1
	double INa_vi_2_tau_scale;  // Scales time constant for INa voltage inactivation 2
	double INaL_va_tau_scale;   // Scales time constant for INaL voltage activation
	double INaL_vi_tau_scale;   // Scales time constant for INaL voltage inactivation
	double Ito_va_tau_scale;    // Scales time constant for Ito voltage activation
	double Ito_vi_tau_scale;    // Scales time constant for Ito voltage inactivation
	double ICaL_va_tau_scale;   // Scales time constant for ICaL voltage activation
	double ICaL_vi_tau_scale;   // Scales time constant for ICaL voltage inactivation
	double IKur_va_tau_scale;   // Scales time constant for IKur voltage activation
	double IKur_vi_tau_scale;   // Scales time constant for IKur voltage inactivation
	double IKr_va_tau_scale;    // Scales time constant for IKr voltage activation
	double IKs_va_tau_scale;    // Scales time constant for IKr voltage activation

	// Voltage dependence
	double INa_va_shift;        // Shift of the V of activation || alpha and beta   mV
	double INa_vi_shift;        // Shift of the V of inactivation || alpha and beta mV

	double INaL_va_shift;       // Shift of the V of activation || alpha and beta   mV
	double INaL_vi_shift;       // Shift of the V of inactivation || alpha and beta mV

	double Ito_va_ss_shift;     // Shift of the V1/2 of acitvation steady state     mV
	double Ito_vi_ss_shift;     // Shift of the V1/2 of inactivation steady state   mV
	double Ito_va_tau_shift;    // Shift of the voltage dependence of time constant mV
	double Ito_vi_tau_shift;    // Shift of the voltage dependence of time constant mV
	double Ito_va_ss_kscale;    // Scales the gradient parameter of activation steady state
	double Ito_vi_ss_kscale;    // Scales the gradient parameter of inactivation steady state
	double Ito_shift;			// Applies to all V shifts 							mV

	double ICaL_va_ss_shift;    // Shift of the V1/2 of acitvation steady state     mV
	double ICaL_vi_ss_shift;    // Shift of the V1/2 of inactivation steady state   mV
	double ICaL_va_tau_shift;   // Shift of the voltage dependence of time constant mV
	double ICaL_vi_tau_shift;   // Shift of the voltage dependence of time constant mV
	double ICaL_va_ss_kscale;   // Scales the gradient parameter of activation steady state
	double ICaL_vi_ss_kscale;   // Scales the gradient parameter of inactivation steady state
	double ICaL_shift;			// Applies to all V shifts 							mV

	double IKur_va_ss_shift;    // Shift of the V1/2 of acitvation steady state     mV
	double IKur_vi_ss_shift;    // Shift of the V1/2 of inactivation steady state   mV
	double IKur_va_tau_shift;   // Shift of the voltage dependence of time constant mV
	double IKur_vi_tau_shift;   // Shift of the voltage dependence of time constant mV
	double IKur_va_ss_kscale;   // Scales the gradient parameter of activation steady state
	double IKur_vi_ss_kscale;   // Scales the gradient parameter of inactivation steady state
	double IKur_shift;			// Applies to all V shifts 							mV

	double IKr_va_ss_shift;     // Shift of the V1/2 of acitvation steady state     mV
	double IKr_va_tau_shift;    // Shift of the voltage dependence of time constant mV
	double IKr_va_ss_kscale;    // Scales the gradient parameter of activation steady state
	double IKr_vi_ss_shift;     // Shift of the V1/2 of acitvation steady state     mV
	double IKr_vi_ss_kscale;    // Scales the gradient parameter of activation steady state

	double IKs_va_ss_shift;     // Shift of the V1/2 of acitvation steady state     mV
	double IKs_va_tau_shift;    // Shift of the voltage dependence of time constant mV
	double IKs_va_ss_kscale;    // Scales the gradient parameter of activation steady state

	double IK1_va_shift;        // Shift of the V1/2 of acitvation steady state     mV
	// End direct current modification ============================//|

	// Ca handling modification ===================================\\|
	double Gup;                 // Scale factor of intracellular, SERCA Ca2+ uptake
	double Gleak;               // Scalr factor of intracellular Ca2+ leak 
	double Grel;				// Scale factor for intracellualr Ca2+ release 
	// End Ca handling modification ===============================//|

	// Boolean switches if modulation arguments have been passed ==\\|
	bool DC_current_mod_arg;		// True IF ANY direct current mod argument has been passed
	bool GNa_arg;                	// Scale factor for fast sodium current (and Ip0d)
	bool GNaL_arg;                	// Scale factor for late sodium current
	bool Gto_arg;                 	// Scale factor for Ito (and Ip1r)
	bool GCaL_arg;                	// Scale factor for ICaL (and Ip2d)
	bool GKur_arg;                	// Scale factor for IKur (and Ip2r)
	bool GKr_arg;                 	// Scale factor for IKr (and Ip3r)
	bool GKs_arg;                 	// Scale factor for IKs
	bool GK1_arg;                 	// Scale factor for IK1
	bool GNCX_arg;                	// Scale factor for INCX
	bool GCaP_arg;                	// Scale factor for ICaP
	bool GNab_arg;                	// Scale factor for INab
	bool GCab_arg;                	// Scale factor for ICab
	bool GKb_arg;                 	// Scale factor for IKb
	bool GNaK_arg;                	// Scale factor for INaK
	bool GClCa_arg;               	// Scale factor for IClCa
	bool INa_va_tau_scale_arg;    	// Scales time constant for INa voltage activation
	bool INa_vi_1_tau_scale_arg;  	// Scales time constant for INa voltage inactivation 1
	bool INa_vi_2_tau_scale_arg;  	// Scales time constant for INa voltage inactivation 2
	bool INaL_va_tau_scale_arg;   	// Scales time constant for INaL voltage activation
	bool INaL_vi_tau_scale_arg;   	// Scales time constant for INaL voltage inactivation
	bool Ito_va_tau_scale_arg;    	// Scales time constant for Ito voltage activation
	bool Ito_vi_tau_scale_arg;    	// Scales time constant for Ito voltage inactivation
	bool ICaL_va_tau_scale_arg;   	// Scales time constant for ICaL voltage activation
	bool ICaL_vi_tau_scale_arg;   	// Scales time constant for ICaL voltage inactivation
	bool IKur_va_tau_scale_arg;   	// Scales time constant for IKur voltage activation
	bool IKur_vi_tau_scale_arg;   	// Scales time constant for IKur voltage inactivation
	bool IKr_va_tau_scale_arg;    	// Scales time constant for IKr voltage activation
	bool IKs_va_tau_scale_arg;    	// Scales time constant for IKr voltage activation
	bool INa_va_shift_arg;        	// Shift of the V of activation || alpha and beta   mV
	bool INa_vi_shift_arg;        	// Shift of the V of inactivation || alpha and beta mV
	bool INaL_va_shift_arg;       	// Shift of the V of activation || alpha and beta   mV
	bool INaL_vi_shift_arg;       	// Shift of the V of inactivation || alpha and beta mV
	bool Ito_va_ss_shift_arg;     	// Shift of the V1/2 of acitvation steady state     mV
	bool Ito_vi_ss_shift_arg;     	// Shift of the V1/2 of inactivation steady state   mV
	bool Ito_va_tau_shift_arg;    	// Shift of the voltage dependence of time constant mV
	bool Ito_vi_tau_shift_arg;    	// Shift of the voltage dependence of time constant mV
	bool Ito_va_ss_kscale_arg;    	// Scales the gradient parameter of activation steady state
	bool Ito_vi_ss_kscale_arg;    	// Scales the gradient parameter of inactivation steady state
	bool Ito_shift_arg;    
	bool ICaL_va_ss_shift_arg;    	// Shift of the V1/2 of acitvation steady state     mV
	bool ICaL_vi_ss_shift_arg;    	// Shift of the V1/2 of inactivation steady state   mV
	bool ICaL_va_tau_shift_arg;   	// Shift of the voltage dependence of time constant mV
	bool ICaL_vi_tau_shift_arg;   	// Shift of the voltage dependence of time constant mV
	bool ICaL_va_ss_kscale_arg;   	// Scales the gradient parameter of activation steady state
	bool ICaL_vi_ss_kscale_arg;   	// Scales the gradient parameter of inactivation steady state
	bool ICaL_shift_arg;    
	bool IKur_va_ss_shift_arg;    	// Shift of the V1/2 of acitvation steady state     mV
	bool IKur_vi_ss_shift_arg;    	// Shift of the V1/2 of inactivation steady state   mV
	bool IKur_va_tau_shift_arg;   	// Shift of the voltage dependence of time constant mV
	bool IKur_vi_tau_shift_arg;   	// Shift of the voltage dependence of time constant mV
	bool IKur_va_ss_kscale_arg;   	// Scales the gradient parameter of activation steady state
	bool IKur_vi_ss_kscale_arg;   	// Scales the gradient parameter of inactivation steady state
	bool IKur_shift_arg;    
	bool IKr_va_ss_shift_arg;     	// Shift of the V1/2 of acitvation steady state     mV
	bool IKr_va_tau_shift_arg;    	// Shift of the voltage dependence of time constant mV
	bool IKr_va_ss_kscale_arg;    	// Scales the gradient parameter of activation steady state
	bool IKr_vi_ss_shift_arg;     	// Shift of the V1/2 of acitvation steady state     mV
	bool IKr_vi_ss_kscale_arg;    	// Scales the gradient parameter of activation steady state
	bool IKs_va_ss_shift_arg;     	// Shift of the V1/2 of acitvation steady state     mV
	bool IKs_va_tau_shift_arg;    	// Shift of the voltage dependence of time constant mV
	bool IKs_va_ss_kscale_arg;    	// Scales the gradient parameter of activation steady state
	bool IK1_va_shift_arg;        	// Shift of the V1/2 of acitvation steady state     mV
	bool Gup_arg;                 	// Scale factor of intracellular, SERCA Ca2+ uptake
	bool Gleak_arg;               	// Scale factor of intracellular Ca2+ leak 
	bool Grel_arg;               	// Scale factor of intracellular Ca2+ release
	// end boolean switches =======================================\\|

}Argument_parameters;
// End Define the arguments struct ==============================================================//|


#endif


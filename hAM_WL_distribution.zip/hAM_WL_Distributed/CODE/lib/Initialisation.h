// Initialisation header file =============================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  // 
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#ifndef SETTINGS_H
#define SETTINGS_H

#include "Structs.h"
#include "Arguments.h"


// Simulation settings functons
void set_simulation_defaults(Simulation_parameters *sim, double dt);
void set_simulation_settings(Simulation_parameters *sim, Argument_parameters A,  const char * Model_type);
void output_settings(Simulation_parameters sim, char const * directory, bool DC_current_mod_arg, Cell_parameters p);
void output_settings_tissue(Simulation_parameters sim, Tissue_parameters t, char const * directory);
void output_settings_3D_cell(Cell_parameters p, Simulation_parameters sim, CRU_variables cru, char const * directory);

// Model conditions
void set_model_conditions(Cell_parameters *p, Argument_parameters A);
void set_local_model_conditions(Cell_parameters p_in, Cell_parameters *p); // For tissue models only

// Parameter defaults 
void set_default_parameters(Cell_parameters *p);
void set_parameters_spatial_Ca_defaults(Cell_parameters *p);
void update_parameters_spatial_Ca_0D(Cell_parameters *p);

// Current modification variables
void set_modification_defaults_native(Cell_parameters *p);
void assign_modification_from_arguments(Cell_parameters *p, Argument_parameters A);

#endif

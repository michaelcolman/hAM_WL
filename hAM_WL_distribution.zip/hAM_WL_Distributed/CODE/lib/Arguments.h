// Argument handling header file ==========================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#ifndef ARGUMENTS_H
#define ARGUMENTS_H

#include "Structs.h"

void set_argument_defaults(Argument_parameters *A);					 // Sets all booleans to false
void set_arguments(int Narg, char *argin[], Argument_parameters *A, char const * Version);
#endif

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //

#ifndef SRF_H
#define SRF_H

#include "Structs.h"
#include <math.h>

// Defaults and setup
void set_SRF_defaults(Spontaneous_release_functions *srf);
void SRF_setup(Spontaneous_release_functions *srf);

// Parameter sets
void set_SRF_defined_parameters(Spontaneous_release_functions *srf);

// Set and run
void set_and_run_SRF(Spontaneous_release_functions *srf, Dyad_variables *d, const char * Mode, RAND *rand, int ex_switch, double sim_time, double CaJSR);
void run_SRF(Spontaneous_release_functions *srf, Dyad_variables *d, double sim_time);
void calc_SRF_mults(Spontaneous_release_functions *srf, Membrane_fluxes *mem, Dyad_variables *dyad);

// Waveform
void Determine_waveform_parameters(Spontaneous_release_functions *srf);
void Waveform(Spontaneous_release_functions *srf, double t);

// Distribution functions
void Determine_ti(Spontaneous_release_functions *srf, double rand);

void Determine_duration(Spontaneous_release_functions *srf, double rand);
void Determine_duration_ks_from_MD(Spontaneous_release_functions *srf);

void Determine_NRyRo_peak(Spontaneous_release_functions *srf, double duration, double rand);

// Test and produce
void test_and_produce_distributions(Spontaneous_release_functions *srf, const char * directory, RAND *r);

#endif


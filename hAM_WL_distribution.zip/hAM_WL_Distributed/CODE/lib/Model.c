// Global model file ======================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include "Model.h"
#include "Structs.h"
// Functions to select appropriate specific functions ===========================================\\|
void set_parameters_native(Cell_parameters *p, char const *Model)
{
	if (strcmp(Model, "minimal") == 0)						set_parameters_native_minimal(p);			// lib/Model_minimal.cpp
	else if (strcmp(Model, "hAM_GB") == 0)					set_parameters_native_hAM_GB(p);			// lib/Model_hAM_GB.cpp
	else if (strcmp(Model, "hAM_CRN") == 0)					set_parameters_native_hAM_CRN(p);			// lib/Model_hAM_CRN.cpp
	else if (strcmp(Model, "hAM_NG") == 0)					set_parameters_native_hAM_NG(p);			// lib/Model_hAM_NG.cpp
	else if (strcmp(Model, "ratAM_CAL") == 0)				set_parameters_native_ratAM_CAL(p);			// lib/Model_ratAM_CAL.cpp
	else if (strcmp(Model, "hAM_MT") == 0)					
	{
		set_parameters_native_hAM_NG(p);																// lib/Model_hAM_NG.cpp
		update_parameters_native_hAM_MT(p);																// lib/Model_hAM_MT.cpp
	}
	else if (strcmp(Model, "hAM_WL_CRN") == 0 || strcmp(Model, "hAM_CRN_mWL") == 0)					
	{
		set_parameters_native_hAM_CRN(p);           													// lib/Model_hAM_CRN.cpp
		update_parameters_native_hAM_WL(p);         													// lib/Model_hAM_WL.cpp
	}
	else if (strcmp(Model, "hAM_WL_GB") == 0 || strcmp(Model, "hAM_GB_mWL") == 0)
	{
		set_parameters_native_hAM_GB(p);																// lib/Model_hAM_CRN.cpp
		update_parameters_native_hAM_WL(p);																// lib/Model_hAM_WL.cpp
	}
	else if (strcmp(Model, "hAM_NG_mWL") == 0)
	{
		set_parameters_native_hAM_NG(p);																// lib/Model_hAM_NG.cpp
		update_parameters_native_hAM_WL(p);																// lib/Model_hAM_WL.cpp
	}
	else
	{
		printf("ERROR: \"%s\" is not a valid model type, parameters cannot be set\n\n", Model);
		exit(1);
	}
}

void initial_conditions_native(State_variables *s, Cell_parameters p, char const *Model)
{
	if (strcmp(Model, "minimal") == 0)      				initial_conditions_native_minimal(s, p);    // lib/Model_minimal.cpp
	else if (strcmp(Model, "hAM_CRN") == 0)  				initial_conditions_native_hAM_CRN(s, p);    // lib/Model_hAM_CRN.cpp
	else if (strcmp(Model, "hAM_GB") == 0)  				initial_conditions_native_hAM_GB(s, p);     // lib/Model_hAM_GB.cpp
	else if (strcmp(Model, "hAM_NG") == 0)  				initial_conditions_native_hAM_NG(s, p);    	// lib/Model_hAM_NG.cpp
	else if (strcmp(Model, "ratAM_CAL") == 0)  				initial_conditions_native_ratAM_CAL(s, p);  // lib/Model_ratAM_CAL.cpp
	else if (strcmp(Model, "hAM_MT") == 0)  				initial_conditions_native_hAM_MT(s, p);    	// lib/Model_hAM_MT.cpp
	else if (strcmp(Model, "hAM_WL_CRN") == 0) 				initial_conditions_native_hAM_WL(s, p);   	// lib/Model_hAM_WL.cpp
	else if (strcmp(Model, "hAM_CRN_mWL") == 0)				initial_conditions_native_hAM_WL(s, p);    	// lib/Model_hAM_WL.cpp
	else if (strcmp(Model, "hAM_WL_GB") == 0) 				initial_conditions_native_hAM_WL(s, p);     // lib/Model_hAM_WL.cpp
	else if (strcmp(Model, "hAM_GB_mWL") == 0) 				initial_conditions_native_hAM_WL(s, p);     // lib/Model_hAM_WL.cpp
	else if (strcmp(Model, "hAM_NG_mWL") == 0) 				initial_conditions_native_hAM_WL(s, p);    	// lib/Model_hAM_WL.cpp
	else
	{
		printf("ERROR: \"%s\" is not a valid model type, initial conditions cannot be set\n\n", Model);
		exit(1);
	}
}

void compute_model_native(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	if (strcmp(p.Model, "minimal") == 0)      					compute_model_minimal_native(p, var, s, Vm, dt); 		// lib/Model_minimal.cpp
	else if (strcmp(p.Model, "hAM_CRN") == 0)   				compute_model_hAM_CRN_native(p, var, s, Vm, dt); 		// lib/Model_hAM_CRN.cpp
	else if (strcmp(p.Model, "hAM_GB") == 0)    				compute_model_hAM_GB_native(p, var, s, Vm, dt); 		// lib/Model_hAM_GB.cpp
	else if (strcmp(p.Model, "hAM_NG") == 0)   					compute_model_hAM_NG_native(p, var, s, Vm, dt); 		// lib/Model_hAM_NG.cpp
	else if (strcmp(p.Model, "ratAM_CAL") == 0)  				compute_model_ratAM_CAL_native(p, var, s, Vm, dt); 		// lib/Model_ratAM_CAL.cpp
	else if (strcmp(p.Model, "hAM_MT") == 0)   					compute_model_hAM_MT_native(p, var, s, Vm, dt); 		// lib/Model_hAM_MT.cpp
	else if (strcmp(p.Model, "hAM_WL_CRN") == 0)   				compute_model_hAM_WL_native(p, var, s, Vm, dt); 		// lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_CRN_mWL") == 0)   			compute_model_hAM_WL_native(p, var, s, Vm, dt); 		// lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_WL_GB") == 0)    				compute_model_hAM_WL_native(p, var, s, Vm, dt); 		// lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_GB_mWL") == 0)    			compute_model_hAM_WL_native(p, var, s, Vm, dt); 		// lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_NG_mWL") == 0) 				compute_model_hAM_WL_native(p, var, s, Vm, dt); 		// lib/Model_hAM_WL.cpp
	else
	{
		printf("ERROR: \"%s\" is not a valid model type, model cannot be computed. See \"compute_model_native()\" in \"lib/Model.c\" for options\n\n", p.Model);
		exit(1);
	}
}

void compute_model_integrated(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	if (strcmp(p.Model, "minimal") == 0)                        compute_model_minimal_integrated(p, var, s, Vm, dt);        // lib/Model_minimal.cpp
	else
	{
		printf("ERROR: \"%s\" is not a valid model type, model cannot be computed. See \"compute_model_native()\" in \"lib/Model.c\" for options\n\n", p.Model);
		exit(1);
	}
}

void compute_and_output_current_functions(Cell_parameters p, Model_variables *var, char const *directory)
{
	if (strcmp(p.Model, "minimal") == 0)        				compute_and_output_current_functions_minimal(p, var, directory);    // lib/Model_minimal.cpp
	else if (strcmp(p.Model, "hAM_CRN") == 0)   				compute_and_output_current_functions_hAM_CRN(p, var, directory);  	// lib/Model_hAM_CRN.cpp
	else if (strcmp(p.Model, "hAM_GB") == 0)    				compute_and_output_current_functions_hAM_GB(p, var, directory);     // lib/Model_hAM_GB.cpp
	else if (strcmp(p.Model, "hAM_NG") == 0)   					compute_and_output_current_functions_hAM_NG(p, var, directory);  	// lib/Model_hAM_NG.cpp
	else if (strcmp(p.Model, "ratAM_CAL") == 0)   				compute_and_output_current_functions_ratAM_CAL(p, var, directory); 	// lib/Model_ratAM_CAL.cpp
	else if (strcmp(p.Model, "hAM_MT") == 0)   					compute_and_output_current_functions_hAM_MT(p, var, directory);  	// lib/Model_hAM_MT.cpp
	else if (strcmp(p.Model, "hAM_WL_CRN") == 0)   				compute_and_output_current_functions_hAM_WL(p, var, directory);  	// lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_CRN_mWL") == 0)  				compute_and_output_current_functions_hAM_WL(p, var, directory);  	// lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_WL_GB") == 0)   				compute_and_output_current_functions_hAM_WL(p, var, directory);     // lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_GB_mWL") == 0)   				compute_and_output_current_functions_hAM_WL(p, var, directory);     // lib/Model_hAM_WL.cpp
	else if (strcmp(p.Model, "hAM_NG_mWL") == 0) 				compute_and_output_current_functions_hAM_WL(p, var, directory);  	// lib/Model_hAM_WL.cpp
	else 
	{
		printf("WARNING: \"%s\" has no function to compute and output model equations; nothing has been done\n\n", p.Model);
	}
}
// End Functions to select appropriate specific functions =======================================//|

// Stimulus current =============================================================================\\|
void stimulus_setup(Cell_parameters p, Model_variables *var, double dt, int BCL, int S2, int Paced_time)
{
	var->stimduration_int		= p.stimduration*(1/dt);
	var->BCL_int				= BCL * (int)(1/dt);
	var->stimflag				= false;
	var->S2_stimflag			= false;
	var->stimcount				= 0;
	var->stimcount_S2			= 0;
	var->Istim					= 0.0;
	var->Istim_S2				= 0.0;
	var->S2_int					= S2 * (int)(1/dt);
	var->Paced_time_int			= Paced_time * (int)(1/dt);
}

void compute_Istim(Cell_parameters p, Model_variables *var, double Paced_time, double S2_time, double time, int time_int)
{
	// S1
	if( (time_int == 0 || time_int % var->BCL_int == 0) && time < Paced_time)
	{
		var->stimflag			= true;
		var->ex_switch     		= 0;	// To reset measurement values, even if AP not < rep threshold at time of stimulus
	}

	if (var->stimflag == true)
	{
		var->Istim				= p.stimmag;
		var->stimcount++;
		if (var->stimcount >= var->stimduration_int)
		{
			var->stimflag		= false;
			var->stimcount		= 0;
		} // end stimcount > duration_int IF
	} // end stimflag = true IF
	else var->Istim				= 0.0;

	// S2
	if (time > Paced_time && var->S2_int > 0)
	{
		if( ((time_int - (var->Paced_time_int-5) )% var->S2_int == 0) && time < S2_time)
		{
			var->S2_stimflag           = true;
			var->ex_switch     			= 0;	// To reset measurement values, even if AP not < rep threshold at time of stimulus
		}

		if (var->S2_stimflag == true)
		{
			var->Istim_S2           = p.stimmag;
			var->stimcount_S2++;
			if (var->stimcount_S2 >= var->stimduration_int)
			{
				var->S2_stimflag       = false;
				var->stimcount_S2      = 0;
			} // end stimcount > duration_int IF
		} // end stimflag = true IF
		else var->Istim_S2            = 0.0;
	}
}
// End Stimulus current =========================================================================//|

// Current modification variables | Het and modulation ==========================================\\|
// Global selection function ==========================================================\\|
void set_heterogeneity_and_modulation_native(Cell_parameters *p)
{
	// Sets global or common het and/or modulation
	// then calls model specific functions for single-model het and/or modulation if global functions did not actually set the parameter
	// (All "X_set_ref" start off = 0; as global/common function is called, set to 1 to indicate function call. If the specific option
	// is not caught by one IF statement in global/common function (i.e. not been set) the "X_set_ref" set back to 0
	// and specific functions are called. If not specific function, error is returned; if option not caught by IF within specific function
	// error also returned (within specific function found in Model_X.cpp)
	// Only one value may be contained in each type (celltype, ISO/ISO_model, Agent, Remodelling, Mutation) at a time; multiple different
	// types may be specified simulataneously

	// Heterogeneity (celltypes) =============================\\|
	if (strcmp(p->Celltype, "default") == 0); 		// Do nothing - only for models with no het settings
	else
	{	
		// Heterogeneity common to multiple or all models
		if (p->hAM == true) 		set_celltype_hAM(p);	// multiple human atrial models
		// set_MODIFIER_X_Y(Cell_parameters *p); or
		// if (strcmp(p->Model, "X_Y") == 0 || strcmp(p->Model, "X_Z") == 0 || strcmp(p->Model, "X_Q") == 0 ...) set_MODIFIER_X_Y(Cell_parameters *p);

		// Model specific (note: not else so that common and specific can be set)
		if (p->Het_set_ref == 0) 	// == 1 if it has already been set in previous global/common function; 0 if not set
		{
			if (strcmp(p->Model, "minimal") == 0)      				set_celltype_native_minimal(p);       	// lib/Model_minimal.cpp
			else if (strcmp(p->Model, "hAM_CRN") == 0)   			set_celltype_native_hAM_CRN(p);       	// lib/Model_hAM_CRN.cpp
			else if (strcmp(p->Model, "hAM_GB") == 0)   			set_celltype_native_hAM_GB(p);       	// lib/Model_hAM_GB.cpp
			else if (strcmp(p->Model, "hAM_NG") == 0)   			set_celltype_native_hAM_NG(p);       	// lib/Model_hAM_NG.cpp
			else if (strcmp(p->Model, "hAM_MT") == 0)   			set_celltype_native_hAM_MT(p);       	// lib/Model_hAM_MT.cpp
			else if (strcmp(p->Model, "hAM_WL_CRN") == 0)  			set_celltype_native_hAM_WL(p);       	// lib/Model_hAM_WL.cpp
			else if (strcmp(p->Model, "hAM_CRN_mWL") == 0) 			set_celltype_native_hAM_WL(p);       	// lib/Model_hAM_WL.cpp
			else if (strcmp(p->Model, "hAM_WL_GB") == 0)   			set_celltype_native_hAM_WL(p);       	// lib/Model_hAM_WL.cpp
			else if (strcmp(p->Model, "hAM_GB_mWL") == 0)  			set_celltype_native_hAM_WL(p);       	// lib/Model_hAM_WL.cpp
			else if (strcmp(p->Model, "hAM_NG_mWL") == 0)  			set_celltype_native_hAM_WL(p);       	// lib/Model_hAM_WL.cpp
			else if (strcmp(p->Model, "ratAM_CAL") == 0) 			set_celltype_native_ratAM_CAL(p);  		// lib/Model_ratAM_CAL.cpp
			else
            {
                printf("ERROR: \"%s\" has no options for Celltype  \"%s\"; nothing has been set global or specific, but celltype is not default!\n", p->Model, p->Celltype);
                exit(1);
            }
		}	//end specific function call if
	}
	// End Heterogeneity (celltypes) =========================//|

	// Modulation (drugs, remodelling, autonomic etc) ========\\|
	// ISO ==============================================\\|
	if (p->ISO <= 0.0);		// Do nothing
	else
	{
		// Global/common
		if (p->hAM == true) set_ISO_hAM(p);	// human atrial models
		// set_MODIFIER_X_Y(Cell_parameters *p); or
		// if (strcmp(p->Model, "X_Y") == 0 || strcmp(p->Model, "X_Z") == 0 || strcmp(p->Model, "X_Q") == 0 ...) set_MODIFIER_X_Y(Cell_parameters *p);

		// Specific
		if (p->ISO_set_ref == 0)    // == 1 if it has already been set in previous global/common function; 0 if not set
		{
			if (strcmp(p->Model, "minimal") == 0)      		set_modulation_ISO_native_minimal(p);      	// lib/Model_minimal.cpp
			else if (strcmp(p->Model, "hAM_CRN") == 0) 		set_modulation_ISO_native_CRN(p);       	// lib/Model_CRN.cpp
			else if (strcmp(p->Model, "hAM_GB") == 0)  		set_modulation_ISO_native_GB(p);      		// lib/Model_GB.cpp
			else if (strcmp(p->Model, "hAM_NG") == 0)  		set_modulation_ISO_native_NG(p);      		// lib/Model_NG.cpp
			else if (strcmp(p->Model, "hAM_MT") == 0)  		set_modulation_ISO_native_MT(p);      		// lib/Model_MT.cpp
			else if (strcmp(p->Model, "hAM_WL_CRN") == 0)  	set_modulation_ISO_native_WL(p);      		// lib/Model_WL.cpp
			else if (strcmp(p->Model, "hAM_WL_GB") == 0)  	set_modulation_ISO_native_WL(p);      		// lib/Model_WL.cpp
			else if (strcmp(p->Model, "hAM_CRN_mWL") == 0) 	set_modulation_ISO_native_WL(p);      		// lib/Model_WL.cpp
			else if (strcmp(p->Model, "hAM_GB_mWL") == 0)  	set_modulation_ISO_native_WL(p);      		// lib/Model_WL.cpp
			else if (strcmp(p->Model, "hAM_NG_mWL") == 0)  	set_modulation_ISO_native_WL(p);      		// lib/Model_WL.cpp
			else
			{
				printf("ERROR: \"%s\" has no options for ISO model \"%s\"; nothing has been set global or specific, but ISO conc is non zero!\n", p->Model, p->ISO_model);
				exit(1);
			}
		} //end specific function call if
	}
	// End ISO ==========================================//|

	// Pharmacological Agent ============================\\|
	if (strcmp(p->Agent, "none") == 0);		// Do nothing
	else 
	{
		// Global/common
		set_global_Agents(p);				// Sets any pharma agents which apply to all models
		// set_MODIFIER_X_Y(Cell_parameters *p); or
		// if (strcmp(p->Model, "X_Y") == 0 || strcmp(p->Model, "X_Z") == 0 || strcmp(p->Model, "X_Q") == 0 ...) set_MODIFIER_X_Y(Cell_parameters *p);

		// Specific (model specific agents)
		if (p->Agent_set_ref == 0)	// == 1 if it has already been set in previous global/common function; 0 if not set
		{
			if (strcmp(p->Model, "minimal") == 0)      		set_modulation_Agent_native_minimal(p);     // lib/Model_minimal.cpp
			else if (strcmp(p->Model, "hAM_CRN") == 0)      set_modulation_Agent_native_CRN(p);         // lib/Model_CRN.cpp
            else if (strcmp(p->Model, "hAM_GB") == 0)       set_modulation_Agent_native_GB(p);          // lib/Model_GB.cpp
            else if (strcmp(p->Model, "hAM_NG") == 0)       set_modulation_Agent_native_NG(p);          // lib/Model_NG.cpp
            else if (strcmp(p->Model, "hAM_MT") == 0)       set_modulation_Agent_native_MT(p);          // lib/Model_MT.cpp
            else if (strcmp(p->Model, "hAM_WL_CRN") == 0)   set_modulation_Agent_native_WL(p);          // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_WL_GB") == 0)    set_modulation_Agent_native_WL(p);          // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_CRN_mWL") == 0)  set_modulation_Agent_native_WL(p);          // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_GB_mWL") == 0)   set_modulation_Agent_native_WL(p);          // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_NG_mWL") == 0)   set_modulation_Agent_native_WL(p);          // lib/Model_WL.cpp
			else
			{
				printf("ERROR: \"%s\" is not a valid Agent for \"%s\". Please check Model.c for options\n\n", p->Agent, p->Model);
				exit(1);
			}
		}
	}
	// End Pharmacological Agent ========================//|

	// Remodelling ======================================\\|
	if (strcmp(p->Remodelling, "none") == 0);	// Do nothing
	else
	{
		// Global/common
		set_global_remodelling(p);
		if (p->hAM == true) set_remodelling_hAM(p); // human atrial models
		// set_MODIFIER_X_Y(Cell_parameters *p); or
		// if (strcmp(p->Model, "X_Y") == 0 || strcmp(p->Model, "X_Z") == 0 || strcmp(p->Model, "X_Q") == 0 ...) set_MODIFIER_X_Y(Cell_parameters *p);

		// Specific
		if (p->Remodelling_set_ref == 0) // == 1 if it has already been set in previous global/common function; 0 if not set
		{
			if (strcmp(p->Model, "minimal") == 0)      		set_modulation_Remodelling_native_minimal(p);   // lib/Model_minimal.cpp
			else if (strcmp(p->Model, "hAM_CRN") == 0)      set_modulation_Remodelling_native_CRN(p);       // lib/Model_CRN.cpp
            else if (strcmp(p->Model, "hAM_GB") == 0)       set_modulation_Remodelling_native_GB(p);        // lib/Model_GB.cpp
            else if (strcmp(p->Model, "hAM_NG") == 0)       set_modulation_Remodelling_native_NG(p);        // lib/Model_NG.cpp
            else if (strcmp(p->Model, "hAM_MT") == 0)       set_modulation_Remodelling_native_MT(p);        // lib/Model_MT.cpp
            else if (strcmp(p->Model, "hAM_WL_CRN") == 0)   set_modulation_Remodelling_native_WL(p);        // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_WL_GB") == 0)    set_modulation_Remodelling_native_WL(p);        // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_CRN_mWL") == 0)  set_modulation_Remodelling_native_WL(p);        // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_GB_mWL") == 0)   set_modulation_Remodelling_native_WL(p);        // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_NG_mWL") == 0)   set_modulation_Remodelling_native_WL(p);  		// lib/Model_WL.cpp
            else if (strcmp(p->Model, "ratAM_CAL") == 0)    set_modulation_Remodelling_native_ratAM_CAL(p);       // lib/Model_ratAM_CAL.cpp
			else
			{
				printf("ERROR: \"%s\" is not a valid Remodelling model for \"%s\". Please check Model.c for options\n", p->Remodelling, p->Model);
				exit(1);
			}
		}
	}
	// End Remodelling ==================================//|

	// Mutation ======================================\\|
	if (strcmp(p->Mutation, "none") == 0);   // Do nothing
	else
	{
		// Global/common
		if (p->hAM == true) set_mutation_hAM(p); // human atrial models
		// set_MODIFIER_X_Y(Cell_parameters *p); or
		// if (strcmp(p->Model, "X_Y") == 0 || strcmp(p->Model, "X_Z") == 0 || strcmp(p->Model, "X_Q") == 0 ...) set_MODIFIER_X_Y(Cell_parameters *p);

		// Specific
		if (p->Mutation_set_ref == 0) // == 1 if it has already been set in previous global/common function; 0 if not set
		{
			if (strcmp(p->Model, "minimal") == 0)      		set_modulation_Mutation_native_minimal(p);       // lib/Model_minimal.cpp
			else if (strcmp(p->Model, "hAM_CRN") == 0)      set_modulation_Mutation_native_CRN(p);           // lib/Model_CRN.cpp
            else if (strcmp(p->Model, "hAM_GB") == 0)       set_modulation_Mutation_native_GB(p);            // lib/Model_GB.cpp
            else if (strcmp(p->Model, "hAM_NG") == 0)       set_modulation_Mutation_native_NG(p);            // lib/Model_NG.cpp
            else if (strcmp(p->Model, "hAM_MT") == 0)       set_modulation_Mutation_native_MT(p);            // lib/Model_MT.cpp
            else if (strcmp(p->Model, "hAM_WL_CRN") == 0)   set_modulation_Mutation_native_WL(p);            // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_WL_GB") == 0)    set_modulation_Mutation_native_WL(p);            // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_CRN_mWL") == 0)  set_modulation_Mutation_native_WL(p);            // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_GB_mWL") == 0)   set_modulation_Mutation_native_WL(p);            // lib/Model_WL.cpp
            else if (strcmp(p->Model, "hAM_NG_mWL") == 0)   set_modulation_Mutation_native_WL(p);            // lib/Model_WL.cpp
			else
			{
				printf("ERROR: \"%s\" is not a valid Mutation model for \"%s\". Please check Model.c for options\n", p->Mutation, p->Model);
				exit(1);
			}
		}
	}
	// End Mutation ==================================//|
	// End modulation (drugs, remodelling, autonomic etc) ====//|
}
// End Global selection function ======================================================//|

// Global or common functions =========================================================\\|
// Template ==============================\\|
void set_MODIFIER_X_Y(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	// Note: setting X_set_ref to 1 and then 0 if not set is important for error checking
	// and for being able to jump into global/common AND specific functions properly

	// Start =====
	// p->X_set_ref = 1; // Indicates X(=ISO/Agent/Celltype/Remodeling/Mutation) has been set
	// if (strcmp(p->X, "SPECIFIER") == 0) { do stuff }
	// else if (strcmp(p->X, "SPECIFIER2") == 0) { do stuff }
	// etc
	// else p->X_set_ref = 0; // Indicates X=(Mutation/Agent/Celltype/Remodeling/Mutation) has not actually been set
	// End =======
}
// End template ==========================//|

// Pharma agents =========================\\|
void set_global_Agents(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	p->Agent_set_ref			= 1; // Indicates Agent has been set (is set back to zero if not caught by any below IF statement)

	if (strcmp(p->Agent, "MC-II-157c") == 0)
	{
		p->IKr_va_ss_shift      += 14;
		p->GKr                  *= 0.88;
	}
	// testing exmaple illustration of implementation
	else if (strcmp(p->Agent, "test_global") == 0)
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new pharmacological agent here: else if (strcmp(p->Agent, "X") == 0) {   }
	else p->Agent_set_ref		= 0;	// Sets back to zero to indicate Agent has not been set despite function call
}
// End Pharma agents =====================//|

// Heterogeneity =========================\\|
void set_celltype_hAM(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	p->Het_set_ref		= 1; // Indicates heterogeneity has been set (is set back to zero if not caught by any below IF statement)

	// Heterogeneity according to Colman et al. 2013 J Physiol 591(17):4249-72
	if (strcmp(p->Celltype, "RA") == 0); // do nothing as default (here for error checking)
	else if (strcmp(p->Celltype, "PM") == 0)
	{
		p->GCaL     *= 0.94;
	}
	else if (strcmp(p->Celltype, "CT") == 0)
	{
		p->GCaL     *= 1.68;
		p->Gto      *= 1.35;
	}
	else if (strcmp(p->Celltype, "RAA") == 0)
	{
		p->GCaL     		*= 1.68;
		p->Gto      		*= 0.4;
		p->IKur_va_ss_shift += 14;
		p->IKur_vi_ss_shift += -25;
		p->IKur_vi_ss_kscale *= 1.769;
	}
	else if (strcmp(p->Celltype, "AVR") == 0)
	{
		p->GCaL     *= 0.67;
		p->Gto      *= 0.6;
		p->GKr		*= 1.63;
	}
	else if (strcmp(p->Celltype, "BB") == 0)
	{
		p->GCaL     *= 2.32;
		p->Gto      *= 1.17;
		p->GK1		*= 0.85;
	}
	else if (strcmp(p->Celltype, "LA") == 0)
	{
		p->GKr     	*= 1.6;
		p->Gto     	*= 0.53;
		p->GKs		*= 1.8;
		p->IKs_va_ss_shift 	+= -13.43;
		p->IKs_va_ss_kscale *= 0.5;
	}
	else if (strcmp(p->Celltype, "AS") == 0)
	{
		p->GCaL             *= 0.4;
		p->Gto              *= 0.4*0.4;
		p->GKur				*= 0.677;
		p->IKur_va_ss_shift += 14;
		p->IKur_vi_ss_shift += -25;
		p->IKur_vi_ss_kscale *= 1.769;
	}
	else if (strcmp(p->Celltype, "LAA") == 0)
	{
		p->GCaL             *= 1.68;
		p->Gto              *= 0.4;
		p->GKur				*= 0.8;
		p->GKr      		*= 1.6;
		p->Gto      		*= 0.53;
		p->GKs      		*= 1.8;
		p->IKur_va_ss_shift += 14;
		p->IKur_vi_ss_shift += -25;
		p->IKur_va_ss_kscale *= 2.13;
		p->IKur_vi_ss_kscale *= 1.769;
	}
	else if (strcmp(p->Celltype, "PV") == 0)
	{
		p->Gto 	*= 0.75;
		p->GCaL *= 0.75;
		p->GKr 	*= 2.4;
		p->GKs 	*= 1.87;
		p->GK1 	*= 0.67;
	}
	// End Col 2013 het

	// testing exmaple illustration of implementation
	else if (strcmp(p->Celltype, "test_global") == 0)
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new celltypes here: else if (strcmp(p->Celltype, "X") == 0) {   }

	else p->Het_set_ref = 0;  // Sets back to zero to indicate celltype has not been set despite function call
}
// End heterogeneity =====================//|

// ISO ===================================\\|
void set_ISO_hAM(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	p->ISO_set_ref            = 1; // Indicates ISO has been set (is set back to zero if not caught by any below IF statement)

	if (strcmp(p->ISO_model, "Col") == 0)
	{
		p->GCaL             *= (1.0 + p->ISO*1.0    );
		p->GKur             *= (1.0 + p->ISO*0.6    );
		p->GKs              *= (1.0 + p->ISO*1.5    );
		p->Gup              *= (1.0 + p->ISO*1.5    );
		p->GNa              *= (1.0 + p->ISO*0.25   );
		p->ICaL_va_ss_shift += (p->ISO*-5);
	}
	else if (strcmp(p->ISO_model, "GB") == 0)
	{
		p->GCaL                 *= (1.0 + p->ISO*0.5);
		p->GKur                 *= (1.0 + p->ISO*2.0);
		p->GKs                  *= (1.0 + p->ISO*2.0);
		p->ICaL_va_ss_shift     += (p->ISO*-3);
		p->ICaL_vi_ss_shift     += (p->ISO*-3);
		p->ICaL_va_tau_shift    += (p->ISO*-3);
		p->ICaL_vi_tau_shift    += (p->ISO*-3);
		p->IKs_va_ss_shift      += (p->ISO*-40);
		p->IKs_va_tau_shift     += (p->ISO*-40);
		p->koCa                 += (p->ISO*10); // GB Ca handling only
		p->INaK_kNa         	*= (1.0 - p->ISO*0.25);
		p->Kmf					*= (1.0 - p->ISO*0.5);
		p->koff_tncl			*= (1.0 + p->ISO*0.5);
	}
	else p->ISO_set_ref       = 0; // Sets back to zero to indicate ISO has not been set despite function call
}
// End ISO ===============================//|

// Remodelling ===========================\\|
void set_global_remodelling(Cell_parameters *p)
{
	// Start =====
	p->Remodelling_set_ref = 1; // Indicates X(=ISO/Agent/Celltype/Remodeling/Mutation) has been set
	if (strcmp(p->Remodelling, "Toy_1") == 0)
	{
		p->GK1				*= 0.5;
		p->IK1_va_shift		+= 10;	
		p->Gup				*= 1.5;
		p->GCaL				*= 0.5;
		p->GNCX				*= 0.5;
		p->GKr				*= 1.5;
		p->GNa				*= 0.5;		
	}
	// else if (strcmp(p->X, "SPECIFIER2") == 0) { do stuff }
	// etc
	else p->Remodelling_set_ref = 0; // Indicates X=(Mutation/Agent/Celltype/Remodeling/Mutation) has not actually been set
	// End =======
}
void set_remodelling_hAM(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	p->Remodelling_set_ref            = 1; // Indicates Remodelling has been set (is set back to zero if not caught by any below IF statement)

	// AF remodelling models ========\\|
	// Grandi et al. 2011 model
	if (strcmp(p->Remodelling, "AF_GB") == 0)
	{	
		p->GNa					*= 0.9;
		p->gNaL					= 0.0025; // (s/mF) NOTE: this is zero if no remodelling, so must be set rather than multiplied!
		p->GKs					*= 2;
		p->Gto					*= 0.3;
		p->GK1					*= 2;
		p->GCaL					*= 0.3;
		p->GNCX					*= 1.4;
		p->GKur					*= 0.5;
		p->Grel					*= 3;	// (equiv of +20 to baselene of 10 in GB model)
		p->Gleak				*= 1.25;
	}
	//Colman et al. 2013 J Physiol 591(17):4249-72 models	
	else if (strcmp(p->Remodelling, "AF_Col_1") == 0) // 
	{
		p->GCaL					*= 0.3;
		p->Gto					*= 0.3;	
		p->Ito_va_ss_shift 		+= 16;
		p->GK1					*= 2;
		p->ICaL_vi_tau_scale 	*= 1.62;	
	}
	else if (strcmp(p->Remodelling, "AF_Col_2") == 0) // 
	{
		p->GCaL                 *= 0.37;
		p->Gto                  *= 0.34;
		p->GKur					*= 0.51;
		p->GK1					*= 2.06;
	}
	else if (strcmp(p->Remodelling, "AF_Col_3") == 0) // 
	{
		p->GCaL                 *= 0.35;
		p->Gto                  *= 0.35;
		p->GK1                  *= 1.75;
	}
	else if (strcmp(p->Remodelling, "AF_Col_4") == 0) // 
	{
		p->GCaL                 *= 0.3;
		p->Gto                  *= 0.34;
		p->GKur                 *= 0.5;
		p->GK1                  *= 2.0;
		p->GKs					*= 2.0;
		p->GNCX					*= 1.55;
		p->Gleak				*= 1.25;
		p->Grel					*= 3;
	}
	// End AF remodelling models =====//|

	// testing exmaple illustration of implementation
	else if (strcmp(p->Mutation, "test_global") == 0)
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new mutation here: else if (strcmp(p->mutation, "X") == 0) {   }


	else p->Remodelling_set_ref       = 0; // Sets back to zero to indicate Remodelling has not been set despite function call
}
// End Remodelling =======================//|

// Mutations =============================\\|
void set_mutation_hAM(Cell_parameters *p)
{
	// Can modify parameters (e.g. conductance) directly, or scaling factors.
	// (conductance denoted "g", scale factor "G")
	// In general, use the scale factors as these are multiplicative/additive throughout
	// the code - if a parameter is set (rather than modified) it will overwrite previous
	// settings; this may or may not be desired

	p->Mutation_set_ref            = 1; // Indicates Mutation has been set (is set back to zero if not caught by any below IF statement)

	// IKur mutations as in Colman, Ni et al. 2017 PLOS Comp Biol https://doi.org/10.1371/journal.pcbi.1005587
	if (strcmp(p->Mutation, "D322H") == 0)
	{
		p->GKur					*= 1.78;
		p->IKur_va_ss_shift		+= -3.26;
		p->IKur_va_ss_kscale	*= 0.809;
		p->IKur_vi_ss_shift		+= 9.61;
		p->IKur_vi_ss_kscale	*= 0.801;
	}
	else if (strcmp(p->Mutation, "Y155C") == 0)
	{
		p->GKur					*= 0.4745;
		p->IKur_va_ss_shift		+= 0.89;
		p->IKur_va_ss_kscale	*= 0.75;
		p->IKur_vi_ss_shift		+= 5.01;
		p->IKur_vi_ss_kscale	*= 0.78;
	}
	// End IKur mutations

	// testing exmaple illustration of implementation
	else if (strcmp(p->Mutation, "test") == 0)
	{
		p->Gto              *= 2;       // Scale factor = Multiplies previous settings
		p->gKur             = 0.003;    // Actual conductance explicitly set. Will overwrite any previous settings of g, but not scale factor mods. 
		p->IKr_va_ss_kscale *= 1.25;    // Multiplies gradient parameter for voltage-activation steady-state. Multiplies previous settings
		p->ICaL_vi_ss_shift += 5;       // Shifts the voltage dependence of the steady state of inactivation gate. Summed to previous settings
		p->IKs_va_tau_scale *= 0.75;    // Multiplies time constant of voltage activation. Multiplies previous settings.
		p->Gup              *= 2;       // Scales intracellular upatke rate. Multiplies previous settings.
	}
	// Add new mutation here: else if (strcmp(p->mutation, "X") == 0) {   }

	else p->Mutation_set_ref       = 0;    // Sets back to zero to indicate Mutation has not been set despite function call
}
// End Mutations =========================//|
// End Global or common functions =====================================================//|
// End Current modification variables | Het and modulation ======================================//|

// Reveral potentials ===========================================================================\\|
void compute_reversal_potentials(Cell_parameters p, Model_variables *var, State_variables *s)
{
	var->ENa			= 		((p.R * p.T)/p.F)*log(s->Nao/s->Nai);
	var->EK				= 		((p.R * p.T)/p.F)*log(s->Ko/s->Ki);
	var->EKs            =       ((p.R * p.T)/p.F)*log((s->Ko + 0.01833*s->Nao)/(s->Ki + 0.01833*s->Nai));
	var->ECa			= 0.5*	((p.R * p.T)/p.F)*log(s->Cao/s->Cai);
	var->ECl			= 		((p.R * p.T)/p.F)*log(15.0/150.0);

	var->ENa_j			= 		((p.R * p.T)/p.F)*log(s->Nao/s->Nai_j);
	var->ENa_sl			= 		((p.R * p.T)/p.F)*log(s->Nao/s->Nai_sl);
	var->ECa_j			= 0.5*	((p.R * p.T)/p.F)*log(s->Cao/s->Cai_j);
	var->ECa_sl			= 0.5*	((p.R * p.T)/p.F)*log(s->Cao/s->Cai_sl);
}
// Compute Reveral potentials ===================================================================//|

// Excitation properties / measurements =========================================================\\|
void determine_excitation_state(Model_variables *var, double Vm, double time)
{
	if (var->ex_switch == 0)	// If currently not excited
	{
		if (Vm > -30)			// threshold to determine excited state || set defaults
		{
			var->ex_switch		= 1; 	// In excitation state
			var->APD_t_switch	= 0; 	// Ready to be calculated
			var->t_ex			= time;

			var->dvdt_max_prev	= var->dvdt_max;
			var->dvdt_max		= 0;

			var->Vmax_prev		= var->Vmax;
			var->Vmax			= -80; 	// Ensure below threshold
			var->Vmin_prev_prev = var->Vmin_prev;
			var->Vmin_prev		= var->Vmin;
			var->Vmin			= 50;
			var->Vamp_prev		= var->Vamp;

			for (int i = 0; i < 9; i++) var->APD_p_switch[i] = 0;

			var->CaT_min_prev	= var->CaT_min;
			var->CaT_min		= 1;	// Ensure above values
			var->CaT_max_prev   = var->CaT_max;
			var->CaT_max		= 0;	// Ensure below values
			var->CaSR_min_prev	= var->CaSR_min;	
			var->CaSR_min		= 5000;	// Ensure above values
			var->CaSR_max_prev	= var->CaSR_max;
			var->CaSR_max		= 0;	// Ensure below values

			// Set previous APD
			var->APD_t_prev		= var->APD_t;
			for (int i = 0; i < 9; i++) var->APD_p_prev[i] = var->APD_p[i];
		}
	}
	else if (var->ex_switch == 1)    // If currently excited
	{
		if (Vm < -45)			// threshold to determine repolarised
		{
			var->ex_switch 		= 0; // no longer in excitation state
		}
	}
}

void determine_excitation_state_integrated_0D(Model_variables *var, double Vm, double time, double *Ca_JSR_t_ex, double Ca_JSR, double *dyad_SRF_prop_active, double srf_SRF_prop_active, int *srf_init, int *srf_set, const char *SRF_Mode)
{   
    if (var->ex_switch == 0)    // If currently not excited
    {
        if (Vm > -30)           // threshold to determine excited state || set defaults
        {
            var->ex_switch      = 1;    // In excitation state
            var->APD_t_switch   = 0;    // Ready to be calculated
            var->t_ex           = time;

            var->dvdt_max_prev  = var->dvdt_max;
            var->dvdt_max       = 0;

            var->Vmax_prev      = var->Vmax;
            var->Vmax           = -80;  // Ensure below threshold
            var->Vmin_prev_prev = var->Vmin_prev;
            var->Vmin_prev      = var->Vmin;
            var->Vmin           = 50;
            var->Vamp_prev      = var->Vamp;

            for (int i = 0; i < 9; i++) var->APD_p_switch[i] = 0;

            var->CaT_min_prev   = var->CaT_min;
            var->CaT_min        = 1;    // Ensure above values
            var->CaT_max_prev   = var->CaT_max;
            var->CaT_max        = 0;    // Ensure below values
            var->CaSR_min_prev  = var->CaSR_min;    
			var->CaSR_min       = 5000; // Ensure above values
			var->CaSR_max_prev  = var->CaSR_max;
			var->CaSR_max       = 0;    // Ensure below values

			// Set previous APD 
			var->APD_t_prev     = var->APD_t;
			for (int i = 0; i < 9; i++) var->APD_p_prev[i] = var->APD_p[i];

			// Set CaJSR at time of exciataion
			*Ca_JSR_t_ex    = Ca_JSR;
	
			// SRF stuff
			*dyad_SRF_prop_active	= srf_SRF_prop_active;	
			if (strcmp(SRF_Mode, "Defined") == 0)
            {
                *srf_init      = 0; // comment out if want just one static beat
                *srf_set        = 0;
            }
            else if (strcmp(SRF_Mode, "Dynamic") == 0)
            {
                *srf_set    = -1;
            }	
		}
	}
	else if (var->ex_switch == 1)    // If currently excited
	{
		if (Vm < -45)           // threshold to determine repolarised
		{
			var->ex_switch      	= 0; // no longer in excitation state
			*dyad_SRF_prop_active	= 0;		
		}
	}
}

void calculate_measurement_properties(Model_variables *var, double Vm1, double Vm2, double time, double dt, double APD_threshold, double CaT, double CaSR)
{
	// dv/dt and dv/dt_max
	var->dvdt		= (Vm2 - Vm1)/dt;
	if (var->dvdt > var->dvdt_max) var->dvdt_max = var->dvdt;

	// Max, min and amplitude
	if (Vm2 > var->Vmax)	var->Vmax = Vm2;
	if (var->dvdt <= 0.0 )if (Vm2 < var->Vmin)	var->Vmin = Vm2;  // calculate Vmin if AP is repolarising only
	var->Vamp				= var->Vmax - var->Vmin_prev; // such that amplitude is V just before stimulus to peak, not on repolarisation

	// Maxmimum and minimum Ca2+ properties
	if (CaT > var->CaT_max)		var->CaT_max = CaT;
	if (CaT < var->CaT_min)		var->CaT_min = CaT; 
	if (CaSR > var->CaSR_max)	var->CaSR_max = CaSR;
	if (CaSR < var->CaSR_min)	var->CaSR_min = CaSR; 

	// APD to set threshold
	if (var->APD_t_switch == 0)	// if in state where APD needs to be calculated (i.e. has been excited but not calculated)
	{
		if (Vm2 < APD_threshold) // if the voltage is now below the threshold
		{
			var->APD_t			= time - var->t_ex;
			var->APD_t_switch	= 1;	// Been calculated
		}
	}

	// APD to different percentages
	double perc, threshold;
	for (int i = 0; i < 9; i++)
	{
		if (var->APD_p_switch[i] == 0)	// if in state where APD needs to be calculated (i.e. has been excited but not calculated)
		{
			perc = (i+1)*10; 	// converts 0 to 10%, 8 to 90%
			perc *= 0.01;		// convers % to proportion
			threshold = var->Vmax - perc*(var->Vmax - var->Vmin_prev); // Vmin_prev is V just before excitation; current Vmax
			if (Vm2 < threshold) // if the voltage is now below the threshold
			{
				var->APD_p[i]			= time - var->t_ex;
				var->APD_p_switch[i]	= 1;	// Been calculated
			}
		}
	}
} 
// End Excitation properties / measurements =====================================================//|

// Voltage clamp ================================================================================\\|
void run_voltage_clamp(Cell_parameters p, Model_variables *var, State_variables *s, char const *directory, double dt)
{
	double Vm, Vclamp, Vhold, time, clamp_time, Vstart, Vend;
	double Ipeak, Ipeak2;
	char * filename       = (char*)malloc(500);

	FILE * I_out;
	FILE * I_out_individual;
	FILE * IV_out;

	// ICaL V clamp ===========================\\|
	printf("Applying ICaL voltage clamp\n");
	sprintf(filename, "%s/Functions/ICaL_Vclamp_traces.dat", directory);
	I_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/ICaL_IV.dat", directory);
	IV_out = fopen(filename, "wt");

	// Vclamp settings
	Vstart 		= -50;
	Vend		= 50;
	Vhold		= -50;
	clamp_time 	= 500;

	for (Vclamp = -50; Vclamp < Vend+1; Vclamp +=5)
	{
		Ipeak = 0;
		initial_conditions_native(s, p, p.Model);    // lib/Model.c
		if (int(Vclamp)%10 == 0)
		{	
			sprintf(filename, "%s/Functions/ICaL_Vclamp_trace_%.0f.dat", directory, Vclamp);
			I_out_individual = fopen(filename, "wt");
		}
		for (time = 0.0; time < 3*clamp_time; time += dt)
		{
			if (time < clamp_time || time > 2*clamp_time) Vm = Vhold;
			else Vm = Vclamp;

			compute_model_native(p, var, s, Vm, dt);

			if (Vm == Vclamp && var->ICaL < Ipeak) Ipeak = var->ICaL;

			fprintf(I_out, "%f %f %f %f\n", time, Vm, var->ICaL, s->Cai);
			if (int(Vclamp)%10 == 0) fprintf(I_out_individual, "%f %f %f %f\n", time, Vm, var->ICaL, s->Cai);
		}
		fprintf(IV_out, "%f %f\n", Vclamp, Ipeak);
		if (int(Vclamp)%10 == 0) fclose(I_out_individual);
	}

	fclose(I_out);
	fclose(IV_out);
	// End ICaL V clamp =======================//|

	// Ito/IKur V clamp =======================\\|
	printf("Applying Ito voltage clamp\n");
	sprintf(filename, "%s/Functions/Ito_Vclamp_traces.dat", directory);
	I_out = fopen(filename, "wt");
	sprintf(filename, "%s/Functions/Ito_IV.dat", directory);
	IV_out = fopen(filename, "wt");

	// Vclamp settings
	Vstart      = -50;
	Vend        = 70;
	Vhold       = -50;
	clamp_time  = 100;

	for (Vclamp = -50; Vclamp < Vend+1; Vclamp +=10)
	{
		Ipeak = Ipeak2 = 0;
		initial_conditions_native(s, p, p.Model);    // lib/Model.c
		sprintf(filename, "%s/Functions/Ito_Vclamp_trace_%.0f.dat", directory, Vclamp);
		I_out_individual = fopen(filename, "wt");
		for (time = 0.0; time < 3*clamp_time; time += dt)
		{
			if (time < clamp_time || time > 2*clamp_time) Vm = Vhold;
			else Vm = Vclamp;

			compute_model_native(p, var, s, Vm, dt);

			if (Vm == Vclamp && var->Ito > Ipeak) Ipeak = var->Ito;
			if (Vm == Vclamp && var->IKur > Ipeak2) Ipeak2 = var->IKur;

			fprintf(I_out, "%f %f %f %f %f\n", time, Vm, var->Ito, var->IKur, var->Ito+var->IKur);
			fprintf(I_out_individual, "%f %f %f %f %f\n", time, Vm, var->Ito, var->IKur, var->Ito+var->IKur);
		}
		fprintf(IV_out, "%f %f %f\n", Vclamp, Ipeak, Ipeak2);
		fclose(I_out_individual);
	}

	fclose(I_out);
	fclose(IV_out);
	// End Ito/Kur V clamp ====================//|

	// IK1 ====================================\\|
	printf("Applying IK1 voltage clamp\n");
	sprintf(filename, "%s/Functions/IK1_IV.dat", directory);
	IV_out = fopen(filename, "wt");
	for (Vclamp = -150; Vclamp < 100; Vclamp +=0.1)
	{
		Vm = Vclamp;
		compute_model_native(p, var, s, Vm, dt);
		fprintf(IV_out, "%f %f\n", Vm, var->IK1);
	}
	fclose(IV_out);
	// End IK1 ================================//|

	free(filename);
}
// End Voltage clamp ============================================================================//|

// Frequently used functions ====================================================================\\|
double rush_larsen(double y, double ss, double tau, double dt)
{
	double gate;
	gate = ss - (ss-y)*exp(-dt/tau);
	return gate;
}

double sigmoid(double V, double V_half, double k)
{
	double value;
	value = 1/(1 + exp((V - V_half)/k) );
	return value;
}
// End Frequently used functions ================================================================//|

// Luo-Rudy 1991 INa formulation ================================================================\\|
// Reference: ********************************************||
// "A model of the ventricular cardiac action potential. 
// Depolarization, repolarization, and their interaction"
// Circulation Research. 1991;68:1501-1526
// *******************************************************||
void set_INa_LR_rates(Cell_parameters p, Model_variables *var, double Vm)
{
	double Vm_ac        = Vm - p.INa_va_shift; 	// Shift of the voltage used to calculate alpha and beta, activation
	double Vm_inac      = Vm - p.INa_vi_shift;	// Shift of the voltage used to calculate alpha and beta, inactivation

	// Set Activation gate alpha and beta
	var->INa_va_al                 = 0.32*(Vm_ac+47.13)/(1-exp(-0.1*(Vm_ac+47.13)));
	if (fabs(Vm_ac + 47.13) < 1e-10) var->INa_va_al = 3.2;
	var->INa_va_bet                = 0.08*exp(-Vm_ac/11.0);

	// Set inactivation gates alphas and betas
	if (Vm_inac < -40.0)
	{
		var->INa_vi_1_al           = 0.135*exp((80+Vm_inac)/-6.8);
		var->INa_vi_1_bet          = 3.56*exp(0.079*Vm_inac)+310000*exp(0.35*Vm_inac);
		var->INa_vi_2_al           = (-127140*exp(0.2444*Vm_inac)-0.00003474*exp(-0.04391*Vm_inac))*((Vm_inac+37.78)/(1+exp(0.311*(Vm_inac+79.23))));
		var->INa_vi_2_bet          = (0.1212*exp(-0.01052*Vm_inac))/(1+exp(-0.1378*(Vm_inac+40.14)));
	}
	else
	{
		var->INa_vi_1_al           = 0;
		var->INa_vi_1_bet          = 1.0/(0.13*(1+exp((Vm_inac+10.66)/-11.1)));
		var->INa_vi_2_al           = 0;
		var->INa_vi_2_bet          = (0.3*exp(-0.0000002535*Vm_inac))/(1+exp(-0.1*(Vm_inac+32)));
	}

	// Set tau and SS from alpha and beta
	var->INa_va_tau                = 1/(var->INa_va_al + var->INa_va_bet); // 1/(a+b)
	var->INa_vi_1_tau              = 1/(var->INa_vi_1_al + var->INa_vi_1_bet);
	var->INa_vi_2_tau              = 1/(var->INa_vi_2_al + var->INa_vi_2_bet);
	var->INa_va_ss                 = var->INa_va_al * var->INa_va_tau; // a*tau
	var->INa_vi_1_ss               = var->INa_vi_1_al * var->INa_vi_1_tau;
	var->INa_vi_2_ss               = var->INa_vi_2_al * var->INa_vi_2_tau;

	var->INa_va_tau 				*= p.INa_va_tau_scale;
	var->INa_vi_1_tau 				*= p.INa_vi_1_tau_scale;
	var->INa_vi_2_tau 				*= p.INa_vi_2_tau_scale;
}

void update_gates_INa_LR(Cell_parameters p, Model_variables *var, State_variables *s, double Vm, double dt)
{
	s->INa_va                      = rush_larsen(s->INa_va, var->INa_va_ss, var->INa_va_tau, dt); // lib/Membrane.c
	s->INa_vi_1                    = rush_larsen(s->INa_vi_1, var->INa_vi_1_ss, var->INa_vi_1_tau, dt);
	s->INa_vi_2                    = rush_larsen(s->INa_vi_2, var->INa_vi_2_ss, var->INa_vi_2_tau, dt);
}

void compute_INa_LR(Cell_parameters p, Model_variables *var, State_variables *s, double Vm)
{
	var->INa    	= p.gNa * pow(s->INa_va, 3) * s->INa_vi_1 * s->INa_vi_2 * (Vm - var->ENa);
	var->INa		*= p.GNa;
}
// End Luo-Rudy 1991 INa formulation ============================================================//|

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //

#include "Spontaneous_release_functions.h"
#include "Structs.h"
#include <fstream>
#include <stdlib.h>
#include <string.h>

// Defaults and setup========================================================\\|
void set_SRF_defaults(Spontaneous_release_functions *srf)
{
	srf->Mode		= "Defined";
	srf->Model		= "3D_cell";
	srf->Pset		= "General_1";

	// RyRo vs duration params
	srf->NRyRo_peak_median_A	= 692.99;
	srf->NRyRo_peak_median_min	= 0.059;
	srf->NRyRo_peak_median_H	= -1.6;

	// Default switch settings
	srf->srf_set				= -1;
	srf->srf_calc				= -1;
	srf->waveform_init			= 0;
}

void SRF_setup(Spontaneous_release_functions *srf)
{

	if (strcmp(srf->Mode, "Defined") == 0) set_SRF_defined_parameters(srf);
	else
	{
		printf("ERROR: %s is not a valid Spontaneous Release Function mode. Please select from \"Defined\" or \"Dynamic\"", srf->Mode); 
	}
	
}
// End Defaults =============================================================//|

// Parameter sets ===========================================================\\|
// Static/defined model ===========================================\\|
void set_SRF_defined_parameters(Spontaneous_release_functions *srf)
{
	// Default duration width from median function parameters
	srf->DW_k1_A		= 276.72; // ms
	srf->DW_k1_half		= 324.11; // ms
	srf->DW_k1_k		= 70.67;
	srf->DW_k1_min		= 40;	  // ms
	srf->DW_k2_A		= 233.26; // ms
	srf->DW_k2_half		= 160.74; // ms
	srf->DW_k2_k		= 14.6;
	srf->DW_k2_min		= 53;	  // ms
	srf->duration_width = -10;	  // dummy value meaning it will be set from MD

	if (strcmp(srf->Pset, "none") == 0) srf->PSCRE	= 0;
	else if (strcmp(srf->Pset, "General_1") == 0)
	{
		srf->PSCRE			= 1.0;
		srf->CF_ti_sep		= 0.1;
		srf->ti_sep			= 500;		// relative to time of last excitation
		srf->k_ti_F1_ms		= 200;		// ms, ti-this = earliest SCRE 
		srf->k_ti_F2_ms		= 800;		// ms, ti+this = latest SCRE
		srf->MD				= 150;
		//srf->duration_width = 150;	  // dummy value meaning it will be set from MD

		// convert ms to gradient (approx)
		srf->k_ti_F1	= 0.145*srf->k_ti_F1_ms;
		srf->k_ti_F2	= 0.145*srf->k_ti_F2_ms;
	}
}
// End Static/defined model =======================================//|
// End Parameter sets =======================================================//|

// run SRF functions ========================================================\\|
void set_and_run_SRF(Spontaneous_release_functions *srf, Dyad_variables *d, const char * Mode, RAND *rand, int ex_switch, double sim_time, double CaJSR)
{
	if (strcmp(Mode, "Defined") == 0)
	{
		if (srf->srf_set == 0) // if ready to be set
		{
			srf->rand[0] = rand->mtrand1();
			if (srf->rand[0] < srf->PSCRE)	// Only need to produce other rands if event will happen
			{
				srf->srf_calc	=1;
				for (int j = 0; j < 5; j++) srf->rand[j] = rand->mtrand1();	
			}
			else
			{
				srf->srf_calc 	= 0;
				srf->srf_set	= -1; // Not ready to be set until next time (or it will check against probabilty every dt)
			}
		}
		run_SRF(srf, d, sim_time);
	} // end "Defined" if
		
}

void run_SRF(Spontaneous_release_functions *srf, Dyad_variables *d, double sim_time)
{
	double t_to_peak_rand_factor;
	srf->NRyRo	= 0;

	// if function ready to be set but not already been set
	if (srf->srf_set == 0 && srf->srf_calc == 1)
	{
		srf->tset	= sim_time; 	// store sim time at which function is set

		// Set waveform parameters
		// ti
		Determine_ti(srf, srf->rand[0]);
	
		// duration
		if (srf->duration_width == -10) Determine_duration_ks_from_MD(srf);                           // if default value, determine duration dist from average
		else                            srf->k_D_F1 = srf->k_D_F2 = 1.8*0.145*srf->duration_width;    // else set k from width in ms
		Determine_duration(srf, srf->rand[1]);

		// t to peak and decay time
		t_to_peak_rand_factor = srf->rand[2];//srf->t_to_peak_dist*(srf->rand[2]) + (1-srf->t_to_peak_dist)*0.5;
		srf->t_to_peak	= 24.0 + t_to_peak_rand_factor*(srf->duration - 52);
		srf->decay_time = srf->duration - srf->t_to_peak;

		// NRyRo_peak
		Determine_NRyRo_peak(srf, srf->duration, srf->rand[3]);
		// Long waveform HERE

		// Set actual waveform parameters
		Determine_waveform_parameters(srf);
		// + waveform long here

		srf->srf_set = 1; // indicates that waveform paramteers have been set
	} // end function ready to be set IF

	// set NRyRo from waveform
	if (srf->srf_set == 1)
	{
		Waveform(srf, sim_time);
	}
	else srf->NRyRo	= 0.0;

	// Check if waveform has actually intiated a spontaneous release
	if (srf->srf_set == 1 && srf->waveform_init == 0 && srf->NRyRo > 0.0002)
	{
		srf->waveform_init = 1;
		srf->tinit	= sim_time;
	}

	// Calculate approximate proportion of active CRUs
	if (srf->waveform_init == 1)
	{
		srf->SRF_prop_active 	= (sim_time - srf->tinit)/(srf->duration);
		if (srf->SRF_prop_active > 1.0) srf->SRF_prop_active = 1.0;
	}

	// Check to see if wave has finished and reset if so
	if (srf->NRyRo < 0.0002 && srf->waveform_init == 1)
	{
		srf->srf_set                = -1; // not set but not ready to be set again
		srf->waveform_init    	 	= 0;
		srf->srf_calc               = 0;
	}

	// set the open RyR seen by dyad functions appropriately
	if (srf->NRyRo > 0) d->NRyR_O_SRF = srf->NRyRo;
	else                d->NRyR_O_SRF = 0;
}

void calc_SRF_mults(Spontaneous_release_functions *srf, Membrane_fluxes *mem, Dyad_variables *dyad)
{
	// This is due to a global RyR waveform not inducing same behaviour
	// as the local-propagation which produces the waveform; too much
	// release and too large an INaCa -> where longer duration SRF
	// have the largest difference. Hence, reduce both based on
	// SRF duration (derived by using exact 3D model waveforms in 0D
	// model and adjusting until Ca_ds, Ca_Ss and INaCa_SS were the same
	// then approximating values vs duration
	if (srf->NRyRo > 0.002)
	{
		mem->NCX_SRF_mult     =  0.4/(1 + exp((srf->duration - 176)/46)) + 0.25;
		dyad->Krel_SRF_mult   =  0.35/(1 + exp((srf->duration - 113)/18)) + 0.4;
	}
	else
	{
		mem->NCX_SRF_mult  	= 1.0;
		dyad->Krel_SRF_mult = 1.0;
	}
}
// End run SRF functions ====================================================//|

// Actual waveform functions ================================================\\|
void Determine_waveform_parameters(Spontaneous_release_functions *srf)
{
	srf->k1_waveform    = 0.16980607*srf->t_to_peak  +  0.00254852;
	srf->k2_waveform    = 0.16980607*srf->decay_time +  0.00254852;

	srf->thalf_1 = srf->tset + srf->ti + (srf->t_to_peak/2);
	srf->thalf_2 = srf->tset + srf->ti + srf->t_to_peak + (srf->decay_time/2);
}

void Waveform(Spontaneous_release_functions *srf, double t)
{
	srf->Fn1    	= 1/(1 + exp(-(t - srf->thalf_1)/srf->k1_waveform) );
	srf->Fn2    	= 1/(1 + exp( (t - srf->thalf_2)/srf->k2_waveform) );

	srf->NRyRo      = srf->NRyRo_peak * srf->Fn1 * srf->Fn2;
}
// End Actual waveform functions ============================================//|

// Distribution functions and their inverses ================================\\|
// Initiation time, ti ========================\\|
void Determine_ti(Spontaneous_release_functions *srf, double rand)
{
	if (rand < 0.0002) 				srf->ti = -srf->k_ti_F1*log(( 2 * (  srf->CF_ti_sep) /  0.0002                         ) - 1) + srf->ti_sep;
	else if (rand > 0.9998)			srf->ti = -srf->k_ti_F2*log(((2 * (1-srf->CF_ti_sep))/((0.9998 + 1) - 2*srf->CF_ti_sep)) - 1) + srf->ti_sep;
	else
	{
		if (rand < srf->CF_ti_sep)	srf->ti = -srf->k_ti_F1*log(( 2 * (  srf->CF_ti_sep) /  rand                           ) - 1) + srf->ti_sep;
		else 						srf->ti	= -srf->k_ti_F2*log(((2 * (1-srf->CF_ti_sep))/((rand   + 1) - 2*srf->CF_ti_sep)) - 1) + srf->ti_sep;
	}
}
// End Initiation time, ti ====================//|

// Duration ===================================\\|
void Determine_duration(Spontaneous_release_functions *srf, double rand)
{
	if (rand < 0.0002)      srf->duration =  -srf->k_D_F1*log(1.0/0.0002 - 1)	+ srf->MD; // extreme clauses
	else if (rand > 0.9998) srf->duration =  -srf->k_D_F2*log(1.0/0.9998 - 1) 	+ srf->MD;
	else if (rand < 0.5)    srf->duration =  -srf->k_D_F1*log(1.0/rand   - 1) 	+ srf->MD; // general population
	else                    srf->duration =  -srf->k_D_F2*log(1.0/rand   - 1) 	+ srf->MD;

	// Ensuring not outside expected ranges
	if (srf->duration < 50) 	srf->duration = 50;//printf("negative duration %f\n", srf->duration);
	if (srf->duration > 1000) 	srf->duration = 1000; // maximum physiological duration

	//if (srf->duration < srf->MD - (srf->k_D_F1/(1.8*0.145)) - 10 )
	//{
	//	srf->duration = srf->MD -(srf->k_D_F1/(1.8*0.145) - 10);
	//printf("duration outside range catch %f %f\n", (srf->k1_duration/(1.8*0.145)), (srf->k1_duration/(1.8*0.145)-10));
	//}
}

// for when duration witdh as a function of median, not pre-defined
void Determine_duration_ks_from_MD(Spontaneous_release_functions *srf)
{
	srf->k_D_F1		= srf->DW_k1_A/(1 + exp(-((srf->MD - srf->DW_k1_half))/srf->DW_k1_k)) + srf->DW_k1_min;
	srf->k_D_F2		= srf->DW_k2_A/(1 + exp(-((srf->MD - srf->DW_k2_half))/srf->DW_k2_k)) + srf->DW_k2_min;

	// ms -> gradient param conversion
	srf->k_D_F1		*= 1.8*0.145;
	srf->k_D_F2		*= 1.8*0.145;
}
// End Duration ===============================//|

// NRyR peak ==================================\\|
void Determine_NRyRo_peak(Spontaneous_release_functions *srf, double duration, double rand)
{
	srf->NRyRo_peak_median	= srf->NRyRo_peak_median_A * pow(duration, srf->NRyRo_peak_median_H) + srf->NRyRo_peak_median_min;
	srf->NRyRo_peak			= srf->NRyRo_peak_median + (rand - 0.5)*0.05;	// uniform variance approximation; reasonable
	if (srf->NRyRo_peak	> 0.9) srf->NRyRo_peak = 0.9; // maximal value
}
// End NRyR peak ==============================//|
// End Distribution functions and their inverses ============================//|

// Test and output distributions ============================================\\|
void test_and_produce_distributions(Spontaneous_release_functions *srf, const char * directory, RAND *r)
{
	FILE * out;
	char str_root[1000];
	char str[1000];
	sprintf(str_root, "%s/Functions/", directory);

	double rand;

	// Initiation time distribution ===========\\|
	int v_hist[500];
	int v_int;
	// First, produce inverse function
	sprintf(str, "%s/SRF_distributions/ti_inverse_function.dat", str_root);
	out = fopen(str, "wt");
	for (double x = 0; x <= 1.0; x+= 0.01)
	{
		Determine_ti(srf, x);	
		fprintf(out, "%f %f\n", srf->ti, x);
	}
	fclose(out);
	// Now distribtion from random sampling
	for (int i = 0; i < 500; i++) v_hist[i] = 0;
	for (int i = 0; i < 10000; i++)
	{
		rand = r->mtrand1();
		Determine_ti(srf, rand);
		v_int = int(srf->ti)/10;
		v_hist[v_int] ++; // ti intervals of 10 ms	
	}
	sprintf(str, "%s/SRF_distributions/ti_distribution.dat", str_root);
	out = fopen(str, "wt");
	for (int i = 0; i < 500; i++) fprintf(out, "%d %d\n", (i*10)+5, v_hist[i]);
	fclose(out);
	// End Initiation time distribution =======//|

	// Duration distribtion ===================\\|
	for (int i = 0; i < 500; i++) v_hist[i] = 0;
	if (srf->duration_width == -10) Determine_duration_ks_from_MD(srf);    									// if default value, determine duration dist from average
	else                            srf->k_D_F1 = srf->k_D_F2 = 1.8*0.145*srf->duration_width;    // else set k from width in ms
	// First, produce inverse function
	sprintf(str, "%s/SRF_distributions/duration_inverse_function.dat", str_root);
    out = fopen(str, "wt");
    for (double x = 0; x <= 1.0; x+= 0.01)
    {
        Determine_duration(srf, x);
        fprintf(out, "%f %f\n", srf->duration, x);
    }
    fclose(out);
    // Now distribtion from random sampling
	for (int i = 0; i < 10000; i++)
    {
        rand = r->mtrand1();
		Determine_duration(srf, rand);
		v_int = int(srf->duration)/10;
        v_hist[v_int] ++; // ti intervals of 10 ms
	}
	sprintf(str, "%s/SRF_distributions/duration_distribution.dat", str_root);
	out = fopen(str, "wt");
	for (int i = 0; i < 500; i++) fprintf(out, "%d %d\n", (i*10)+5, v_hist[i]);
	fclose(out);	
	// End Duration distribtion ===============//|

	// NRyRo_peak =============================\\|
	// Produce the NRyRo_peak vs duration function
	sprintf(str, "%s/SRF_distributions/NRyRo_peak_median_vs_duration_function.dat", str_root);
    out = fopen(str, "wt");	
	for (double x = 0; x <= 1000; x+= 1)
	{
		Determine_NRyRo_peak(srf, x, 0.5);
		fprintf(out, "%f %f\n", x, srf->NRyRo_peak); // NRyRo_peak = median as rand = 0.5
	}
	fclose(out);
	// End NRyRo_peak =========================//|

}
// End test and output distributions ========================================//|

// Outputs header file ====================================  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //


// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#ifndef OUTPUTS_H
#define OUTPUTS_H

#include "Structs.h"
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <cstring>


// Global output functions
void output_properties_to_screen(const char * log_reference, Model_variables var, Simulation_parameters Sim);
void output_currents(std::ostream& out, double sim_time, Model_variables var, State_variables s, double Vm);
void output_excitation_properties(std::ostream& out, double sim_time, Model_variables var, double Vm);

// Integrated Ca handling models only
void output_CRU(std::ostream& out, double sim_time, Ca_variables Ca, CRU_variables cru, double Vm);

// Spatial outputs (3D cell and tissue models)
void linescan_out_X(std::ostream& out, SC_variables sc, double * variable, int y, int z);
void linescan_out_Y(std::ostream& out, SC_variables sc, double * variable, int x, int z);
void linescan_out_Z(std::ostream& out, SC_variables sc, double * variable, int x, int y);
void vtk_3D_output(const char *string,  const char * dir, const char * dir2, double *variable, SC_variables sc, int count);


#endif



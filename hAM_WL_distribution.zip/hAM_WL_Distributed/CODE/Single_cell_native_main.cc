// Main file for human atrial cell model code. ============  //
// Associated publication: "Description of the human atrial  //
// action potential dervied from a single, congruent data==  //
// source: Novel computational models for integrated ======  //
// experimental-numerical study of atrial arrhythmia ======  //
// mechanisms." M.A. Colman, P. Saxena, S. Kettlewell and =  //
// A.J. Workman. Frontiers in Physiology 2018. ============  //

// COPYRIGHT MICHAEL A. COLMAN 2018. ======================  //
// THIS SOFTWARE IS PROVIDED OPEN SOURCE AND MAY BE FREELY=  //
// USED, DISTRIBUTED AND UPDATED, PROVIDED: (i) THE =======  //
// APPROPRIATE WORK(S) IS(ARE) CITED; (ii) THIS TEXT IS ===  //
// RETAINED WITHIN THE CODE OR ASSOCIATED  WITH IT. ANY ===  //
// INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY ====  //
// EXPRESS PERMISSION OF MICHAEL A COLMAN ONLY. IN NO EVENT  //
// ARE THE COPYRIGHT HOLDERS LIABLE FOR ANY DIRECT, =======  //
// INDIRECT INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL  //
// DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE ===========  //
// PLEASE SEE ASSOCIATED DOCUMENTATION FOR INSTRUCTIONS AND  //
// FULL CITATION LIST. ====================================  //
// Contact: m.a.colman@leeds.ac.uk ========================  //
// For updates, corrections etc, please check: ============  //
// 1. http://physicsoftheheart.com/ =======================  //
// 2. https://github.com/michaelcolman ====================  //

#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <cstring>
#include <time.h>

#include "lib/Arguments.h"
#include "lib/Initialisation.h"
#include "lib/Structs.h"
#include "lib/Model.h"
#include "lib/Read_write_state.h"
#include "lib/Outputs.h"

using namespace std;

// Main *****************************************************************************************\\|
int main(int argc, char *argv[])
{
	// Read in path for geometry and state files ========\\|
	char PATH[1000];
	FILE *path_in;
	path_in = fopen("PATH.txt", "r");
	if (path_in == NULL) // Check if file can be opened
	{
		printf("ERROR: Cannot open \"PATH.txt\"\n");
		printf("Ensure it is present in the current directory\n");
		exit(1);
	}
	fscanf(path_in, "%[^\n]", PATH); // read up to new line into PATH char
	printf("\n*PATH location is %s*\n", PATH);
	fclose(path_in);
	// End read path ====================================//|

	// Output model version to screen ===================\\|
	printf("\n");
	printf("|============================================================|\n");
	printf("|Multi-scale simulation of cardiac electrophysiology ========|\n");
	printf("|Model version: Single-cell - 0D - native Ca handling =======|\n");
	printf("|Code version:  human atrial models only ====================|\n");
	printf("|============================================================|\n");
	printf("\n");
	// End output to screen =============================//|

	// Command line argument initialise and read in =====\\| 
	Argument_parameters Argin;									// Initialise struct 							|| lib/Arguments.h
	set_argument_defaults(&Argin);								// Sets all boolean switches to false 			|| lib/Arguments.h
	set_arguments(argc, argv, &Argin, "Single_cell_native");	// Sets the arguments struct from  arguments 	|| lib/Arguments.h
	// End Argument handling ============================//|
	
	// Set and assign simulation settings ===============\\|
	Simulation_parameters Sim;									// Initialise sim parameters struct || lib/Structs.h
	set_simulation_defaults(&Sim, 0.02);						// (sim struct, dt)					|| lib/Initialisation.c
	set_simulation_settings(&Sim, Argin, "native");				// Set from arguments				|| lib/Initialisation.c
	// End set and assign settings ======================//|

	// Output files =====================================\\|
	// Create folders if needed
   	char * directory 	= (char*)malloc(500);
	char * mkdirectory	= (char*)malloc(500);
	char * mkfile		= (char*)malloc(500);
	if (Argin.reference_arg == true) sprintf(directory, "Outputs_%s", Sim.reference);
	else sprintf(directory, "Outputs");
	sprintf(mkdirectory, "mkdir -p %s", directory);
	system(mkdirectory);
	sprintf(mkdirectory, "mkdir -p %s/Results", directory);
	system(mkdirectory);
	sprintf(mkdirectory, "mkdir -p %s/Functions", directory);
	system(mkdirectory);
	// Now create actual output files
	printf(">Creating output files...\n");
	if (Sim.S2_CL == 0) sprintf(mkfile, "%s/Results/Currents_BCL_%d.dat", directory, Sim.BCL);
	else 				sprintf(mkfile, "%s/Results/Currents_BCL_%d_S2_%d.dat", directory, Sim.BCL, Sim.S2_CL);
	ofstream out_cu(mkfile);    // Contains all current related outputs
	printf("\t %s\n", mkfile);
	if (Sim.S2_CL == 0)	sprintf(mkfile, "%s/Results/Properties_BCL_%d.dat", directory, Sim.BCL);
	else 				sprintf(mkfile, "%s/Results/Properties_BCL_%d_S2_%d.dat", directory, Sim.BCL, Sim.S2_CL);
	ofstream out_ex(mkfile); 	 // Contains all AP properties related outputs
	printf("\t %s\n", mkfile);
	printf("\n");
	free(mkfile);
	free(mkdirectory);
	// End Output files =================================//|

	// Initialise simulation structs and variables ======\\|
	double		sim_time				= 0;
	int			iteration_counter		= 0; 	// Number of iterations over dt
	int			outcount				= 0; 	// Output number reference

	// All below defined in lib/Structs.h
	Cell_parameters					Params;	
	State_variables					State;
	Model_variables					Variables;
	double 							Vm;	// Global voltage
	printf(">Variables and structs declared\n");
	// End Initialise simulation structs and variables ==//|

	// Set model condition parameters from arguments | lib/Initialisation.c
	set_model_conditions(&Params, Argin); // Set Model, ISO, remodelling etc to default or argument controlled

	// Check Model is appropriate for this code version =\\|
	if      (strcmp(Params.Model, "minimal") == 0);
	else if (strcmp(Params.Model, "hAM_GB") == 0);
	else if (strcmp(Params.Model, "hAM_CRN") == 0);
	else if (strcmp(Params.Model, "hAM_NG") == 0);
	else if (strcmp(Params.Model, "ratAM_CAL") == 0);
	else if (strcmp(Params.Model, "hAM_MT") == 0);
	else if (strcmp(Params.Model, "hAM_WL_CRN") == 0);
	else if (strcmp(Params.Model, "hAM_WL_GB") == 0);
	else if (strcmp(Params.Model, "hAM_GB_mWL") == 0);
	else if (strcmp(Params.Model, "hAM_CRN_mWL") == 0);
	else if (strcmp(Params.Model, "hAM_NG_mWL") == 0);
	else
	{
		printf("ERROR: \"%s\" is not a valid Model selection for this code version\n", Params.Model);
		exit(1);
	}
	// End appropriate check ============================//|

	// Set parameters (defaults and model specific) =====\\|
	// Default modifiers
	set_modification_defaults_native(&Params);		// lib/Initialisation.c

	// Set default global parameters (may want to overwrite a modifier here, hence defaulted above)
	set_default_parameters(&Params);				// lib/Initialisation.c
	printf(">Default parameters set\n");

	// Set model specific parameters
	Params.dt = Sim.dt; 	// Set before "set_params" called, which may explicitly set dt, for checking if dt has changed
	set_parameters_native(&Params, Params.Model);	// lib/Model.c and dependants (may set dt for model-specific)
	if (Argin.Celltype_arg 	== true)	Params.Celltype 	= Argin.Celltype; // Overwrites default celltype if argument passed (default set in appropriate "set_parameters_native" function)
	if (Argin.ISO_model_arg == true)	Params.ISO_model 	= Argin.ISO_model; // Overwrites default celltype if argument passed (default set in appropriate "set_parameters_native" function or set model conditions)
	if (Argin.Ihyp_arg      == true)   	Params.AIhyp        = Argin.AIhyp;
	// Update Sim.dt if Params.dt has been explicitly set in "set_parameters" (thus Sim.dt != Params.dt), and dt has NOT been passed as a command-line argument.
	if (Argin.dt_arg    	== false && Params.dt != Sim.dt) 	Sim.dt = Params.dt;
	printf(">Model and version specific parameters set\n");
	// End set parameters (defaults and model specific) =//|

	// Set current modification =========================\\| 
	assign_modification_from_arguments(&Params, Argin);	// lib/Initialisation.c
	set_heterogeneity_and_modulation_native(&Params);	// lib/Model.c
	printf(">Heterogeneity and modulation parameters set\n");
	// end set current modification =====================\\| 

	// Initialise stimulus ==============================\\|
	stimulus_setup(Params, &Variables, Sim.dt, Sim.BCL, Sim.S2_CL, Sim.Paced_time); // lib/Model.c
	printf(">Stimulus settings set\n");
	// End initialise stimulus ==========================//|

	// Output settings to screen and file || done here so can output actual settings (rather than inputs) for confidence
	output_settings(Sim, directory, Argin.DC_current_mod_arg, Params);	// lib/Initialisation.c

	// Setup complete, simulation running ======\\|
	time_t rawtime;
	time (&rawtime);
	printf("|============================================================|\n");
	printf("|Setup complete:\n");
	printf("|Code is now running. Started at %s", ctime (&rawtime));
	printf("|============================================================|\n\n");
	// End Setup complete, simulation running ==//|

	// Set initial conditions of state variables
	initial_conditions_native(&State, Params, Params.Model); 	// lib/Model.c
	Vm = State.Vm;
	Variables.ex_switch		= 0; 	// Default to not in excitation state
	Variables.APD_t_switch 	= -1; 	// Not set or ready to be set
	printf("Initial conditions set\n");

	// Calculate and output voltage-dependant functions, as used in the simulation
	compute_and_output_current_functions(Params, &Variables, directory); // lib/Model.c
	if(strcmp(Sim.Vclamp, "On") == 0) 
	{
		run_voltage_clamp(Params, &Variables, &State, directory, Sim.dt);
		initial_conditions_native(&State, Params, Params.Model);    // lib/Model.c || Re-set initial conditions
		printf("Voltage clamp completed\n");
	}

	// Read state 
	if (strcmp(Sim.Read_state, "On") == 0)
	{
		Read_state_single_cell_native(&State, Params, Sim.BCL, PATH, Params.Model); //lib/Read_write_state.c
		printf("Initial conditions / state read in from file\n");
	}

	// Time loop ================================================================================\\|
	printf("Time loop started:\nTime = %.0fms\n",sim_time);
	for (sim_time = 0.0; sim_time < (float)Sim.Total_time; sim_time += Sim.dt)
	{
		// Compute stimulus current
		compute_Istim(Params, &Variables, Sim.Paced_time, Sim.S2_time, sim_time, iteration_counter);  	// lib/Model.c

		// Solve the model
		compute_model_native(Params, &Variables, &State, Vm, Sim.dt);						// lib/Model.c

		// Update Voltage
		State.Vm	= State.Vm + Sim.dt*(-(Variables.Itot + Variables.Istim + Variables.Istim_S2));

		// Excitation state and measurements | lib/Model.c  | "State.Vm" is voltage at t, "Vm" is voltage at t-dt
		determine_excitation_state(&Variables, Vm, sim_time);							
		calculate_measurement_properties(&Variables, Vm, State.Vm, sim_time, Sim.dt, -70, State.Cai, State.CanSR);		// -70 is APD V threshold	

		// Assign global voltage to state voltage
		Vm			= State.Vm;

		// Output data to files
		if (iteration_counter%(int)(1/Sim.dt) == 0) // if sim_time is an integer (i.e. per ms)
		{
			output_currents(out_cu, sim_time, Variables, State, Vm);						// lib/Outputs.cpp
			output_excitation_properties(out_ex, sim_time, Variables, Vm);					// lib/Outputs.cpp
		}

		iteration_counter ++;
		if (iteration_counter%(2000*((int)(1/Sim.dt))) == 0) printf("Time = %.0fms\n",sim_time); // output every 2000 ms
	}
	// End Time loop ============================================================================//|

	printf("Final Time = %.0fms\n\n",sim_time);

	// Write state 
	if (strcmp(Sim.Write_state, "On") == 0)
	{
		Write_state_single_cell_native(State, Params, Sim.BCL, PATH, Params.Model); //lib/Read_write_state.c
		printf("State written to file\n");
	}
	// End Write state

	// Output final beat properties to file and screen
	char * log_reference 	= (char*)malloc(500);
	sprintf(log_reference, "%s/Properties_log.dat", directory);
	output_properties_to_screen(log_reference, Variables, Sim); 	// lib/Outputs.cpp
	free(log_reference);

	time (&rawtime);
	printf("|============================================================|\n");
	printf("|Code has now finished. Finished at %s", ctime (&rawtime));
	printf("|============================================================|\n");

	free(directory);
} 
// End Main *************************************************************************************//|

